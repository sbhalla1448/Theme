<?php
/**
 * Cart totals
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/cart/cart-totals.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 2.3.6
 */

defined( 'ABSPATH' ) || exit;

?>

<div class="cart_totals <?php echo ( WC()->customer->has_calculated_shipping() ) ? 'calculated_shipping' : ''; ?>">
    <?php do_action( 'woocommerce_before_cart_totals' ); ?>
    <div class="shop-cart-widget">
        <p><?php _e('Sub Total', 'open-learning'); ?> <span><?php wc_cart_totals_subtotal_html(); ?></span></p>
        <?php foreach ( WC()->cart->get_coupons() as $code => $coupon ) : ?>
            <p class="cart-discount coupon-<?php echo esc_attr( sanitize_title( $code ) ); ?>">
                <span class="coupon-label"><?php echo apply_filters( 'woocommerce_cart_totals_coupon_label', sprintf( esc_html__( 'COUPON : %s', 'open-learning' ), $coupon->get_code() ), $coupon ); ?></span>
                <div data-title="<?php echo esc_attr( wc_cart_totals_coupon_label( $coupon, false ) ); ?>">
                <?php 
                $discount_amount_html = '';

                $amount               = WC()->cart->get_coupon_discount_amount( $coupon->get_code(), WC()->cart->display_cart_ex_tax );
                $discount_amount_html = '-' . wc_price( $amount );
            
                if ( $coupon->get_free_shipping() && empty( $amount ) ) {
                $discount_amount_html = esc_html__( 'Free shipping coupon', 'open-learning' );
                }
                echo apply_filters( 'woocommerce_coupon_discount_amount_html', $discount_amount_html, $coupon );

                $coupon_html          = ' <a href="' . esc_url( add_query_arg( 'remove_coupon', rawurlencode( $coupon->get_code() ), defined( 'WOOCOMMERCE_CHECKOUT' ) ? wc_get_checkout_url() : wc_get_cart_url() ) ) . '" class="woocommerce-remove-coupon py-2 px-3 btn btn-sm" data-coupon="' . esc_attr( $coupon->get_code() ) . '">' . esc_html__( 'Remove', 'open-learning' ) . '</a>';

                echo apply_filters( 'woocommerce_cart_totals_coupon_html', $coupon_html);
                ?>
                </div>
            </p>
        <?php endforeach; ?>

        <?php foreach ( WC()->cart->get_fees() as $fee ) : ?>
            <p class="fee">
                <th><?php echo esc_html( $fee->name ); ?></th>
                <td data-title="<?php echo esc_attr( $fee->name ); ?>"><?php wc_cart_totals_fee_html( $fee ); ?></td>
            </p>
        <?php endforeach; ?>

        <?php
        if ( wc_tax_enabled() && ! WC()->cart->display_prices_including_tax() ) {
            $taxable_address = WC()->customer->get_taxable_address();
            $estimated_text  = '';

            if ( WC()->customer->is_customer_outside_base() && ! WC()->customer->has_calculated_shipping() ) {
                /* translators: %s location. */
                $estimated_text = sprintf( ' <small>' . esc_html__( '(estimated for %s)', 'open-learning' ) . '</small>', WC()->countries->estimated_for_prefix( $taxable_address[0] ) . WC()->countries->countries[ $taxable_address[0] ] );
            }

            if ( 'itemized' === get_option( 'woocommerce_tax_total_display' ) ) {
                foreach ( WC()->cart->get_tax_totals() as $code => $tax ) { // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
                    ?>
                    <p class="tax-rate tax-rate-<?php echo esc_attr( sanitize_title( $code ) ); ?>">
                        <th><?php echo esc_html( $tax->label ) . $estimated_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></th>
                        <td data-title="<?php echo esc_attr( $tax->label ); ?>"><?php echo wp_kses_post( $tax->formatted_amount ); ?></td>
                    </p>
                    <?php
                }
            } else {
                ?>
                <p class="tax-total">
                    <th><?php echo esc_html( WC()->countries->tax_or_vat() ) . $estimated_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></th>
                    <td data-title="<?php echo esc_attr( WC()->countries->tax_or_vat() ); ?>"><?php wc_cart_totals_taxes_total_html(); ?></td>
                </p>
                <?php
            }
        }
        ?>

        <?php do_action( 'woocommerce_cart_totals_before_order_total' ); ?>
        <h2 class="cart-total-amount">
            <?php _e('Grand Total', 'open-learning'); ?> <span><?php wc_cart_totals_order_total_html(); ?></span>
        </h2>

        <?php do_action( 'woocommerce_cart_totals_after_order_total' ); ?>
    </div>
    <?php do_action( 'woocommerce_after_cart_totals' ); ?>
</div>
