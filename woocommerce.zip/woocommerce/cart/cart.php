<?php
/**
 * Cart Page
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/cart/cart.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.8.0
 */

defined( 'ABSPATH' ) || exit;

?>
<?php
    /**
     * woocommerce_before_main_content hook.
     *
     * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
     * @hooked woocommerce_breadcrumb - 20
     */
    do_action( 'woocommerce_before_main_content' );
?>
<div class="rbt-cart-area bg-color-white rbt-section-gap">
    <div class="cart_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <?php do_action( 'woocommerce_before_cart' ); ?>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <form class="woocommerce-cart-form" action="<?php echo esc_url( wc_get_cart_url() ); ?>" method="post">
                    <?php do_action( 'woocommerce_before_cart_table' ); ?>
                    <!-- Cart Table -->
                    <div class="cart-table table-responsive mb--60">
                    <table class="table cart woocommerce-cart-form__contents" cellspacing="0">
                        <thead>
                            <tr>
                                <th class="pro-thumbnail"><?php esc_html_e( 'Image', 'woocommerce' ); ?></th>
                                <th class="pro-title"><?php esc_html_e( 'Product', 'woocommerce' ); ?></th>
                                <th class="pro-price"><?php esc_html_e( 'Price', 'woocommerce' ); ?></th>
                                <th class="pro-quantity"><?php esc_html_e( 'Quantity', 'woocommerce' ); ?></th>
                                <th class="pro-subtotal"><?php esc_html_e( 'Subtotal', 'woocommerce' ); ?></th>
                                <th class="pro-remove"><?php _e('Remove', 'open-learning'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php do_action( 'woocommerce_before_cart_contents' ); ?>

                            <?php
                            foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
                                $_product   = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
                                $product_id = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );

                                if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
                                    $product_permalink = apply_filters( 'woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink( $cart_item ) : '', $cart_item, $cart_item_key );
                                    ?>
                                    <tr class="woocommerce-cart-form__cart-item <?php echo esc_attr( apply_filters( 'woocommerce_cart_item_class', 'cart_item', $cart_item, $cart_item_key ) ); ?>">
                                        <td class="pro-thumbnail product-thumbnail">
                                            <?php
                                            $thumbnail = apply_filters( 'woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key );

                                            if ( ! $product_permalink ) {
                                                echo $thumbnail; // PHPCS: XSS ok.
                                            } else {
                                                printf( '<a href="%s">%s</a>', esc_url( $product_permalink ), $thumbnail ); // PHPCS: XSS ok.
                                            }
                                            ?>
                                        </td>

                                        <td class="pro-title product-name" data-title="<?php esc_attr_e( 'Product', 'woocommerce' ); ?>">
                                        <?php
                                        if ( ! $product_permalink ) {
                                            echo wp_kses_post( apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key ) . '&nbsp;' );
                                        } else {
                                            echo wp_kses_post( apply_filters( 'woocommerce_cart_item_name', sprintf( '<a href="%s">%s</a>', esc_url( $product_permalink ), $_product->get_name() ), $cart_item, $cart_item_key ) );
                                        }

                                        do_action( 'woocommerce_after_cart_item_name', $cart_item, $cart_item_key );

                                        // Meta data.
                                        echo wc_get_formatted_cart_item_data( $cart_item ); // PHPCS: XSS ok.

                                        // Backorder notification.
                                        if ( $_product->backorders_require_notification() && $_product->is_on_backorder( $cart_item['quantity'] ) ) {
                                            echo wp_kses_post( apply_filters( 'woocommerce_cart_item_backorder_notification', '<p class="backorder_notification">' . esc_html__( 'Available on backorder', 'woocommerce' ) . '</p>', $product_id ) );
                                        }
                                        ?>
                                        </td>

                                        <td class="pro-price product-price" data-title="<?php esc_attr_e( 'Price', 'woocommerce' ); ?>">
                                            <?php
                                                echo apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $_product ), $cart_item, $cart_item_key ); // PHPCS: XSS ok.
                                            ?>
                                        </td>

                                        <td class="pro-quantity product-quantity" data-title="<?php esc_attr_e( 'Quantity', 'woocommerce' ); ?>">
                                        <div class="pro-qty">
                                            <?php
                                            if ( $_product->is_sold_individually() ) {
                                                $min_quantity = 1;
                                                $max_quantity = 1;
                                            } else {
                                                $min_quantity = 0;
                                                $max_quantity = $_product->get_max_purchase_quantity();
                                            }
                                            ?>
                                            <input type="text" value="<?php echo $cart_item['quantity']; ?>" autocomplete="off" name="<?php echo "cart[{$cart_item_key}][qty]"; ?>">
                                        </div>
                                        </td>

                                        <td class="pro-subtotal product-subtotal" data-title="<?php esc_attr_e( 'Subtotal', 'woocommerce' ); ?>">
                                            <?php
                                                echo apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $_product, $cart_item['quantity'] ), $cart_item, $cart_item_key ); // PHPCS: XSS ok.
                                            ?>
                                        </td>
                                        <td class="pro-remove product-remove">
                                            <?php
                                                echo apply_filters( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                                                    'woocommerce_cart_item_remove_link',
                                                    sprintf(
                                                        '<a href="%s" aria-label="%s" data-product_id="%s" data-product_sku="%s"><i class="feather-x"></i></a>',
                                                        esc_url( wc_get_cart_remove_url( $cart_item_key ) ),
                                                        esc_html__( 'Remove this item', 'woocommerce' ),
                                                        esc_attr( $product_id ),
                                                        esc_attr( $_product->get_sku() )
                                                    ),
                                                    $cart_item_key
                                                );
                                            ?>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                    </div>
                    <?php do_action( 'woocommerce_after_cart_table' ); ?>
                    
                    <div class="row g-5">

                        <div class="col-lg-6 col-12">

                            <!-- Calculate Shipping -->
                            <?php if ( WC()->cart->needs_shipping() && WC()->cart->show_shipping() ) : ?>

                            <?php do_action( 'woocommerce_cart_totals_before_shipping' ); ?>

                            <?php wc_cart_totals_shipping_html(); ?>

                            <?php do_action( 'woocommerce_cart_totals_after_shipping' ); ?>

                            <?php elseif ( WC()->cart->needs_shipping() && 'yes' === get_option( 'woocommerce_enable_shipping_calc' ) ) : ?>

                            <p class="shipping">
                                <th><?php esc_html_e( 'Shipping', 'open-learning' ); ?></th>
                                <td data-title="<?php esc_attr_e( 'Shipping', 'open-learning' ); ?>"><?php woocommerce_shipping_calculator(); ?></td>
                            </p>

                            <?php endif; ?>
                            <?php if ( wc_coupons_enabled() ) { ?>
                            <!-- Discount Coupon -->
                            <div class="discount-coupon edu-bg-shade">
                                <div class="section-title text-start">
                                    <h4 class="title mb--30"><?php _e('Discount Coupon Code', 'open-learning'); ?></h4>
                                </div>
                               
                                <div class="row">
                                    <div class="col-md-6 col-12 mb--25">
                                        <input type="text" placeholder="Coupon Code" name="coupon_code" class="input-text" id="coupon_code" value="">
                                    </div>
                                    <div class="col-md-6 col-12 mb--25">
                                        <?php wp_nonce_field( 'woocommerce-cart', 'woocommerce-cart-nonce' ); ?>
                                        <div class="coupon">
                                            <button class="rbt-btn btn-gradient hover-icon-reverse btn-sm" name="apply_coupon" value="<?php esc_attr_e( 'Apply coupon', 'woocommerce' ); ?>">
                                                <span class="icon-reverse-wrapper">
                                                    <span class="btn-text"><?php esc_attr_e( 'Apply coupon', 'woocommerce' ); ?></span>
                                                <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                                <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                                </span>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php } ?>
                        </div>
                        <!-- Cart Summary -->

                        <div class="col-lg-5 offset-lg-1 col-12">
                            <div class="cart-summary">
                                <div class="cart-summary-wrap">
                                    <div class="section-title text-start">
                                        <h4 class="title mb--30"><?php _e('Cart Summary', 'open-learning'); ?></h4>
                                    </div>
                                    <?php
                                        /**
                                         * Cart collaterals hook.
                                         *
                                         * @hooked woocommerce_cross_sell_display
                                         * @hooked woocommerce_cart_totals - 10
                                         */
                                        do_action( 'woocommerce_cart_collaterals' );
                                    ?>
                                </div>

                                <div class="cart-submit-btn-group">
                                    <div class="single-button w-50">
                                        <?php do_action( 'woocommerce_proceed_to_checkout' ); ?>
                                    </div>
                                    <div class="single-button w-50">
                                        <button type="submit" class="rbt-btn rbt-switch-btn rbt-switch-y w-100 btn-border" name="update_cart" value="<?php esc_attr_e( 'Update cart', 'woocommerce' ); ?>">
                                            <span data-text="Update Cart"><?php esc_html_e( 'Update cart', 'woocommerce' ); ?></span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="rbt-separator-mid">
    <div class="container">
        <hr class="rbt-separator m-0">
    </div>
</div>
