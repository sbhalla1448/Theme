<?php
/**
 * Single variation cart button
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.4.0
 */

defined( 'ABSPATH' ) || exit;

global $product;
?>

<div class="perched-info">
    <div class="cart-plus-minus">
        <div class="qty num-block">
            <input type="number" class="in-num"
                value="<?php echo isset( $_POST['quantity'] ) ? wc_stock_amount( wp_unslash( $_POST['quantity'] ) ) : $product->get_min_purchase_quantity(); ?>"
                readonly="" name="quantity">
            <div class="qtybutton-box">
                <span class="plus"><img src="<?php echo get_template_directory_uri();?>/assets/img/icon/plus.png"
                        alt="<?php _e( 'plus', 'open-learning' ); ?>"></span>
                <span class="minus dis"><img src="<?php echo get_template_directory_uri();?>/assets/img/icon/minus.png"
                        alt="<?php _e( 'minus', 'open-learning' ); ?>"></span>
            </div>
        </div>
    </div>
    <button type="submit" class="btn"><?php echo esc_html( $product->single_add_to_cart_text() ); ?></button>
    <div class="wishlist-compare">
        <ul>
            <?php echo do_shortcode('[yith_wcwl_add_to_wishlist]'); ?>
            <li><a href="#" title="Add to Compare List"><i class="fas fa-retweet"></i></a></li>
        </ul>
    </div>
</div>
<input type="hidden" name="add-to-cart" value="<?php echo absint( $product->get_id() ); ?>" />
<input type="hidden" name="product_id" value="<?php echo absint( $product->get_id() ); ?>" />
<input type="hidden" name="variation_id" class="variation_id" value="0" />