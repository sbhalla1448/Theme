<?php
/**
 * Single Product tabs
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/tabs/tabs.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.8.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Filter tabs and allow third parties to add their own.
 *
 * Each tab is an array containing title, callback and priority.
 *
 * @see woocommerce_default_product_tabs()
 */
$product_tabs = apply_filters( 'woocommerce_product_tabs', array() );

if ( ! empty( $product_tabs ) ) : ?>
<div class="rbt-product-description rbt-section-gapBottom bg-color-white">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 offset-lg-2">
				<ul class="nav nav-tabs tab-button-style-2" id="myTab" role="tablist">
					<?php $count = 0; foreach ( $product_tabs as $key => $product_tab ) : $count++;?>
					<?php if( $product_tab['callback'] != 'woocommerce_product_additional_information_tab' ): ?>
					<li class="nav-item" role="presentation">
						<a class="tab-button <?php echo wp_kses_post($count === 1 ? 'active' : ''); ?>" data-bs-toggle="tab" data-bs-target="#<?php echo esc_attr( $key ); ?>-4" role="tab" aria-controls="<?php echo esc_attr( $key ); ?>-tab-4" aria-selected="true">
							<span class="title"><?php echo wp_kses_post( apply_filters( 'woocommerce_product_' . $key . '_tab_title', $product_tab['title'], $key ) ); ?></span>
						</a>
					</li>
					<?php endif; ?>
					<?php endforeach; ?>
				</ul>
				<div class="tab-content" id="myTabContent">
					<?php $count = 0; foreach ( $product_tabs as $key => $product_tab ) : $count++;?>
						<div class="product-description-content tab-pane fade <?php echo wp_kses_post($count === 1 ? 'show active' : '');?>" id="<?php echo esc_attr( $key ); ?>-4" role="tabpanel" aria-labelledby="<?php echo esc_attr( $key ); ?>-tab-4">
							<?php
							if ( isset( $product_tab['callback'] ) ) {
								call_user_func( $product_tab['callback'], $key, $product_tab );
							}
							?>
						</div>
					<?php endforeach; ?>
				</div>
				<?php do_action( 'woocommerce_product_after_tabs' ); ?>
			</div>
		</div>
	</div>
</div>
<?php do_action( 'woocommerce_product_after_tabs' ); ?>

<?php endif; ?>