<?php
/**
 * Loop Add to Cart
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/loop/add-to-cart.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     3.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( defined( 'YITH_WCWL' ) && get_option('yith_wcwl_show_on_loop') == 'yes' ) {
	return false;
}

global $product;
?>
<?php ob_start(); ?>
<a class="rbt-btn btn-gradient hover-icon-reverse" data-quantity="<?php echo esc_attr( isset( $args['quantity'] ) ? $args['quantity'] : 1 ); ?>" <?php echo isset( $args['attributes'] ) ? wc_implode_html_attributes( $args['attributes'] ) : ''; ?> href="<?php echo esc_url( $product->add_to_cart_url() ); ?>">
	<span class="icon-reverse-wrapper">
		<span class="btn-text"><?php _e('Add To Cart', 'open-learning'); ?></span>
	<span class="btn-icon"><i class="feather-arrow-right"></i></span>
	<span class="btn-icon"><i class="feather-arrow-right"></i></span>
	</span>
</a>
<?php
	echo apply_filters(
		'woocommerce_loop_add_to_cart_link', // WPCS: XSS ok.
		ob_get_clean(),
		$product,
		$args
	);
?>
