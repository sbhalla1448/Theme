<?php
/**
 * Pagination
 */

global $wp_query;
$total   = $wp_query->max_num_pages;
$current = get_query_var( 'paged' );
$base    = isset( $base ) ? $base : esc_url_raw( str_replace( 999999999, '%#%', get_pagenum_link( 999999999, false ) ) );
$format  = isset( $format ) ? $format : '';

if( $total <= 1 ){
    return;
}

$args = array(
    'base'      => $base,
    'format'    => $format,
    'add_args'  => false,
    'current'   => max( 1, $current ),
    'total'     => $total,
    'prev_text' => is_rtl() ? '<i class="feather-chevron-right"></i>' : '<i class="feather-chevron-left"></i>',
    'next_text' => is_rtl() ? '<i class="feather-chevron-left"></i>' : '<i class="feather-chevron-right"></i>',
    'type'      => 'list',
    'end_size'  => 3,
    'mid_size'  => 3,
);
echo paginate_links($args);
?>