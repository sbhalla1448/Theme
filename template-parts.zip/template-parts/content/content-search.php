<?php
/**
 * Template part for displaying results in search pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package OLC
 */
?>
  <!-- Start Single Card  -->
  <div class="rbt-card variation-01 rbt-hover">
		<?php tutor_load_template( 'loop.thumbnail' ); ?>
			<div class="rbt-card-body">
				<h4 class="rbt-card-title">
                <a href="<?php echo esc_url( get_the_permalink() ); ?>"><?php echo esc_html( theme_truncate( get_the_title(), 35 ) );  ?></a>
                </h4>
                <p class="rbt-card-desc">
                    <?php echo esc_html( theme_truncate( get_the_excerpt(), 105 ) );  ?>
                </p>
                <?php tutor_load_template( 'loop.rating' ); ?>
                <div class="rbt-card-bottom">
                    <?php tutor_course_loop_price(); ?>
                </div>
			</div>
</div>
<!-- End Single Card  -->