<?php
/**
 * 
 * Footer Menu
 * @package OLC
 * @version 1.0.0
 * 
 */

 ?>

<?php 
    if( has_nav_menu( 'footer_menu')):
        wp_nav_menu( array(
            'theme_location'    => 'footer_menu',
            'menu_class'        => 'menu-links',
            'container'         => 'nav',
            'container_class'   => 'menu-links'
        ));
    endif;
?>
