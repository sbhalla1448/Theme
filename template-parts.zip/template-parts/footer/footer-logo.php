<?php
/**
 * Footer 2 logo
 */

$footer_style = function_exists('get_field') ? get_field('footer_styles') : '';
?>
<div class="footer-logo" id="footer-logo">
    <?php if( get_theme_mod('footer_1_logo') ||  get_theme_mod('footer_2_logo') ): ?>
        <a href="<?php echo site_url('/'); ?>"><img src="<?php echo (esc_attr($footer_style) == 'footer_2' || esc_attr($footer_style) == 'footer_3') ? esc_url(get_theme_mod('footer_2_logo', get_theme_file_uri('/assets/img/logo/logo.png'))) : esc_url(get_theme_mod('footer_1_logo')); ?>" alt="<?php bloginfo( 'name' ); ?>"></a>
    <?php else: ?>
        <h2 class="<?php echo (esc_attr($footer_style) == 'footer_2' || esc_attr($footer_style) == 'footer_3') ? 'text-dark' : 'text-white'; ?>"><a href="<?php echo site_url('/'); ?>"><?php bloginfo('name'); ?></a></h2>
    <?php endif; ?>
</div>