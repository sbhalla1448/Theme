<?php
/**
 * Search
 */
?>
<div class="rbt-search-field">
    <div class="search-field">
        <form action="<?php echo home_url( '/' ); ?>" method="get">
            <input type="text" placeholder="Search Course" value="<?php  echo get_search_query() ?>" name="s" id="s">
            <input type="hidden" name="post_type" value="courses">
            <button type="submit" class="rbt-round-btn serach-btn" value="<?php echo esc_attr( 'Search', 'open-learning' ); ?>"><i
                class="feather-search"></i></button>
        </form>
    </div>
</div>