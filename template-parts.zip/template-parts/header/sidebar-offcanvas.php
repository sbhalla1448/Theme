<?php
/**
 * 
 * Sidebar Offcanvas
 */
?>

<div class="sidebar-off-canvas info-group">
    <div class="off-canvas-overlay"></div>
    <div class="off-canvas-widget scroll">
        <div class="sidebar-widget-container">
            <div class="off-canvas-heading">
                <a href="#" class="close-side-widget">
                    <svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16">
                        <path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"/>
                    </svg>
                </a>
            </div>
            <div class="sidebar-textwidget">
                <div class="sidebar-info-contents">
                    <div class="content-inner">
                        <div class="logo mb-30">
                            <?php get_template_part('template-parts/header/logo'); ?>
                        </div>
                        <div class="content-box">
                            <p id="offcanvas_text"><?php echo wp_kses_post(get_theme_mod( 'offcanvas_text', esc_html__('WooCommerce and WordPress are both free, open source software reasons many!', 'open-learning') ));; ?></p>
                        </div>
                        <div class="contact-info">
                            <h4 class="title"><?php echo wp_kses_post( esc_html__('CONTACT US', 'open-learning') ); ?></h4>
                            <ul>
                                <li><span class="flaticon-phone-call"></span><a href="tel:<?php echo str_replace(' ', '', get_theme_mod( 'offcanvas_contact_phone', esc_html('+93254440000') )); ?>" id="offcanvas_contact_phone"><?php echo wp_kses_post(str_replace(' ', '', get_theme_mod( 'offcanvas_contact_phone', esc_html('+93254440000'))));; ?></a></li>
                                <li><span class="flaticon-email"></span><a
                                        href="mailto:<?php echo get_theme_mod( 'offcanvas_contact_email', esc_html('adara@info.com') ); ?>" id="offcanvas_contact_email"><?php echo wp_kses_post(get_theme_mod( 'offcanvas_contact_email', esc_html('adara@info.com') ));; ?></a></li>
                                <li><span class="flaticon-place"></span><a id="offcanvas_contact_address"><?php echo wp_kses_post(get_theme_mod( 'offcanvas_contact_address', esc_html('71 Park Lan Street 2355 NY') ));; ?></a></li>
                            </ul>
                        </div>
                        <?php
                            if( class_exists('OLC_Newsletter') ){
                                the_widget('OLC_Newsletter');
                            }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>