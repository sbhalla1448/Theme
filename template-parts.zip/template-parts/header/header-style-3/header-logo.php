<?php
/**
 * Header style 3 logo
 */
?>
<?php if(has_custom_logo() ):
    $logo = get_theme_mod( 'custom_logo' );
    $logo_url = wp_get_attachment_image_url( $logo, 'large' );
    if(!$logo_url){
        $logo_url = get_theme_mod( 'main_logo', esc_url(get_theme_file_uri('/assets/img/logo/fw_logo.png')) );
    }if(function_exists('get_field') && get_field('header_styles') === 'header_3'){
        $logo_url = esc_url(get_theme_file_uri('/assets/img/logo/fw_logo.png'));
    }
    echo sprintf(
        '<a href="%1$s"  class="main-logo"><img src="%2$s" alt="%3$s"></a>',
        home_url('/'),
        esc_url( $logo_url ),
        get_bloginfo( 'name' )
    );
?>
<?php else: ?>
    <h2><a href="<?php echo home_url('/'); ?>" class="main-logo text-white"><?php bloginfo( 'name' ); ?></a></h2>
<?php endif; ?>

<?php if(get_theme_mod('secondary_logo')):
    $secondary_logo = esc_url( get_theme_mod('secondary_logo', get_theme_file_uri('/assets/img/logo/logo.png') ) );
    if(function_exists('get_field') && get_field('header_styles') === 'header_3'){
        $secondary_logo = esc_url(get_theme_file_uri('/assets/img/logo/logo.png'));
    }
    
?>
    <a href="<?php echo home_url('/'); ?>" class="sticky-logo"><img src="<?php echo esc_url($secondary_logo); ?>" alt="<?php bloginfo('name'); ?>"></a>
<?php else: ?>
    <h2><a href="<?php echo home_url('/'); ?>" class="sticky-logo"><?php bloginfo( 'name' ); ?></a></h2>
<?php endif; ?>