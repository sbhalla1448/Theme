<?php
/**
 * 
 * Custom Hooks
 */

 function adara_social_links_fn(){
    get_template_part( 'template-parts/social-links' );
 }
 add_action( 'adara_social_links', 'adara_social_links_fn' );
