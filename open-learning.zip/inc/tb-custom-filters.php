<?php
/**
 * 
 * Custom Filters
 */

// menu ul class
function olc_nav_menus( $classes, $item, $args, $depth){
    $args->menu_class = 'ft-link';

    return $classes;
}
// add_filter('nav_menu_css_class', 'olc_nav_menus', 10, 4);


function olc_custom_dashboard_menu_item($tutor_dashboard_menu_items){
    $tutor_dashboard_menu_items = array_merge(array_slice($tutor_dashboard_menu_items, 0, 4), array(
        'my-events' => array(
            'title' 	=> 'My Events',
            'auth_cap'	=> 'tutor_instructor',
            'icon'		=> 'tutor-icon-calender-bold'
        )
    ), array_slice($tutor_dashboard_menu_items, 4));

    return $tutor_dashboard_menu_items;
}
add_filter('tutor_dashboard/instructor_nav_items', 'olc_custom_dashboard_menu_item');

// function custom_subpage_rewrite_rule() {
//     $dashboard_page_id   = (int) tutor_utils()->get_option( 'tutor_dashboard_page_id' );
//     $dashboard_page_slug = get_post_field( 'post_name', $dashboard_page_id );
//     add_rewrite_rule(
//           "^{$dashboard_page_slug}/my-events/?$",
//           "index.php?pagename={$dashboard_page_slug}&subpage=1",
//           'top'
//     );
// }
// add_action('init', 'custom_subpage_rewrite_rule');

