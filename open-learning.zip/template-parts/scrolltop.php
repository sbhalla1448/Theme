<?php
/**
 * 
 * ScrollTop
 */
?>

<button class="scroll-top scroll-to-target" data-target="html">
    <i class="fas fa-angle-up"></i>
</button>