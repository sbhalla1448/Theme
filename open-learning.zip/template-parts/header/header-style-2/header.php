<?php
/**
 * Header Style 2
 */
?>

<!-- Start Header Area -->
<header class="rbt-header rbt-header-9">
    <div class="rbt-sticky-placeholder"></div>
    <?php if( get_theme_mod('header_campaign') ): ?>
    <div class="rbt-header-campaign rbt-header-campaign-1 rbt-header-top-news bg-image1">
        <div class="wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="inner justify-content-center">
                            <div class="content">
                                <span class="rbt-badge variation-02 bg-color-primary color-white radius-round"><?php echo esc_html__(get_theme_mod('header_campaign_offer_text'), 'open-learning'); ?></span>
                                <span class="news-text color-white-off"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/hand-emojji.svg"
                                        alt="Hand Emojji Images"> <?php echo esc_html__(get_theme_mod('header_campaign_text'), 'open-learning'); ?></span>
                            </div>
                            <div class="right-button">
                                <a class="rbt-btn-link color-white"
                                    href="<?php echo esc_html__(get_theme_mod('header_campaign_button_link'), 'open-learning'); ?>">
                                    <span><?php echo esc_html__(get_theme_mod('header_campaign_button_text'), 'open-learning'); ?> <i class="feather-arrow-right"></i></span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="icon-close position-right">
            <button class="rbt-round-btn btn-white-off bgsection-activation">
                <i class="feather-x"></i>
            </button>
        </div>
    </div>
    <?php endif; ?>

    <!-- Start Header Top -->
    <div class="rbt-header-middle position-relative rbt-header-mid-1  bg-color-white rbt-border-bottom">
        <div class="container">
            <div class="rbt-header-sec align-items-center ">

                <div class="rbt-header-sec-col rbt-header-center d-none d-md-block">
                    <div class="rbt-header-content">
                        <div class="header-info">
                            <?php get_template_part('template-parts/header/search'); ?>
                        </div>
                    </div>
                </div>

                <div class="rbt-header-sec-col rbt-header-right">
                    <div class="rbt-header-content">
                        <div class="header-info">
                            <ul class="quick-access">
                                <li>
                                    <a class="d-none d-xl-block rbt-cart-sidenav-activation" href="#"><i
                                            class="feather-shopping-cart"></i><?php _e('Cart', 'open-learning'); ?></a>
                                    <a class="d-block d-xl-none rbt-cart-sidenav-activation" href="#"><i
                                            class="feather-shopping-cart"></i></a>
                                </li>
                            </ul>
                        </div>
                        <?php if( is_user_logged_in() ): ?>
                        <div class="header-info">
                            <?php
                                $user_id                   = get_current_user_id();
                                $user                      = get_user_by( 'ID', $user_id );
                            ?>
                            <ul class="quick-access">
                                <li class="account-access rbt-user-wrapper right-align-dropdown d-none d-xl-block">
                                    <a href="#"><i class="feather-user"></i><?php echo esc_html(ucwords($user->display_name)); ?></a>
                                    <div class="rbt-user-menu-list-wrapper">
                                        <div class="inner">
                                            <?php get_template_part('template-parts/header/user-info'); ?>
                                            <?php get_template_part('template-parts/header/user-page-links'); ?>
                                        </div>
                                    </div>
                                </li>

                                <li class="access-icon rbt-user-wrapper right-align-dropdown d-block d-xl-none">
                                    <a class="rbt-round-btn" href="#"><i class="feather-user"></i></a>
                                    <div class="rbt-user-menu-list-wrapper">
                                        <div class="inner">
                                            <?php get_template_part('template-parts/header/user-info'); ?>
                                            <?php get_template_part('template-parts/header/user-page-links'); ?>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- End Header Top -->

    <div class="rbt-header-wrapper  header-not-transparent header-sticky">
        <div class="container">
            <div class="mainbar-row rbt-navigation-end align-items-center">
                <div class="header-left rbt-header-content">
                    <div class="header-info">
                        <div class="logo">
                            <?php get_template_part('template-parts/header/logo'); ?>
                        </div>
                    </div>
                    <div class="header-info">
                        <div class="rbt-category-menu-wrapper">
                            <div class="rbt-category-btn rbt-side-offcanvas-activation">
                                <div class="rbt-offcanvas-trigger md-size icon">
                                    <span class="d-none d-xl-block">
                                        <i class="feather-grid"></i>
                                    </span>
                                    <i title="Category" class="feather-grid d-block d-xl-none"></i>
                                </div>
                                <span class="category-text d-none d-xl-block">Category</span>
                            </div>

                            <div class="category-dropdown-menu d-none d-xl-block">
                                <div class="category-menu-item">
                                    <div class="rbt-vertical-nav">
                                        <ul class="rbt-vertical-nav-list-wrapper vertical-nav-menu">
                                            <li class="vertical-nav-item active">
                                                <a href="#tab1">Course School</a>
                                            </li>
                                            <li class="vertical-nav-item">
                                                <a href="#tab2">Online School</a>
                                            </li>
                                            <li class="vertical-nav-item">
                                                <a href="#tab3">kindergarten</a>
                                            </li>
                                            <li class="vertical-nav-item">
                                                <a href="#tab4">Classic LMS</a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="rbt-vertical-nav-content">
                                        <!-- Start One Item  -->
                                        <div class="rbt-vertical-inner tab-content" id="tab1" style="display: block">
                                            <div class="rbt-vertical-single">
                                                <div class="row">
                                                    <div class="col-lg-6 col-sm-6 col-6">
                                                        <div class="vartical-nav-content-menu">
                                                            <h3 class="rbt-short-title">Course Title</h3>
                                                            <ul class="rbt-vertical-nav-list-wrapper">
                                                                <li><a href="#">Web Design</a></li>
                                                                <li><a href="#">Art</a></li>
                                                                <li><a href="#">Figma</a></li>
                                                                <li><a href="#">Adobe</a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6 col-sm-6 col-6">
                                                        <div class="vartical-nav-content-menu">
                                                            <h3 class="rbt-short-title">Course Title</h3>
                                                            <ul class="rbt-vertical-nav-list-wrapper">
                                                                <li><a href="#">Photo</a></li>
                                                                <li><a href="#">English</a></li>
                                                                <li><a href="#">Math</a></li>
                                                                <li><a href="#">Read</a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- End One Item  -->

                                        <!-- Start One Item  -->
                                        <div class="rbt-vertical-inner tab-content" id="tab2">
                                            <div class="rbt-vertical-single">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <div class="vartical-nav-content-menu">
                                                            <h3 class="rbt-short-title">Course Title</h3>
                                                            <ul class="rbt-vertical-nav-list-wrapper">
                                                                <li><a href="#">Photo</a></li>
                                                                <li><a href="#">English</a></li>
                                                                <li><a href="#">Math</a></li>
                                                                <li><a href="#">Read</a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="vartical-nav-content-menu">
                                                            <h3 class="rbt-short-title">Course Title</h3>
                                                            <ul class="rbt-vertical-nav-list-wrapper">
                                                                <li><a href="#">Web Design</a></li>
                                                                <li><a href="#">Art</a></li>
                                                                <li><a href="#">Figma</a></li>
                                                                <li><a href="#">Adobe</a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- End One Item  -->

                                        <!-- Start One Item  -->
                                        <div class="rbt-vertical-inner tab-content" id="tab3">
                                            <div class="rbt-vertical-single">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="vartical-nav-content-menu">
                                                            <h3 class="rbt-short-title">Course Title</h3>
                                                            <ul class="rbt-vertical-nav-list-wrapper">
                                                                <li><a href="#">Photo</a></li>
                                                                <li><a href="#">English</a></li>
                                                                <li><a href="#">Math</a></li>
                                                            </ul>
                                                            <div class="read-more-btn">
                                                                <a class="rbt-btn-link" href="#">Learn More<i
                                                                        class="feather-arrow-right"></i></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- End One Item  -->

                                        <!-- Start One Item  -->
                                        <div class="rbt-vertical-inner tab-content" id="tab4">
                                            <div class="rbt-vertical-single">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="vartical-nav-content-menu">
                                                            <h3 class="rbt-short-title">Course Title</h3>
                                                            <ul class="rbt-vertical-nav-list-wrapper">
                                                                <li><a href="#">Photo</a></li>
                                                                <li><a href="#">English</a></li>
                                                                <li><a href="#">Math</a></li>
                                                                <li><a href="#">Read</a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- End One Item  -->

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="rbt-main-navigation d-none d-xl-block">
                    <nav class="mainmenu-nav">
                    <?php get_template_part('template-parts/header/navbar'); ?>
                    </nav>
                </div>
                <div class="header-right">
                    <div class="rbt-btn-wrapper d-none d-xl-block">
                        <a class="rbt-btn rbt-switch-btn btn-gradient btn-sm hover-transform-none" href="<?php echo esc_html__(get_theme_mod('header_campaign_button_link'), 'open-learning'); ?>">
                            <span data-text="Join Now">Join Now</span>
                        </a>
                    </div>
                    <!-- Start Mobile-Menu-Bar -->
                    <div class="mobile-menu-bar d-block d-xl-none">
                        <div class="hamberger">
                            <button class="hamberger-button rbt-round-btn">
                                <i class="feather-menu"></i>
                            </button>
                        </div>
                    </div>
                    <!-- Start Mobile-Menu-Bar -->
                </div>
            </div>
        </div>
    </div>

    <!-- Start Side Vav -->
    <div class="rbt-offcanvas-side-menu rbt-category-sidemenu">
        <div class="inner-wrapper">
            <div class="inner-top">
                <div class="inner-title">
                    <h4 class="title">Course Category</h4>
                </div>
                <div class="rbt-btn-close">
                    <button class="rbt-close-offcanvas rbt-round-btn"><i class="feather-x"></i></button>
                </div>
            </div>
            <nav class="side-nav w-100">
                <ul class="rbt-vertical-nav-list-wrapper vertical-nav-menu">
                    <li class="vertical-nav-item">
                        <a href="#">Course School</a>
                        <div class="vartical-nav-content-menu-wrapper">
                            <div class="vartical-nav-content-menu">
                                <h3 class="rbt-short-title">Course Title</h3>
                                <ul class="rbt-vertical-nav-list-wrapper">
                                    <li><a href="#">Web Design</a></li>
                                    <li><a href="#">Art</a></li>
                                    <li><a href="#">Figma</a></li>
                                    <li><a href="#">Adobe</a></li>
                                </ul>
                            </div>
                            <div class="vartical-nav-content-menu">
                                <h3 class="rbt-short-title">Course Title</h3>
                                <ul class="rbt-vertical-nav-list-wrapper">
                                    <li><a href="#">Photo</a></li>
                                    <li><a href="#">English</a></li>
                                    <li><a href="#">Math</a></li>
                                    <li><a href="#">Read</a></li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="vertical-nav-item">
                        <a href="#">Online School</a>
                        <div class="vartical-nav-content-menu-wrapper">
                            <div class="vartical-nav-content-menu">
                                <h3 class="rbt-short-title">Course Title</h3>
                                <ul class="rbt-vertical-nav-list-wrapper">
                                    <li><a href="#">Photo</a></li>
                                    <li><a href="#">English</a></li>
                                    <li><a href="#">Math</a></li>
                                    <li><a href="#">Read</a></li>
                                </ul>
                            </div>
                            <div class="vartical-nav-content-menu">
                                <h3 class="rbt-short-title">Course Title</h3>
                                <ul class="rbt-vertical-nav-list-wrapper">
                                    <li><a href="#">Web Design</a></li>
                                    <li><a href="#">Art</a></li>
                                    <li><a href="#">Figma</a></li>
                                    <li><a href="#">Adobe</a></li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="vertical-nav-item">
                        <a href="#">kindergarten</a>
                        <div class="vartical-nav-content-menu-wrapper">
                            <div class="vartical-nav-content-menu">
                                <h3 class="rbt-short-title">Course Title</h3>
                                <ul class="rbt-vertical-nav-list-wrapper">
                                    <li><a href="#">Photo</a></li>
                                    <li><a href="#">English</a></li>
                                    <li><a href="#">Math</a></li>
                                    <li><a href="#">Read</a></li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="vertical-nav-item">
                        <a href="#">Classic LMS</a>
                        <div class="vartical-nav-content-menu-wrapper">
                            <div class="vartical-nav-content-menu">
                                <h3 class="rbt-short-title">Course Title</h3>
                                <ul class="rbt-vertical-nav-list-wrapper">
                                    <li><a href="#">Web Design</a></li>
                                    <li><a href="#">Art</a></li>
                                    <li><a href="#">Figma</a></li>
                                    <li><a href="#">Adobe</a></li>
                                </ul>
                            </div>
                        </div>
                    </li>
                </ul>
                <div class="read-more-btn">
                    <div class="rbt-btn-wrapper mt--20">
                        <a class="rbt-btn btn-border-gradient radius-round btn-sm hover-transform-none w-100 justify-content-center text-center"
                            href="#">
                            <span>Learn More</span>
                        </a>
                    </div>
                </div>
            </nav>
            <div class="rbt-offcanvas-footer">

            </div>
        </div>
    </div>
    <!-- End Side Vav -->
    <a class="rbt-close_side_menu" href="javascript:void(0);"></a>
</header>
<!-- Mobile Menu Section -->
<div class="popup-mobile-menu">
    <div class="inner-wrapper">
        <div class="inner-top">
            <div class="content">
                <div class="logo">
                    <a href="index.html">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo/logo.png" alt="Education Logo Images">
                    </a>
                </div>
                <div class="rbt-btn-close">
                    <button class="close-button rbt-round-btn"><i class="feather-x"></i></button>
                </div>
            </div>
            <p class="description">Histudy is a education website template. You can customize all.</p>
            <ul class="navbar-top-left rbt-information-list justify-content-start">
                <li>
                    <a href="mailto:hello@example.com"><i class="feather-mail"></i>example@gmail.com</a>
                </li>
                <li>
                    <a href="#"><i class="feather-phone"></i>(302) 555-0107</a>
                </li>
            </ul>
        </div>

        <nav class="mainmenu-nav">
           <?php get_template_part('template-parts/header/navbar'); ?>
        </nav>

        <div class="mobile-menu-bottom">
            <div class="rbt-btn-wrapper mb--20">
                <a class="rbt-btn btn-border-gradient radius-round btn-sm hover-transform-none w-100 justify-content-center text-center"
                    href="#">
                    <span>Enroll Now</span>
                </a>
            </div>

            <div class="social-share-wrapper">
                <span class="rbt-short-title d-block">Find With Us</span>
                <ul class="social-icon social-default transparent-with-border justify-content-start mt--20">
                    <li><a href="https://www.facebook.com/">
                            <i class="feather-facebook"></i>
                        </a>
                    </li>
                    <li><a href="https://www.twitter.com">
                            <i class="feather-twitter"></i>
                        </a>
                    </li>
                    <li><a href="https://www.instagram.com/">
                            <i class="feather-instagram"></i>
                        </a>
                    </li>
                    <li><a href="https://www.linkdin.com/">
                            <i class="feather-linkedin"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php if(class_exists('WooCommerce')): ?>
<div class="rbt-cart-side-menu">
    <div class="inner-wrapper">
        <div class="inner-top">
            <div class="content">
                <div class="title">
                    <h4 class="title mb--0"><?php _e('Your shopping cart', 'open-learning'); ?></h4>
                </div>
                <div class="rbt-btn-close" id="btn_sideNavClose">
                    <button class="minicart-close-button rbt-round-btn"><i class="feather-x"></i></button>
                </div>
            </div>
        </div>
        <?php wc_get_template('cart/mini-cart.php'); ?>
    </div>
</div>
<a class="close_side_menu" href="javascript:void(0);"></a>
<?php endif; ?>