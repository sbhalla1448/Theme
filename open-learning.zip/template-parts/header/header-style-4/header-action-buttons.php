<?php
/**
 * Header 4 Actions Buttons
 */
?>

<ul>
    <li class="header-search">
        <a href="#" data-toggle="modal" data-target="#search-modal"><i class="flaticon-search"></i></a>
    </li>
    <li class="header-profile">
        <a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>"><i class="flaticon-user"></i></a>
    </li>
    <?php if( class_exists('woocommerce') ): ?>
        <?php if(get_theme_mod('wishlist_icon', 0) && defined('YITH_WCWL')): ?>
        <li class="wish-list"><a href="<?php echo home_url('/wishlist/'); ?>"><i class="flaticon-heart-shape-outline"></i></a></li>
        <?php endif; ?>
        <li class="header-shop-cart">
            <a href="#">
                <i class="flaticon-shopping-bag"></i>
                <span><?php echo WC()->cart->get_cart_contents_count(); ?></span>
            </a>
            <?php get_template_part('template-parts/header/cart'); ?>
        </li>
    <?php endif; ?>
    <li class="sidebar-toggle-btn">
        <a href="#" class="navSidebar-button">
            <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-list" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z"/>
            </svg>
        </a>
    </li>
</ul>