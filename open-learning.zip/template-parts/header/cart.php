<?php
/**
 * Cart
 */


 wc_get_template('cart/mini-cart.php');
?>

