<?php
    $user_id                   = get_current_user_id();
    $user                      = get_user_by( 'ID', $user_id );
    $profile_photo_id          = get_user_meta( $user_id, '_tutor_profile_photo', true);
    $placeholder_img           = function_exists('tutor')? tutor()->url . 'assets/images/placeholder.svg' : '';
    $profile_photo_url         = wp_get_attachment_image_url( $profile_photo_id, 'full' )? wp_get_attachment_image_url( $profile_photo_id, 'full' ) : $placeholder_img;
    $profile_url               = function_exists('tutor_utils')? tutor_utils()->profile_url( $user_id, true ) : '#';
?>
<div class="rbt-admin-profile">
    <div class="admin-thumbnail">
        <img src="<?php echo esc_url($profile_photo_url); ?>" alt="<?php echo esc_html(ucwords($user->display_name)); ?>">
    </div>
    <div class="admin-info">
        <span class="name"><?php echo esc_html(ucwords($user->display_name)); ?></span>
        <a class="rbt-btn-link color-primary" href="<?php echo esc_url($profile_url); ?>"><?php _e('View Profile', 'open-learning'); ?></a>
    </div>
</div>