<?php
/**
 * Categgories
 */
?>
<div class="header-category d-none d-lg-block">
    <a href="#" class="cat-toggle"><i class="fas fa-bars"></i><?php echo esc_html__('ALL CATEGORIES', 'open-learning'); ?></a>
    <?php
    if(class_exists('woocommerce')){
        $args = array(
            'hierarchical' => 1,
            'show_option_none' => '',
            'hide_empty'    => true,
            'taxonomy'      => 'product_cat',
            'parent'        => 0
        );
    }else{
        $args = array(
            'hide_empty'    => true,
            'parent'        => 0
        );
    }
    
    $categories = get_terms( $args );
    ?>
    <ul class="category-menu">
        <?php foreach( $categories as $category ): ?>
        <?php
            if(class_exists('woocommerce')){
                $child_args = array(
                    'hierarchical' => 1,
                    'show_option_none' => '',
                    'hide_empty' => 0,
                    'taxonomy'      => 'product_cat',
                    'parent'        => $category->term_id
                );
            }else{
                $child_args = array(
                    'parent'        => $category->term_id
                );
            }
            
            $child_categories = get_terms( $child_args );
        ?>
        <?php if($child_categories): ?>
        <li class="has-dropdown"><a href="<?php echo get_term_link($category->term_id); ?>"><?php echo esc_html( $category->name ); ?></a>
            <ul class="cat-mega-menu">
                <?php foreach( $child_categories as $child_category ): ?>
                <li>
                    <a href="<?php echo get_term_link($child_category->term_id); ?>"><?php echo esc_html( $child_category->name ); ?></a>
                </li>
                <?php endforeach; ?>
            </ul>
        </li>
        <?php else: ?>
        <li><a href="<?php echo get_term_link($category->term_id); ?>"><?php echo esc_html( $category->name ); ?></a></li>
        <?php endif; ?>
        <?php endforeach; ?>
    </ul>
</div>