<?php
/**
 * Logo
 */
 ?>

<?php if(!get_theme_mod( 'main_logo')):?>
    <h2><a href="<?php echo site_url('/'); ?>" class="main-logo"><?php bloginfo( 'name' ); ?></a></h2>
<?php else:
    $logo = get_theme_mod( 'custom_logo' );
    $logo_url = wp_get_attachment_image_url( $logo, 'large' );
    if(!$logo_url){
        $logo       = get_theme_mod( 'main_logo' );
        $logo_url   = wp_get_attachment_image_url( $logo, 'large' );
        echo '<a href="'.site_url('/').'"  class="main-logo"><img src="'.esc_url( $logo_url ).'" alt="'.get_bloginfo( 'name' ).'"></a>';
    }else{
        echo '<a href="'.site_url('/').'"  class="main-logo"><img src="'.esc_url( $logo_url ).'" alt="'.get_bloginfo( 'name' ).'"></a>';
    }
    
    endif;
?>