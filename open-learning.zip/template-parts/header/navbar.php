<?php
/**
 * Navbar
 */
?>

<?php 
    wp_nav_menu( array(
        'menu'          => 'main_menu',
        'theme_location'=> 'main_menu',
        'menu_class'    => 'mainmenu',
        'container'     => 'ul',
        'walker'        => new OLC_Menu_Walker()
    ));
?>