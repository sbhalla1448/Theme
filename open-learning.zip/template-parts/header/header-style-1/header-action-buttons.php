<?php
/**
 * Header 1 Action Buttons
 */
?>

<div class="header-action d-none d-md-block">
    <ul>
        <?php if(class_exists( 'woocommerce' ) && get_theme_mod( 'header_shipping_offer_text_hideshow', 0 )): ?>
        <li class="shipping-offer" id="header_shipping_offer_text"><?php echo wp_kses_post( get_theme_mod('header_shipping_offer_text', 'Free Shipping on Orders <span>$39+</span>') ); ?></li>
        <?php endif; ?>
        <li class="header-search"><a href="#" data-toggle="modal"
                data-target="#search-modal"><i
                    class="flaticon-search-interface-symbol"></i></a></li>
        <?php if(get_theme_mod('header_offcanvas', 0)): ?>
        <li class="sidebar-toggle-btn"><a href="#" class="navSidebar-button"><img
                    src="<?php echo get_template_directory_uri(); ?>/assets/img/icon/sidebar_toggle_icon.png" alt="<?php bloginfo('name'); ?>"></a></li>
        <?php endif; ?>
    </ul>
</div>