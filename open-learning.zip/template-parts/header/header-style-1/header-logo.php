<?php

/**
 * Header 1 logo
 */

?>

<div class="logo d-block d-lg-none" id="header-logo">
    <?php if(get_theme_mod('secondary_logo')): ?>
        <a href="<?php echo home_url('/'); ?>" class="main-logo"><img src="<?php echo esc_url( get_theme_mod('secondary_logo') ); ?>" alt="<?php bloginfo('name'); ?>"></a>
    <?php else: ?>
        <h2><a href="<?php echo home_url('/'); ?>" class="main-logo text-white"><?php bloginfo( 'name' ); ?></a></h2>
    <?php endif; ?>
    
    <?php if(!has_custom_logo() ):?>
        <h2><a href="<?php echo home_url('/'); ?>" class="sticky-logo"><?php bloginfo( 'name' ); ?></a></h2>
    <?php else:
        $logo = get_theme_mod( 'custom_logo' );
        $logo_url = wp_get_attachment_image_url( $logo, 'large' );
        if(!$logo_url){
            $logo_url = get_theme_mod( 'main_logo', esc_url(get_theme_file_uri('/assets/img/logo/logo.png')) );
        }
        echo sprintf(
            '<a href="%1$s"  class="sticky-logo"><img src="%2$s" alt="%3$s"></a>',
            home_url('/'),
            esc_url( $logo_url ),
            get_bloginfo( 'name' )
        );
        endif;
    ?>
</div>