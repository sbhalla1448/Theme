<?php
/**
 * Header Top
 */

?>
<div class="header-top-wrap">
    <div class="container custom-container">
        <div class="row align-items-center justify-content-center">
            <div class="col-xl-3 col-lg-4 d-none d-lg-block">
                <div class="logo">
                    <?php get_template_part('template-parts/header/logo'); ?>
                </div>
            </div>
            <div class="col-xl-6 col-lg-5 col-md-6">
                <?php if(class_exists( 'woocommerce' ) && get_theme_mod( 'header_top_offer_text_hideshow', 0 )): ?>
                <div class="header-top-offer">
                    <p id="header_offer_text"><?php echo wp_kses_post(get_theme_mod( 'header_top_offer_text', 'SUMMER SALE UP TO <span>70% OFF.</span> SHOP NOW' )); ?></p>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="header-top-action">
                    <ul>
                        <?php if(!is_user_logged_in()):?>
                            <li class="sign-in">
                                <?php if(class_exists( 'woocommerce' )): ?>
                                    <a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>"><?php echo esc_html__('Sign In', 'open-learning'); ?></a>
                                <?php else: ?>
                                    <a href="<?php echo admin_url('/'); ?>"><?php echo esc_html__('Sign In', 'open-learning'); ?></a>
                                <?php endif; ?>
                            </li>
                        <?php else: ?>
                            <li>
                                <?php
                                    $avatar = get_avatar(get_current_user_id());
                                    $avatar_url = get_avatar_url(get_current_user_id());
                                ?>
                                <?php if(class_exists( 'woocommerce' )): ?>
                                    <a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>" class="avatar-img">
                                        <?php echo wp_kses_post( $avatar ); ?>
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo admin_url('/'); ?>" class="avatar-img">
                                        <?php echo wp_kses_post( $avatar ); ?>
                                    </a>
                                <?php endif; ?>
                                
                            </li>
                        <?php endif; ?>
                        <?php if(class_exists( 'woocommerce' )): ?>
                            <?php if(get_theme_mod('wishlist_icon', 0) && defined('YITH_WCWL')): ?>
                            <li class="wish-list"><a href="<?php echo home_url('/wishlist/'); ?>"><i class="flaticon-heart-shape-outline"></i></a></li>
                            <?php endif; ?>
                            <?php if(get_theme_mod('wishlist_icon') && defined('YITH_WCWL')): ?>
                            <li class="header-shop-cart">
                            <?php else: ?>
                            <li class="header-shop-cart actions-separator">
                            <?php endif; ?>
                                <a href="#" class="cart-count">
                                    <i class="flaticon-shopping-bag"></i>
                                    <span><?php echo WC()->cart->get_cart_contents_count(); ?></span>
                                </a>
                                <?php get_template_part( 'template-parts/header/cart' ); ?>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>