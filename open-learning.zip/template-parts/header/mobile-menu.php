<?php
/**
 * Mobile Menu
 */
?>

<div class="mobile-menu">
    <div class="close-btn">
        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16">
            <path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"/>
        </svg>
    </div>
    <nav class="menu-box">
        <div class="nav-logo">
            <?php get_template_part('template-parts/header/logo'); ?>
        </div>
        <div class="menu-outer">
          <?php get_template_part('template-parts/header/navbar'); ?>
        </div>
        <?php if(get_theme_mod('footer_socials', 1)):?>
        <div class="social-links">
            <ul class="clearfix">
                <?php if(!empty(get_theme_mod('facebook_link'))): ?>
                <li><a href="<?php echo esc_attr(get_theme_mod('facebook_link', '#')); ?>"><span class="fab fa-facebook-square"></span></a></li>
                <?php endif; ?>
                <?php if(!empty(get_theme_mod('twitter_link'))): ?>
                <li><a href="<?php echo esc_attr(get_theme_mod('twitter_link', '#')); ?>"><<span class="fab fa-twitter"></span></i></a></li>
                <?php endif; ?>
                <?php if(!empty(get_theme_mod('youtube_link'))): ?>
                <li><a href="<?php echo esc_attr(get_theme_mod('youtube_link', '#')); ?>"><span class="fab fa-youtube"></span></a></li>
                <?php endif; ?>
                <?php if(!empty(get_theme_mod('instagram_link'))): ?>
                <li><a href="<?php echo esc_attr(get_theme_mod('instagram_link', '#')); ?>"><span class="fab fa-instagram"></span></a></li>
                <?php endif; ?>
                <?php if(!empty(get_theme_mod('linkedin_link'))): ?>
                <li><a href="<?php echo esc_attr(get_theme_mod('linkedin_link', '#')); ?>"><i class="fab fa-linkedin-in"></i></a></li>
                <?php endif; ?>
            </ul>
        </div>
        <?php endif; ?>
    </nav>
</div>
<div class="menu-backdrop"></div>