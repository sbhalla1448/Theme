<?php
/**
 * 
 * Footer Socials
 * @package OLC
 * @version 1.0.0
 * 
 */

 ?>

<?php if(get_theme_mod('footer_socials', 0)):?>

<div class="footer-social" id="footer-social-links">
    <?php do_action('adara_social_links'); ?>
</div>
<?php endif; ?>