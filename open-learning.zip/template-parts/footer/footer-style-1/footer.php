<?php
/**
 * Footer Style 1
 */

$footer_logo        = get_theme_mod('footer_logo', esc_url( get_theme_file_uri('/assets/images/logo/logo.png') ));
$footer_logo_url    = wp_get_attachment_image_url($footer_logo, 'full');
$footer_text        = get_theme_mod('footer_text', 'We’re always in search for talented and motivated people. Don’t be shy introduce yourself!');
$footer_button_text = get_theme_mod('footer_button_text', esc_html__('Contact With Us', 'open-learning'));
$footer_button_link = get_theme_mod('footer_button_link');
$footer_copyright   = get_theme_mod('footer_copyright', 'Copyright © 2023 <a href="https://themeforest.net/user/rbt-themes">Rainbow-Themes.</a> All Rights Reserved');
?>

<!-- Start Footer aera -->
<footer class="rbt-footer footer-style-1">
    <div class="footer-top">
        <div class="container">
            <div class="row row--15 mt_dec--30">
                <div class="col-lg-4 col-md-6 col-sm-6 col-12 mt--30">
                    <div class="footer-widget">
                        <div class="logo">
                            <a href="<?php echo home_url('/'); ?>">
                                <?php if($footer_logo_url): ?>
                                <img src="<?php echo esc_url($footer_logo_url); ?>" alt="Edu-cause">
                                <?php else: ?>
                                    <h3><?php echo bloginfo('name'); ?></h3>
                                <?php endif; ?>
                            </a>
                        </div>

                        <p class="description mt--20"><?php echo esc_html__($footer_text, 'open-learning'); ?></p>

                        <div class="contact-btn mt--30">
                            <a class="rbt-btn hover-icon-reverse btn-border-gradient radius-round" href="<?php echo esc_url($footer_button_link); ?>">
                                <div class="icon-reverse-wrapper">
                                    <span class="btn-text"><?php echo esc_html__($footer_button_text, 'open-learning'); ?></span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-2 col-md-6 col-sm-6 col-12 mt--30">
                    <?php
                        if(is_active_sidebar( 'footer-1-column-2' )){
                            dynamic_sidebar('footer-1-column-2'); 
                        }
                    ?>
                </div>

                <div class="col-lg-2 col-md-6 col-sm-6 col-12 mt--30">
                    <?php
                        if(is_active_sidebar( 'footer-1-column-3' )){
                            dynamic_sidebar('footer-1-column-3'); 
                        }
                    ?>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-6 col-12 mt--30">
                    <?php
                        if(is_active_sidebar( 'footer-1-column-4' )){
                            dynamic_sidebar('footer-1-column-4'); 
                        }
                    ?>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- End Footer aera -->
<div class="rbt-separator-mid">
    <div class="container">
        <hr class="rbt-separator m-0">
    </div>
</div>
<!-- Start Copyright Area  -->
<div class="copyright-area copyright-style-1 ptb--20">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-12 col-12">
                <p class="rbt-link-hover text-center text-lg-start"><?php echo $footer_copyright; ?></p>
            </div>
            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-12 col-12">
                <?php
                    $items = array();
                    if( get_theme_mod('footer_menu') != -1 ){
                        $items = wp_get_nav_menu_items(get_theme_mod('footer_menu'));
                    }
                ?>
                <ul
                    class="copyright-link rbt-link-hover justify-content-center justify-content-lg-end mt_sm--10 mt_md--10">
                    <?php if( !empty($items) && !is_null($items) ): 
                        foreach( $items as $item ):    
                    ?>
                    <li><a href="<?php echo esc_url($item->url); ?>"><?php echo esc_html($item->title); ?></a></li>
                    <?php
                        endforeach;
                    endif;
                    ?>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- End Copyright Area  -->