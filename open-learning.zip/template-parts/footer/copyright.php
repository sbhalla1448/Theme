<?php
/**
 * 
 * Copyright
 */

$footer_style = function_exists('get_field') ? get_field('footer_styles') : '';
?>
<div class="copyright-wrap <?php echo (get_theme_mod('footer_styles') == 'footer_3' || $footer_style == 'footer_3') ? 'gray-light-bg' : ''; ?>">
    <?php if(get_theme_mod('footer_styles') == 'footer_2' || $footer_style == 'footer_2' ||  $footer_style == 'footer_3'): ?>
    <div class="container">
    <?php endif; ?>
        <div class="row align-items-center">
            <div class="col-lg-6 <?php echo !empty(get_theme_mod('payment_methods')) && class_exists('woocommerce') ? '' : 'm-auto text-center'; ?>">
                <div class="copyright-text">
                    <p id="footer_copyright_text"><?php echo wp_kses(get_theme_mod('footer_copyright_text', wp_kses_post('&copy; 2022 <a href="/">adara</a>. All Rights Reserved | Ph (+09) 456 457869')), array(
                        'a' => array(
                            'href' => array(),
                            'title' => array()
                        ),
                        'br' => array(),
                        'em' => array(),
                        'strong' => array(),
                    )); ?></p>
                </div>
            </div>
            <?php if(!empty(get_theme_mod('payment_methods')) && class_exists('woocommerce')):?>
            <div class="col-lg-6">
                <div class="pay-method-img" id="payment-img">
                    <img src="<?php echo esc_url(get_theme_mod('payment_methods', esc_url(get_theme_file_uri( '/assets/img/images/payment_method_img.png' )))); ?>" alt="payments">
                </div>
            </div>
            <?php endif; ?>
        </div>
    <?php if(get_theme_mod('footer_styles') == 'footer_2' || $footer_style == 'footer_2' ||  $footer_style == 'footer_3'): ?>
    </div>
    <?php endif; ?>
</div>