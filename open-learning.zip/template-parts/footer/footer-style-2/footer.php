<?php
/**
 * Footer Style 2
 */
?>
<div class="footer-style-2 ptb--60 bg-color-white">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-between">
            <div class="col-lg-12">
                <div class="inner text-center">

                    <div class="logo">
                        <a href="index.html">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo/logo.png" alt="Logo images">
                        </a>
                    </div>
                    <!-- Social icone Area -->
                    <ul class="social-icon social-default">
                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                    </ul>
                    <!-- End -->
                    <div class="text mt--20">
                        <p>© 2023 <a target="_blank"
                                href="https://themeforest.net/user/rbt-themes/portfolio">Rainbow-Themes</a>. All
                            Rights Reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>