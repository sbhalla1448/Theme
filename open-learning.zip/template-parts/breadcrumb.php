<?php
/*
 * Breadcrumbs For All Pages 
 * 
 */
global $post;
?>

<?php if(is_search()): ?>
    <!-- breadcrumb-area -->
    <?php if(get_theme_mod( 'breadcrumb_bg' ) != ''): ?>
    <section class="breadcrumb-area breadcrumb-bg" data-background="<?php echo get_theme_mod( 'breadcrumb_bg' ); ?>">
    <?php else: ?>
    <section class="breadcrumb-area breadcrumb-bg">
    <?php endif; ?>
    
    	<div class="container">
    		<div class="row">
    			<div class="col-12">
    				<div class="breadcrumb-content">
    					<h2>
    						<?php
    							printf(
    								/* translators: %s: Search term. */
    								esc_html__( 'Results for "%s"', 'open-learning' ),
    								'<span class="page-description search-term">' . esc_html( get_search_query() ) . '</span>'
    							);
    						?>
    					</h2>
    					<nav aria-label="breadcrumb">
    						<ol class="breadcrumb">
    							<li class="breadcrumb-item"><a href="<?php echo site_url('/'); ?>"><?php echo esc_html__('Home', 'open-learning'); ?></a></li>
    							<li class="breadcrumb-item active" aria-current="page"><?php echo esc_html__('Blog', 'open-learning'); ?></li>
    						</ol>
    					</nav>
    				</div>
    			</div>
    		</div>
    	</div>
    </section>
    <!-- breadcrumb-area-end -->

<?php elseif(is_category()): ?>

    <!-- breadcrumb-area -->
    <?php if(get_theme_mod( 'breadcrumb_bg' ) != ''): ?>
	<section class="breadcrumb-area breadcrumb-bg" data-background="<?php echo get_theme_mod( 'breadcrumb_bg' ); ?>">
	<?php else: ?>
	<section class="breadcrumb-area breadcrumb-bg">
	<?php endif; ?>
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb-content">
                        <h2 class="text-capitalize"><?php single_cat_title( esc_html__('Category: ', 'open-learning') ); ?></h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo site_url('/'); ?>"><?php echo esc_html__('Home', 'open-learning'); ?></a></li>
                                <li class="breadcrumb-item active" aria-current="page"><?php single_cat_title(); ?></li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb-area-end -->
    
<?php elseif(is_archive()): ?>

    <!-- breadcrumb-area -->
	<?php if(get_theme_mod( 'breadcrumb_bg' ) != ''): ?>
	<section class="breadcrumb-area breadcrumb-bg" data-background="<?php echo get_theme_mod( 'breadcrumb_bg' ); ?>">
	<?php else: ?>
	<section class="breadcrumb-area breadcrumb-bg">
	<?php endif; ?>

		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="breadcrumb-content">
						<?php the_archive_title( '<h2>', '</h2>' ); ?>
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?php echo site_url('/'); ?>"><?php echo esc_html__('Home', 'open-learning'); ?></a></li>
								<li class="breadcrumb-item active" aria-current="page"><?php echo esc_html__('Blog', 'open-learning'); ?></li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- breadcrumb-area-end -->
<?php elseif(is_singular() && is_single() && get_post_type() === 'post'): ?>
    <!-- breadcrumb-area -->
	<?php if(get_theme_mod( 'breadcrumb_bg' ) != ''): ?>
	<section class="breadcrumb-area breadcrumb-bg" data-background="<?php echo get_theme_mod( 'breadcrumb_bg' ); ?>">
	<?php else: ?>
	<section class="breadcrumb-area breadcrumb-bg">
	<?php endif; ?>
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="breadcrumb-content">
						<?php
							if(is_singular() && is_single() && get_post_type() === 'post'){
								$category = get_the_category();
								echo '<div class="tag"><a href="'.get_category_link( $category[0] ).'">'.$category[0]->name.'</a></div>';
							}
						?>
						<h2><?php single_post_title(); ?></h2>
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?php echo site_url('/'); ?>"><?php echo esc_html__( 'Home', 'open-learning' ); ?></a></li>
								<li class="breadcrumb-item active" aria-current="page"><?php single_post_title(); ?></li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- breadcrumb-area-end -->
<?php elseif(is_page()): ?>
    <!-- breadcrumb-area -->
	<?php if(get_the_post_thumbnail_url($post->ID, 'full')): ?>
	<section class="breadcrumb-area breadcrumb-bg" data-background="<?php echo esc_url(get_the_post_thumbnail_url($post->ID, 'full')); ?>">
	<?php else: ?>
	<section class="breadcrumb-area breadcrumb-bg">
	<?php endif; ?>
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="breadcrumb-content">
						<h2><?php single_post_title(); ?></h2>
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?php echo site_url('/'); ?>"><?php echo esc_html__( 'Home', 'open-learning' ); ?></a></li>
								<li class="breadcrumb-item active" aria-current="page"><?php single_post_title(); ?></li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- breadcrumb-area-end -->
<?php else: ?>
    <!-- breadcrumb-area -->
	<?php if(get_theme_mod( 'breadcrumb_bg' ) != ''): ?>
	<section class="breadcrumb-area breadcrumb-bg" data-background="<?php echo get_theme_mod( 'breadcrumb_bg' ); ?>">
	<?php else: ?>
	<section class="breadcrumb-area breadcrumb-bg">
	<?php endif; ?>

		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="breadcrumb-content">
						<h2><?php echo get_theme_mod( 'breadcrumb_title', esc_html__( 'Our Blog', 'open-learning' ) ); ?></h2>
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?php echo site_url('/'); ?>"><?php echo esc_html__('Home', 'open-learning'); ?></a></li>
								<li class="breadcrumb-item active" aria-current="page"><?php echo esc_html__('Blog', 'open-learning'); ?></li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- breadcrumb-area-end -->
	
<?php endif; ?>
