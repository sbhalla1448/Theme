<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package OLC
 */

global $post;

?>
<?php if( is_home() || is_archive() || is_category() ): ?>
<!-- Start Single Card  -->
<div class="col-lg-6 col-md-6 col-12">
    <div <?php post_class('rbt-blog-grid rbt-card variation-02 rbt-hove'); ?>>
        <?php if(has_post_thumbnail()): ?>
        <div class="rbt-card-img">
            <a href="<?php echo get_the_permalink(); ?>">
                <?php the_post_thumbnail('full'); ?>
            </a>
        </div>
        <?php endif; ?>
        <div class="rbt-card-body">
            <h5 class="rbt-card-title">
                <a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a>
            </h5>

            <ul class="blog-meta">
                <li><i class="feather-user"></i> <?php echo get_the_author_link(); ?></li>
                <li><i class="feather-clock"></i> <?php echo get_the_date(); ?> </li>
            </ul>
            <p class="rbt-card-text"><?php echo wp_trim_words( get_the_excerpt(), 20 ); ?></p>
            <div class="rbt-card-bottom">
                <a class="transparent-button" href="<?php echo get_the_permalink(); ?>">
                <?php echo esc_html__( 'Learn More', 'open-learning' ); ?>
                <i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i>
                </a>
            </div>
        </div>
    </div>
</div>
<!-- End Single Card  -->
<?php elseif( is_singular() && is_single() && get_post_type() === 'post' ): ?>
    <div class="rbt-blog-details-area rbt-section-gapBottom breadcrumb-style-max-width">
        <div class="blog-content-wrapper rbt-article-content-wrapper">
            <div class="content">
                <div class="post-thumbnail mb--30 position-relative wp-block-image alignwide">
                    <figure>
                        <?php 
                        if(the_post_thumbnail('full') != NULL):
                            the_post_thumbnail('full');
                        endif; 
                        ?>
                        <figcaption><?php echo get_the_excerpt(); ?></figcaption>
                    </figure>
                </div>
                <?php the_content(); ?>

                <!-- BLog Tag Clound  -->
                <div class="tagcloud">
                    <?php $tags = get_the_tags(); ?>
                    <?php
                        if( !empty($tags) ){
                            $tags_html = ''; 
                            foreach( $tags as $tag ){
                                echo '<a href="'.get_term_link($tag->term_id).'">'.$tag->name.'</a>';
                            }
                        }
                    ?>
                </div>

                <!-- Blog Author  -->
                <div class="about-author">
                    <div class="media">
                        <div class="thumbnail">
                            <a href="#">
                                <?php echo wp_kses_post(get_avatar(get_the_author_meta( 'ID' ))); ?>
                            </a>
                        </div>
                        <div class="media-body">
                            <div class="author-info">
                                <h5 class="title">
                                    <a class="hover-flip-item-wrapper" href="#">
                                        <?php echo esc_html(ucwords(get_the_author())); ?>
                                    </a>
                                </h5>
                                <span class="b3 subtitle">Author Designations</span>
                            </div>
                            <div class="content">
                                <p class="description"><?php echo esc_html(get_the_author_meta('description')); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                    // If comments are open or we have at least one comment, load up the comment template.
                    if ( comments_open() || get_comments_number() ){
                        comments_template();
                        if($post->comment_status === 'closed'){
                            echo wp_kses_post( '<strong class="mt-30 text-muted d-block">Comments closed!</strong>' );
                        }
                    }else{
                        echo wp_kses_post( '<strong class="mt-30 text-muted d-block">Comments disabled!</strong>' );
                    }
                ?>
            </div>
            <div class="related-post pt--60">
                <div class="section-title text-start mb--40">
                    <span class="subtitle bg-primary-opacity">Related Post</span>
                    <h4 class="title"><?php _e('Similar Post', 'open-learning'); ?></h4>
                </div>
                <?php
                    $tags = wp_get_post_terms( get_queried_object_id(), 'post_tag', array('fields' => 'ids'));
                    $query_args = array(
                        'post__not_in'        => array( get_queried_object_id() ),
                        'post_status'         => 'publish',
                        'posts_per_page'      => 3,
                        'ignore_sticky_posts' => 1,
                        'orderby'             => 'rand',
                        'tax_query'           => array(
                            array(
                                'taxonomy' => 'post_tag',
                                'terms'    => $tags
                            )
                        )
                    );

                    $related_posts = new WP_Query($query_args);
                    if($related_posts->have_posts()):
                ?>
                <?php while($related_posts->have_posts()): $related_posts->the_post(); ?>
                <!-- Start Single Card  -->
                <div class="rbt-card card-list variation-02 rbt-hover mt--30">
                    <div class="rbt-card-img">
                        <a href="<?php the_permalink(); ?>">
                            <img src="<?php echo wp_get_attachment_image_url(get_post_thumbnail_id(), 'full'); ?>" alt="<?php echo esc_html(get_the_title()); ?>"> 
                        </a>
                    </div>
                    <div class="rbt-card-body">
                        <h5 class="rbt-card-title"><a href="<?php the_permalink(); ?>"><?php echo esc_html(get_the_title()); ?></a>
                        </h5>
                        <div class="rbt-card-bottom">
                            <a class="transparent-button" href="<?php the_permalink(); ?>">
                                <?php _e('Read Article', 'open-learning'); ?>
                                <i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg">
                                        <g stroke="#27374D" fill="none" fill-rule="evenodd">
                                            <path d="M10.614 0l5.629 5.629-5.63 5.629" />
                                            <path stroke-linecap="square" d="M.663 5.572h14.594" />
                                        </g>
                                    </svg>
                                </i>
                            </a>
                        </div>
                    </div>
                </div>
                <!-- End Single Card  -->
                <?php endwhile; wp_reset_postdata(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php else: ?>
<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div class="entry-content">
        <?php the_content(); ?>
        <?php
            wp_link_pages( array(
                'before'      => '<div class="page-links">' . esc_html__( 'Pages:', 'open-learning' ),
                'after'       => '</div>',
                'link_before' => '<span class="page-number">',
                'link_after'  => '</span>',
            ) );
        ?>
    </div><!-- .entry-content -->
</div><!-- #post-<?php the_ID(); ?> -->
<?php endif; ?>