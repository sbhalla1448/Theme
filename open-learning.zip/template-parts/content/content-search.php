<?php
/**
 * Template part for displaying results in search pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package OLC
 */

?>
<div id="post-<?php the_ID(); ?>" <?php post_class('blog--post--item text-center'); ?>>
    <?php if(has_post_thumbnail()): ?>
    <div class="blog-post-thumb mb-35">
        <a href="<?php echo get_the_permalink(); ?>"><?php the_post_thumbnail('large'); ?></a>
    </div>
    <?php endif; ?>
    <div class="blog-post-content">
        <?php 
            $categories = get_the_category(get_the_ID());
            if( !empty($categories) ): 
        ?>
        <div class="tag"><a
                href="<?php echo get_category_link($categories[0]->cat_ID); ?>"><?php echo esc_html($categories[0]->name); ?></a>
        </div>
        <?php endif; ?>
        <h3 class="single-blog-title"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h3>
        <?php if(get_post_type() != 'product'): ?>
        <div class="blog-post-meta">
            <ul>
                <li><i class="far fa-user"></i><?php echo printf('By %s', get_the_author_link()); ?></li>
                <li><i class="far fa-calendar-alt"></i> <?php echo get_the_date(); ?></li>
            </ul>
        </div>
        <?php endif; ?>
        <p class="post-excerpt"><?php echo get_the_excerpt(); ?></p>
        <?php if(get_post_type() != 'product'): ?>
        <a href="<?php echo get_the_permalink(); ?>"><?php echo esc_html__('Read More', 'open-learning'); ?></a>
        <?php endif; ?>
    </div>
</div>
