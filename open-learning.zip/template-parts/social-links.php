<?php
/**
 * Socials Links
 * 
 */

 ?>

<ul>
    <?php if(!empty(get_theme_mod('facebook_link', '#'))): ?>
    <li><a href="<?php echo esc_attr(get_theme_mod('facebook_link', '#')); ?>"><i class="fab fa-facebook-f"></i></a></li>
    <?php endif; ?>
    <?php if(!empty(get_theme_mod('twitter_link', '#'))): ?>
    <li><a href="<?php echo esc_attr(get_theme_mod('twitter_link', '#')); ?>"><i class="fab fa-twitter"></i></a></li>
    <?php endif; ?>
    <?php if(!empty(get_theme_mod('youtube_link', '#'))): ?>
    <li><a href="<?php echo esc_attr(get_theme_mod('youtube_link', '#')); ?>"><i class="fab fa-youtube"></i></a></li>
    <?php endif; ?>
    <?php if(!empty(get_theme_mod('instagram_link', '#'))): ?>
    <li><a href="<?php echo esc_attr(get_theme_mod('instagram_link', '#')); ?>"><i class="fab fa-instagram"></i></a></li>
    <?php endif; ?>
    <?php if(!empty(get_theme_mod('linkedin_link', '#'))): ?>
    <li><a href="<?php echo esc_attr(get_theme_mod('linkedin_link', '#')); ?>"><i class="fab fa-linkedin-in"></i></a></li>
    <?php endif; ?>
</ul>