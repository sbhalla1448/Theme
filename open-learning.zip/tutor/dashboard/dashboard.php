<?php
/**
 * Frontend Dashboard Template
 *
 * @package Tutor\Templates
 * @subpackage Dashboard
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.4.3
 */

use Tutor\Models\CourseModel;
use Tutor\Models\WithdrawModel;

if ( tutor_utils()->get_option( 'enable_profile_completion' ) ) {
	$profile_completion = tutor_utils()->user_profile_completion();
	$is_instructor      = tutor_utils()->is_instructor( null, true );
	$total_count        = count( $profile_completion );
	$incomplete_count   = count(
		array_filter(
			$profile_completion,
			function( $data ) {
				return ! $data['is_set'];
			}
		)
	);
	$complete_count     = $total_count - $incomplete_count;

	if ( $is_instructor ) {
		if ( isset( $total_count ) && isset( $incomplete_count ) && $incomplete_count <= $total_count ) {
			?>
			<div class="tutor-profile-completion tutor-card tutor-px-32 tutor-py-24 tutor-mb-40">
				<div class="tutor-row tutor-gx-0">
					<div class="tutor-col-lg-7 <?php echo tutor_utils()->is_instructor() ? 'tutor-profile-completion-content-admin' : ''; ?>">
						<div class="tutor-fs-5 tutor-fw-medium tutor-color-black">
							<?php esc_html_e( 'Complete Your Profile', 'tutor' ); ?>
						</div>

						<div class="tutor-row tutor-align-center tutor-mt-12">
							<div class="tutor-col">
								<div class="tutor-row tutor-gx-1">
									<?php for ( $i = 1; $i <= $total_count; $i++ ) : ?>
										<div class="tutor-col">
											<div class="tutor-progress-bar" style="--tutor-progress-value: <?php echo $i > $complete_count ? 0 : 100; ?>%; height: 8px;"><div class="tutor-progress-value" area-hidden="true"></div></div>
										</div>
									<?php endfor; ?>
								</div>
							</div>

							<div class="tutor-col-auto">
								<span class="tutor-round-box tutor-my-n20">
									<i class="tutor-icon-trophy" area-hidden="true"></i>
								</span>
							</div>
						</div>

						<div class="tutor-fs-6 tutor-mt-20">
							<?php
								$profile_complete_text = __( 'Please complete profile', 'tutor' );
							if ( $complete_count > ( $total_count / 2 ) && $complete_count < $total_count ) {
								$profile_complete_text = __( 'You are almost done', 'tutor' );
							} elseif ( $complete_count === $total_count ) {
								$profile_complete_text = __( 'Thanks for completing your profile', 'tutor' );
							}
								$profile_complete_status = $profile_complete_text;
							?>

							<span class="tutor-color-muted"><?php echo esc_html( $profile_complete_status ); ?>:</span>
							<span><?php echo esc_html( $complete_count . '/' . $total_count ); ?></span>
						</div>
					</div>

					<div class="tutor-col-lg-1 tutor-text-center tutor-my-24 tutor-my-lg-n24">
						<div class="tutor-vr tutor-d-none tutor-d-lg-inline-flex"></div>
						<div class="tutor-hr tutor-d-flex tutor-d-lg-none"></div>
					</div>

					<div class="tutor-col-lg-4 tutor-d-flex tutor-flex-column tutor-justify-center">
						<?php
						$i           = 0;
						$monetize_by = tutils()->get_option( 'monetize_by' );
						foreach ( $profile_completion as $key => $data ) {
							if ( '_tutor_withdraw_method_data' === $key ) {
								if ( 'free' === $monetize_by ) {
									continue;
								}
							}
							$is_set = $data['is_set']; // Whether the step is done or not.
							?>
								<div class="tutor-d-flex tutor-align-center<?php echo $i < ( count( $profile_completion ) - 1 ) ? ' tutor-mb-8' : ''; ?>">
									<?php if ( $is_set ) : ?>
										<span class="tutor-icon-circle-mark-line tutor-color-success tutor-mr-8"></span>
									<?php else : ?>
										<span class="tutor-icon-circle-times-line tutor-color-warning tutor-mr-8"></span>
									<?php endif; ?>

									<span class="<?php echo $is_set ? 'tutor-color-secondary' : 'tutor-color-muted'; ?>">
										<a class="tutor-btn tutor-btn-ghost tutor-has-underline" href="<?php echo esc_url( $data['url'] ); ?>">
											<?php echo esc_html( $data['text'] ); ?>
										</a>
									</span>
								</div>
								<?php
								$i++;
						}
						?>
					</div>
				</div>
			</div>
			<?php
		}
	} else {
		if ( ! $profile_completion['_tutor_profile_photo']['is_set'] ) {
			$alert_message = sprintf(
				'<div class="tutor-alert tutor-primary tutor-mb-20">
					<div class="tutor-alert-text">
						<span class="tutor-alert-icon tutor-fs-4 tutor-icon-circle-info tutor-mr-12"></span>
						<span>
							%s
						</span>
					</div>
					<div class="alert-btn-group">
						<a href="%s" class="tutor-btn tutor-btn-sm">' . __( 'Click Here', 'tutor' ) . '</a>
					</div>
				</div>',
				$profile_completion['_tutor_profile_photo']['text'],
				tutor_utils()->tutor_dashboard_url( 'settings' )
			);

			echo $alert_message; //phpcs:ignore
		}
	}
}
?>
<div class="section-title">
	<h4 class="rbt-title-style-3"><?php esc_html_e( 'Dashboard', 'tutor' ); ?></h4>
</div>
<?php
	$user_id           = get_current_user_id();
	$enrolled_course   = tutor_utils()->get_enrolled_courses_by_user();
	$completed_courses = tutor_utils()->get_completed_courses_ids_by_user();
	$total_students    = tutor_utils()->get_total_students_by_instructor( $user_id );
	$my_courses        = CourseModel::get_courses_by_instructor( $user_id, CourseModel::STATUS_PUBLISH );
	$earning_sum       = WithdrawModel::get_withdraw_summary( $user_id );
	$active_courses    = tutor_utils()->get_active_courses_by_user( $user_id );

	$enrolled_course_count  = $enrolled_course ? $enrolled_course->post_count : 0;
	$completed_course_count = count( $completed_courses );
	$active_course_count    = is_object( $active_courses ) && $active_courses->have_posts() ? $active_courses->post_count : 0;

	$status_translations = array(
		'publish' => __( 'Published', 'tutor' ),
		'pending' => __( 'Pending', 'tutor' ),
		'trash'   => __( 'Trash', 'tutor' ),
	);

?>
<div class="rbt-dashboard-content bg-color-white rbt-shadow-box mb--60">
	<div class="content">
		<div class="row g-5">
			<div class="col-lg-4 col-md-4 col-sm-6 col-12">
				<div class="rbt-counterup variation-01 rbt-hover-03 rbt-border-dashed bg-primary-opacity">
					<div class="inner">
						<div class="rbt-round-icon bg-primary-opacity">
							<i class="feather-book-open"></i>
						</div>
						<div class="content">
							<h3 class="counter without-icon color-primary"><span class="odometer" data-count="<?php echo esc_html( $enrolled_course_count ); ?>"><?php echo esc_html( $enrolled_course_count ); ?></span>
							</h3>
							<span class="rbt-title-style-2 d-block"><?php _e('Enrolled Courses', 'open-learning'); ?></span>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-6 col-12">
				<div class="rbt-counterup variation-01 rbt-hover-03 rbt-border-dashed bg-secondary-opacity">
					<div class="inner">
						<div class="rbt-round-icon bg-secondary-opacity">
							<i class="feather-monitor"></i>
						</div>
						<div class="content">
							<h3 class="counter without-icon color-secondary"><span class="odometer" data-count="<?php echo esc_html( $active_course_count ); ?>"><?php echo esc_html( $active_course_count ); ?></span>
							</h3>
							<span class="rbt-title-style-2 d-block"><?php _e('ACTIVE COURSES', 'open-learning'); ?></span>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-6 col-12">
				<div class="rbt-counterup variation-01 rbt-hover-03 rbt-border-dashed bg-violet-opacity">
					<div class="inner">
						<div class="rbt-round-icon bg-violet-opacity">
							<i class="feather-award"></i>
						</div>
						<div class="content">
							<h3 class="counter without-icon color-violet"><span class="odometer" data-count="<?php echo esc_html( $completed_course_count ); ?>"><?php echo esc_html( $completed_course_count ); ?></span>
							</h3>
							<span class="rbt-title-style-2 d-block"><?php _e('Completed Courses', 'open-learning'); ?></span>
						</div>
					</div>
				</div>
			</div>
			<?php if ( current_user_can( tutor()->instructor_role ) ) : ?>
				<div class="col-lg-4 col-md-4 col-sm-6 col-12">
					<div class="rbt-counterup variation-01 rbt-hover-03 rbt-border-dashed bg-pink-opacity">
						<div class="inner">
							<div class="rbt-round-icon bg-pink-opacity">
								<i class="feather-users"></i>
							</div>
							<div class="content">
								<h3 class="counter without-icon color-pink"><span class="odometer" data-count="<?php echo esc_html( $total_students ); ?>"><?php echo esc_html( $total_students ); ?></span>
								</h3>
								<span class="rbt-title-style-2 d-block"><?php _e('Total Students', 'open-learning'); ?></span>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-6 col-12">
					<div class="rbt-counterup variation-01 rbt-hover-03 rbt-border-dashed bg-coral-opacity">
						<div class="inner">
							<div class="rbt-round-icon bg-coral-opacity">
								<i class="feather-gift"></i>
							</div>
							<div class="content">
								<h3 class="counter without-icon color-coral"><span class="odometer" data-count="<?php echo esc_html( count( $my_courses ) ); ?>"><?php echo esc_html( count( $my_courses ) ); ?></span>
								</h3>
								<span class="rbt-title-style-2 d-block"><?php _e('Total Courses', 'open-learning'); ?></span>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-6 col-12">
					<div class="rbt-counterup variation-01 rbt-hover-03 rbt-border-dashed bg-warning-opacity">
						<div class="inner">
							<div class="rbt-round-icon bg-warning-opacity">
								<i class="feather-dollar-sign"></i>
							</div>
							<div class="content">
								<h3 class="counter color-warning"><span class="odometer" data-count="<?php echo wp_kses_post( $earning_sum->total_income ); ?>"><?php echo wp_kses_post( $earning_sum->total_income ); ?></span>
								</h3>
								<span class="rbt-title-style-2 d-block"><?php _e('Total Earnings', 'open-learning'); ?></span>
							</div>
						</div>
					</div>
				</div>
			<?php endif; ?>
		</div>
	</div>
</div>
<?php
/**
 * Active users in progress courses
 */
$placeholder_img     = tutor()->url . 'assets/images/placeholder.svg';
$courses_in_progress = tutor_utils()->get_active_courses_by_user( get_current_user_id() );
?>

<?php if ( $courses_in_progress && $courses_in_progress->have_posts() ) : ?>
	<div class="rbt-dashboard-content bg-color-white rbt-shadow-box mb--60">
		<div class="content">
			<div class="row">
				<div class="col-lg-12">
					<div class="section-title">
						<h4 class="rbt-title-style-3"><?php esc_html_e( 'In Progress Courses', 'tutor' ); ?></h4>
					</div>
				</div>
			</div>
			<div class="row gy-5">
				<div class="col-lg-12">
					<div class="rbt-course-grid-column active-list-view">
						<?php
						while ( $courses_in_progress->have_posts() ) :
							$instructors = tutor_utils()->get_instructors_by_course(get_the_ID());
							$profile_url       = tutor_utils()->profile_url( $instructors[0]->ID, true );
							$course_categories = get_tutor_course_categories( get_the_ID() );
							$courses_in_progress->the_post();
							$tutor_course_img = get_tutor_course_thumbnail_src('large');
							$course_rating    = tutor_utils()->get_course_rating( get_the_ID() );
							$course_progress  = tutor_utils()->get_course_completed_percent( get_the_ID(), 0, true );
							$completed_number = 0 === (int) $course_progress['completed_count'] ? 1 : (int) $course_progress['completed_count'];
							?>
							<div class="course-grid-3">
								<div class="rbt-card variation-01 rbt-hover card-list-2">
									<div class="rbt-card-img">
										<a href="<?php the_permalink(); ?>">
											<img src="<?php echo empty( $tutor_course_img ) ? esc_url( $placeholder_img ) : esc_url( $tutor_course_img ); ?>" alt="<?php the_title(); ?>">
										</a>
									</div>
									<div class="rbt-card-body">
										<?php tutor_load_template( 'loop.rating' ); ?>

										<h4 class="rbt-card-title">
											<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
										</h4>

										<ul class="rbt-meta">
											<li>
												<span class="tutor-color-muted tutor-mr-4">
													<?php esc_html_e( 'Completed Lessons:', 'tutor' ); ?>
												</span>
												<span class="tutor-fw-medium tutor-color-black">
													<span>
													<?php echo esc_html( $course_progress['completed_count'] ); ?>
													</span>
													<?php esc_html_e( 'of', 'tutor' ); ?>
													<span>
													<?php echo esc_html( $course_progress['total_count'] ); ?>
													</span>
													<?php echo esc_html( _n( 'lesson', 'lessons', $completed_number, 'tutor' ) ); ?>
												</span>
											</li>
										</ul>
										<div class="rbt-author-meta">
											<div class="rbt-avater">
												<a href="<?php echo esc_url( $profile_url ); ?>">
													<?php echo wp_kses( tutor_utils()->get_tutor_avatar( $instructors[0]->ID ), tutor_utils()->allowed_avatar_tags() ); ?>
												</a>
											</div>
											<div class="rbt-author-info">
												By 
												<a href="<?php echo esc_url( $profile_url ); ?>"><?php echo esc_html( ucwords(get_the_author()) ); ?></a> In <a href="#">
												<?php if ( ! empty( $course_categories ) && is_array( $course_categories ) && count( $course_categories ) ) : ?>
													<?php
														$category_links = array();
														foreach ( $course_categories as $course_category ) :
														$category_name    = $course_category->name;
														$category_link    = get_term_link( $course_category->term_id );
														$category_links[] = wp_sprintf( '<a href="%1$s">%2$s</a>', esc_url( $category_link ), esc_html( $category_name ) );
														endforeach;
														echo implode( ', ', $category_links ); //phpcs:ignore --contain safe data
													?>
												<?php endif; ?>
												</a>
											</div>
										</div>
										<div class="rbt-progress-style-1 mb--20 mt--10">
											<div class="single-progress">
												<h6 class="rbt-title-style-2 mb--10"><?php esc_html_e( 'Complete', 'tutor' ); ?></h6>
												<div class="progress">
													<div class="progress-bar wow fadeInLeft bar-color-success" data-wow-duration="0.5s" data-wow-delay=".3s" role="progressbar" style="width: <?php echo esc_attr( $course_progress['completed_percent'] ); ?>%" aria-valuenow="<?php echo esc_attr( $course_progress['completed_percent'] ); ?>" aria-valuemin="0" aria-valuemax="100">
													</div>
													<span class="rbt-title-style-2 progress-number">
														<?php echo esc_html( $course_progress['completed_percent'] . '%' ); ?>
													</span>
												</div>
											</div>
										</div>
										<div class="rbt-card-bottom">
											<?php tutor_course_loop_price(); ?>
											<?php
											$product_id = tutor_utils()->get_course_product_id( get_the_ID() );
											$product    = wc_get_product( $product_id );
										
											if ( $product ) {
											$sale_price    = $product->get_sale_price();
											$regular_price = $product->get_regular_price();
											?>
											<div class="rbt-price">
												<span class="current-price"><?php echo wc_price( $sale_price ? $sale_price : $regular_price ); //phpcs:ignore?></span>
												<?php if ( $regular_price && $sale_price && $sale_price != $regular_price ) : ?>
												<span class="off-price"><?php echo wc_price( $regular_price ); //phpcs:ignore?></span>
												<?php endif; ?>
											</div>
											<?php }?>
										</div>
									</div>
								</div>
							</div>
							<?php endwhile; ?>
						<?php wp_reset_postdata(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php endif; ?>

<?php
$instructor_course = tutor_utils()->get_courses_for_instructors( get_current_user_id() );

if ( count( $instructor_course ) ) {
	$course_badges = array(
		'publish' => 'success',
		'pending' => 'warning',
		'trash'   => 'danger',
	);

?>
<div class="rbt-dashboard-content bg-color-white rbt-shadow-box mb--60">
	<div class="content">
		<div class="row">
			<div class="col-lg-12">
				<div class="section-title">
					<h4 class="rbt-title-style-3"><?php _e('My Courses', 'open-learning'); ?></h4>
				</div>
			</div>
		</div>
		<div class="row gy-5">
			<div class="col-lg-12">
				<div class="rbt-dashboard-table table-responsive">
					<table class="rbt-table table table-borderless">
						<thead>
							<tr>
								<th>
									<?php esc_html_e( 'Course Name', 'tutor' ); ?>
								</th>
								<th>
									<?php esc_html_e( 'Enrolled', 'tutor' ); ?>
								</th>
								<th>
									<?php esc_html_e( 'Rating', 'tutor' ); ?>
								</th>
							</tr>
						</thead>
						<tbody>
							<?php if ( is_array( $instructor_course ) && count( $instructor_course ) ) : ?>
							<?php
							foreach ( $instructor_course as $course ) :
								$enrolled      = tutor_utils()->count_enrolled_users_by_course( $course->ID );
								$course_status = isset( $status_translations[ $course->post_status ] ) ? $status_translations[ $course->post_status ] : __( $course->post_status, 'tutor' ); //phpcs:ignore
								$course_rating = tutor_utils()->get_course_rating( $course->ID );
								$course_badge  = isset( $course_badges[ $course->post_status ] ) ? $course_badges[ $course->post_status ] : 'dark';
								?>
								<tr>
									<td>
										<a href="<?php echo esc_url( get_the_permalink( $course->ID ) ); ?>" target="_blank">
											<?php echo esc_html( $course->post_title ); ?>
										</a>
									</td>
									<td>
										<?php echo esc_html( $enrolled ); ?>
									</td>
									<td>
										<?php tutor_utils()->star_rating_generator_v2( $course_rating->rating_avg, null, true ); ?>
									</td>
								</tr>
							<?php endforeach; ?>
							<?php else : ?>
								<tr>
									<td colspan="100%" class="column-empty-state">
										<?php tutor_utils()->tutor_empty_state( tutor_utils()->not_found_text() ); ?>
									</td>
								</tr>
							<?php endif; ?>
						</tbody>
					</table>
				</div>

				<div class="load-more-btn text-center">
					<a class="rbt-btn-link" href="<?php echo esc_url( tutor_utils()->tutor_dashboard_url( 'my-courses' ) ); ?>"><?php _e('Browse All Course', 'open-learning'); ?><i class="feather-arrow-right"></i></a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php } ?>
