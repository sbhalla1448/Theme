<?php
/**
 * Pending events
 *
 * @package Tutor\Templates
 * @subpackage Dashboard\My_Events
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.4.3
 */

$active_tab = 'my-events/pending-events';
require dirname( __DIR__ ) . DIRECTORY_SEPARATOR . 'my-events.php';

