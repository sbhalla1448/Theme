<?php
/**
 * My Courses Page
 *
 * @package Tutor\Templates
 * @subpackage Dashboard
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.4.3
 */

use TUTOR\Input;
use Tutor\Models\CourseModel;

// Get the user ID and active tab.
$current_user_id                     = get_current_user_id();
! isset( $active_tab ) ? $active_tab = 'my-courses' : 0;

// Map required course status according to page.
$status_map = array(
	'my-courses'                 => CourseModel::STATUS_PUBLISH,
	'my-courses/draft-courses'   => CourseModel::STATUS_DRAFT,
	'my-courses/pending-courses' => CourseModel::STATUS_PENDING,
);

// Set currently required course status fo rcurrent tab.
$status = isset( $status_map[ $active_tab ] ) ? $status_map[ $active_tab ] : CourseModel::STATUS_PUBLISH;

// Get counts for course tabs.
$count_map = array(
	'publish' => CourseModel::get_courses_by_instructor( $current_user_id, CourseModel::STATUS_PUBLISH, 0, 0, true ),
	'pending' => CourseModel::get_courses_by_instructor( $current_user_id, CourseModel::STATUS_PENDING, 0, 0, true ),
	'draft'   => CourseModel::get_courses_by_instructor( $current_user_id, CourseModel::STATUS_DRAFT, 0, 0, true ),
);

$course_archive_arg = isset( $GLOBALS['tutor_course_archive_arg'] ) ? $GLOBALS['tutor_course_archive_arg']['column_per_row'] : null;
$courseCols         = null === $course_archive_arg ? tutor_utils()->get_option( 'courses_col_per_row', 4 ) : $course_archive_arg;
$per_page           = tutor_utils()->get_option( 'courses_per_page', 10 );
$paged              = Input::get( 'current_page', 1, Input::TYPE_INT );
$offset             = $per_page * ( $paged - 1 );

$results = CourseModel::get_courses_by_instructor( $current_user_id, $status, $offset, $per_page );
?>
<div class="rbt-dashboard-content bg-color-white rbt-shadow-box">
	<div class="content">
		<div class="section-title">
			<h4 class="rbt-title-style-3"><?php esc_html_e( 'My Courses', 'tutor' ); ?></h4>
		</div>
		<div class="advance-tab-button mb--30">
			<ul class="nav nav-tabs tab-button-style-2 justify-content-start">
				<li role="presentation">
					<a href="<?php echo esc_url( tutor_utils()->get_tutor_dashboard_page_permalink( 'my-courses' ) ); ?>" class="tab-button <?php echo esc_attr( 'my-courses' === $active_tab ? 'active' : '' ); ?>">
						<span class="title"><?php esc_html_e( 'Publish', 'tutor' ); ?> <?php echo esc_html( '(' . $count_map['publish'] . ')' ); ?></span>
					</a>
				</li>
				<li role="presentation">
					<a href="<?php echo esc_url( tutor_utils()->get_tutor_dashboard_page_permalink( 'my-courses/pending-courses' ) ); ?>" class="tab-button <?php echo esc_attr( 'my-courses/pending-courses' === $active_tab ? 'active' : '' ); ?>">
						<span class="title"><?php esc_html_e( 'Pending', 'tutor' ); ?> <?php echo esc_html( '(' . $count_map['pending'] . ')' ); ?></span>
					</a>
				</li>
				<li role="presentation">
					<a href="<?php echo esc_url( tutor_utils()->get_tutor_dashboard_page_permalink( 'my-courses/draft-courses' ) ); ?>" class="tab-button <?php echo esc_attr( 'my-courses/draft-courses' === $active_tab ? 'active' : '' ); ?>">
						<span class="title"><?php esc_html_e( 'Draft', 'tutor' ); ?> <?php echo esc_html( '(' . $count_map['draft'] . ')' ); ?></span>
					</a>
				</li>
			</ul>
		</div>

		<div class="tab-content">
			<div class="tab-pane fade active show">
				<!-- Course list -->
				<?php
				$placeholder_img = tutor()->url . 'assets/images/placeholder.svg';

				if ( ! is_array( $results ) || ( ! count( $results ) && 1 == $paged ) ) {
					tutor_utils()->tutor_empty_state( tutor_utils()->not_found_text() );
				} else {
					?>
					<div class="row g-5">
						<?php
						global $post;
						$tutor_nonce_value = wp_create_nonce( tutor()->nonce_action );
						foreach ( $results as $post ) :
							setup_postdata( $post );

							$avg_rating         = tutor_utils()->get_course_rating()->rating_avg;
							$tutor_course_img   = get_tutor_course_thumbnail_src();
							$id_string_delete   = 'tutor_my_courses_delete_' . $post->ID;
							$row_id             = 'tutor-dashboard-my-course-' . $post->ID;
							$course_duration    = get_tutor_course_duration_context( $post->ID, true );
							$course_students    = tutor_utils()->count_enrolled_users_by_course();
							$is_main_instructor = CourseModel::is_main_instructor( $post->ID );
							$topics_ids = get_posts(array(
								'post_parent'	=> $post->ID,
								'post_type'		=> 'topics',
								'fields' 		=> 'ids'
							));
							
							$lessons_count = 0;
							foreach( $topics_ids as $topic ){
								$lessons_ids = get_posts(array(
									'post_type'		=> 'lesson',
									'post_parent'	=> $topic,
									'fields' 		=> 'ids'
								));
							
								$lessons_count += count($lessons_ids);
							}
							?>
							<div class="col-lg-4 col-md-6 col-12">
								<div class="rbt-card variation-01">
									<div id="<?php echo esc_attr( $row_id ); ?>" class="tutor-mycourse-<?php the_ID(); ?>">
										<div class="rbt-card-img">
											<a href="<?php echo esc_url( get_the_permalink() ); ?>">
												<img src="<?php echo empty( $tutor_course_img ) ? esc_url( $placeholder_img ) : esc_url( $tutor_course_img ); ?>" alt="<?php the_title(); ?>">
											</a>
										</div>
										<?php if ( false === $is_main_instructor ) : ?>
										<div class="tutor-course-co-author-badge"><?php esc_html_e( 'Co-author', 'tutor' ); ?></div>
										<?php endif; ?>
										<div class="rbt-card-body">
											<div class="rbt-card-top">
												<div class="rbt-review">
													<div class="rating">
													<?php
														$course_rating = tutor_utils()->get_course_rating();
														$output = '';
														for ( $i = 1; $i <= 5; $i++ ) {
															$intRating = (int) $course_rating->rating_avg;

															if ( $intRating >= $i ) {
																$output .= '<i class="fas fa-star" data-rating-value="' . $i . '"></i>';
															} else {
																if ( ( $course_rating->rating_avg - $i ) >= -0.5 ) {
																	$output .= '<i class="fad fa-star-half-alt" data-rating-value="' . $i . '"></i>';
																} else {
																	$output .= '<i class="far fa-star" data-rating-value="' . $i . '"></i>';
																}
															}
														}
														echo $output;
													?>
													</div>
													<span class="rating-count"> (<?php echo esc_html( $course_rating->rating_count > 0 ? $course_rating->rating_count : 0 ); ?> Reviews)</span>
												</div>
											</div>
											<h4 class="rbt-card-title"><a href="<?php echo esc_url( get_the_permalink() ); ?>"><?php the_title(); ?></a></h4>
											<ul class="rbt-meta">
												<li><i class="feather-book"></i><?php echo esc_html($lessons_count); ?> Lessons</li>
												<?php if ( ! empty( $course_students ) ) : ?>
												<li><i class="feather-users"></i><?php echo esc_html($course_students); ?> Students</li>
												<?php endif; ?>
											</ul>

											<div class="rbt-card-bottom">
												<div class="rbt-price">
													<?php
														$price = tutor_utils()->get_course_price();
														if ( null === $price ) {?>
															<span class="rbt-badge-6 bg-primary-opacity mb-0"><?php esc_html_e( 'Free', 'tutor' ); ?></span>
														<?php
														} else {
															$course_id  = tutor_utils()->get_post_id( $post->ID );
															$product_id = tutor_utils()->get_course_product_id( $course_id );
															$product = wc_get_product( $product_id );
															$sale_price    = $product->get_sale_price();
															$regular_price = $product->get_regular_price();
															?>
															<span class="current-price"><?php echo wc_price( $sale_price ? $sale_price : $regular_price ); //phpcs:ignore?></span>
															<?php if ( $regular_price && $sale_price && $sale_price != $regular_price ) : ?>
															<span class="off-price"><?php echo wc_price( $regular_price ); //phpcs:ignore?></span>
															<?php endif; ?>
															<?php
														}
													?>
												</div>
												
												<div class="tutor-iconic-btn-group tutor-mr-n8">
													<a class="rbt-btn-link left-icon" href="<?php echo esc_url( tutor_utils()->course_edit_link( $post->ID ) ); ?>"><i class="feather-edit"></i></a>
													<div class="tutor-dropdown-parent">
														<button type="button" class="tutor-iconic-btn" action-tutor-dropdown="toggle">
															<span class="tutor-icon-kebab-menu" area-hidden="true"></span>
														</button>
														<div id="table-dashboard-course-list-<?php echo esc_attr( $post->ID ); ?>" class="tutor-dropdown tutor-dropdown-dark tutor-text-left">
															
															<!-- Submit Action -->
															<?php if ( tutor()->has_pro && in_array( $post->post_status, array( CourseModel::STATUS_DRAFT ) ) ) : ?>
																<?php
																$params = http_build_query(
																	array(
																		'tutor_action' => 'update_course_status',
																		'status' => CourseModel::STATUS_PENDING,
																		'course_id' => $post->ID,
																		tutor()->nonce => $tutor_nonce_value,
																	)
																);
																?>
															<a class="tutor-dropdown-item" href="?<?php echo esc_attr( $params ); ?>">
																<i class="tutor-icon-share tutor-mr-8" area-hidden="true"></i>
																<span>
																	<?php
																	$can_publish_course = current_user_can( 'administrator' ) || (bool) tutor_utils()->get_option( 'instructor_can_publish_course' );
																	if ( $can_publish_course ) {
																		esc_html_e( 'Publish', 'tutor' );
																	} else {
																		esc_html_e( 'Submit', 'tutor' );
																	}
																	?>
																</span>
															</a>
															<?php endif; ?>
															<!-- # Submit Action -->

															<!-- Duplicate Action -->
															<?php if ( tutor()->has_pro && in_array( $post->post_status, array( CourseModel::STATUS_PUBLISH, CourseModel::STATUS_PENDING, CourseModel::STATUS_DRAFT ) ) ) : ?>
																<?php
																$params = http_build_query(
																	array(
																		'tutor_action' => 'duplicate_course',
																		'course_id' => $post->ID,
																	)
																);
																?>
															<a class="tutor-dropdown-item" href="?<?php echo esc_attr( $params ); ?>">
																<i class="tutor-icon-copy-text tutor-mr-8" area-hidden="true"></i>
																<span><?php esc_html_e( 'Duplicate', 'tutor' ); ?></span>
															</a>
															<?php endif; ?>
															<!-- # Duplicate Action -->
															
															<!-- Move to Draf Action -->
															<?php if ( tutor()->has_pro && in_array( $post->post_status, array( CourseModel::STATUS_PUBLISH ) ) ) : ?>
																<?php
																$params = http_build_query(
																	array(
																		'tutor_action' => 'update_course_status',
																		'status' => CourseModel::STATUS_DRAFT,
																		'course_id' => $post->ID,
																		tutor()->nonce => $tutor_nonce_value,
																	)
																);
																?>
															<a class="tutor-dropdown-item" href="?<?php echo esc_attr( $params ); ?>">
																<i class="tutor-icon-archive tutor-mr-8" area-hidden="true"></i>
																<span><?php esc_html_e( 'Move to Draft', 'tutor' ); ?></span>
															</a>
															<?php endif; ?>
															<!-- # Move to Draft Action -->
															
															<!-- Cancel Submission -->
															<?php if ( tutor()->has_pro && in_array( $post->post_status, array( CourseModel::STATUS_PENDING ) ) ) : ?>
																<?php
																$params = http_build_query(
																	array(
																		'tutor_action' => 'update_course_status',
																		'status' => CourseModel::STATUS_DRAFT,
																		'course_id' => $post->ID,
																		tutor()->nonce => $tutor_nonce_value,
																	)
																);
																?>
															<a href="?<?php echo esc_attr( $params ); ?>" class="tutor-dropdown-item">
																<i class="tutor-icon-times tutor-mr-8" area-hidden="true"></i>
																<span><?php esc_html_e( 'Cancel Submission', 'tutor' ); ?></span>
															</a>
															<?php endif; ?>
															<!-- # Cancel Submission -->
															
															<!-- Delete Action -->
															<?php if ( $is_main_instructor && in_array( $post->post_status, array( CourseModel::STATUS_PUBLISH, CourseModel::STATUS_DRAFT ) ) ) : ?>
															<a href="#" data-tutor-modal-target="<?php echo esc_attr( $id_string_delete ); ?>" class="tutor-dropdown-item tutor-admin-course-delete">
																<i class="tutor-icon-trash-can-bold tutor-mr-8" area-hidden="true"></i>
																<span><?php esc_html_e( 'Delete', 'tutor' ); ?></span>
															</a>
															<?php endif; ?>
															<!-- # Delete Action -->

														</div>
													</div>
												</div>
											</div>
										</div>
										<!-- Delete prompt modal -->
										<div id="<?php echo esc_attr( $id_string_delete ); ?>" class="tutor-modal">
											<div class="tutor-modal-overlay"></div>
											<div class="tutor-modal-window">
												<div class="tutor-modal-content tutor-modal-content-white">
													<button class="tutor-iconic-btn tutor-modal-close-o" data-tutor-modal-close>
														<span class="tutor-icon-times" area-hidden="true"></span>
													</button>

													<div class="tutor-modal-body tutor-text-center">
														<div class="tutor-mt-48">
															<img class="tutor-d-inline-block" src="<?php echo esc_attr( tutor()->url ); ?>assets/images/icon-trash.svg" />
														</div>

														<div class="tutor-fs-3 tutor-fw-medium tutor-color-black tutor-mb-12"><?php esc_html_e( 'Delete This Course?', 'tutor' ); ?></div>
														<div class="tutor-fs-4 tutor-color-muted"><?php esc_html_e( 'Are you sure you want to delete this course permanently from the site? Please confirm your choice.', 'tutor' ); ?></div>

														<div class="rbt-group-btn mt--30">
															<button data-tutor-modal-close class="rbt-btn btn-sm btn-border">
																<?php esc_html_e( 'Cancel', 'tutor' ); ?>
															</button>
															<button class="rbt-btn btn-sm" data-request_data='{"course_id":<?php echo esc_attr( $post->ID ); ?>,"action":"tutor_delete_dashboard_course","redirect_to":"<?php echo esc_url( tutor_utils()->get_current_url() ); ?>"}' data-delete_element_id="<?php echo esc_attr( $row_id ); ?>">
																<?php esc_html_e( 'Yes, Delete This', 'tutor' ); ?>
															</button>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<?php
						endforeach;
						wp_reset_postdata();
						?>
					</div>
					<div class="tutor-mt-20">
						<?php
						if ( $count_map[ $status ] > $per_page ) {
							$pagination_data = array(
								'total_items' => $count_map[ $status ],
								'per_page'    => $per_page,
								'paged'       => $paged,
							);

							tutor_load_template_from_custom_path(
								tutor()->path . 'templates/dashboard/elements/pagination.php',
								$pagination_data
							);
						}
						?>

					</div>
					<?php
				}
				?>
			</div>
		</div>
	</div>
</div>
