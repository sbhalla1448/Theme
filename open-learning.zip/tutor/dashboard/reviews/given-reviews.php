<?php
/**
 * My Own reviews
 *
 * @package Tutor\Templates
 * @subpackage Dashboard\Reviews
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.1.2
 */

use TUTOR\Input;

// Pagination Variable.
$per_page     = tutor_utils()->get_option( 'pagination_per_page', 20 );
$current_page = max( 1, Input::get( 'current_page', 0, Input::TYPE_INT ) );
$offset       = ( $current_page - 1 ) * $per_page;


$all_reviews    = tutor_utils()->get_reviews_by_user( 0, $offset, $per_page, true );
$review_count   = $all_reviews->count;
$reviews        = $all_reviews->results;
$received_count = tutor_utils()->get_reviews_by_instructor( 0, 0, 0 )->count;
?>
<div class="rbt-dashboard-content bg-color-white rbt-shadow-box">
	<div class="content">
		<div class="section-title">
			<h4 class="rbt-title-style-3"><?php esc_html_e( 'Reviews', 'tutor' ); ?></h4>
		</div>
		<?php if ( current_user_can( tutor()->instructor_role ) ) : ?>
		<div class="advance-tab-button mb--30">
			<ul class="nav nav-tabs tab-button-style-2 justify-content-start">
				<li>
					<a class="tab-button" href="<?php echo esc_url( tutor_utils()->get_tutor_dashboard_page_permalink( 'reviews' ) ); ?>">
						<span class="title"><?php esc_html_e( 'Received', 'tutor' ); ?> (<?php echo esc_html( $received_count ); ?>)</span>
					</a> 
				</li>
				<?php if ( $review_count ) : ?>
					<li> 
						<a class="tab-button active" href="<?php echo esc_url( tutor_utils()->get_tutor_dashboard_page_permalink( 'reviews/given-reviews' ) ); ?>"> 
							<span class="title"><?php esc_html_e( 'Given', 'tutor' ); ?> (<?php echo esc_html( $review_count ); ?>)</span>
						</a> 
					</li>
				<?php endif; ?>
			</ul>
		</div>
		<?php endif; ?>
		<?php if ( is_array( $reviews ) || count( $reviews ) ) : ?>
			<div class="tab-content">
				<div class="tab-pane fade active show">
					<div class="rbt-dashboard-table table-responsive mobile-table-750">
						<table class="rbt-table table table-borderless">
							<thead>
								<tr>
									<th>
										<?php esc_html_e( 'Course Title', 'tutor' ); ?>
									</th>
									<th>
										<?php esc_html_e( 'Review', 'tutor' ); ?>
									</th>
									<th>
										<?php esc_html_e( 'Actions', 'tutor' ); ?>
									</th>
								</tr>
							</thead>

							<tbody>
							<?php foreach ( $reviews as $review ) : 
								$update_id   = 'tutor_review_update_' . $review->comment_ID;
								$delete_id   = 'tutor_review_delete_' . $review->comment_ID;
								$row_id      = 'tutor_review_row_' . $review->comment_ID;	
							?>
								<tr id="<?php echo esc_html( $row_id ); ?>" class="tutor-review-<?php echo esc_html( $review->comment_ID ); ?>">
									<th width="35%">Course: <?php echo esc_html( get_the_title( $review->comment_post_ID ) ); ?></th>
									<td>
										<div class="rbt-review">
											<div class="rating">
												<?php tutor_utils()->star_rating_generator_v2( $review->rating, null, true ); ?> 
											</div>
										</div>
										<p class="b3"><?php echo esc_textarea( htmlspecialchars( stripslashes( $review->comment_content ) ) ); ?></p>
									</td>
									<td width="20%">
										<div class="rbt-button-group">
											<a class="rbt-btn-link left-icon" href="#" data-tutor-modal-target="<?php echo esc_html( $update_id ); ?>" role="button"><i class="feather-edit"></i> <?php esc_html_e( 'Edit', 'tutor' ); ?></a>
											<a class="rbt-btn-link left-icon" href="#" data-tutor-modal-target="<?php echo esc_html( $delete_id ); ?>" role="button"><i class="feather-trash-2"></i> <?php esc_html_e( 'Delete', 'tutor' ); ?></a>
										</div>
										<!-- Edit Review Modal -->
										<form class="tutor-modal" id="<?php echo esc_html( $update_id ); ?>">
											<div class="tutor-modal-overlay"></div>
											<div class="tutor-modal-window">
												<div class="tutor-modal-content tutor-modal-content-white">
													<button class="tutor-iconic-btn tutor-modal-close-o" data-tutor-modal-close>
														<span class="tutor-icon-times" area-hidden="true"></span>
													</button>

													<div class="tutor-modal-body tutor-text-center">
														<div class="tutor-fs-3 tutor-fw-medium tutor-color-black tutor-mt-48 tutor-mb-12"><?php esc_html_e( 'How would you rate this course?', 'tutor' ); ?></div>
														<div class="tutor-fs-4 tutor-color-muted"><?php esc_html_e( 'Select Rating', 'tutor' ); ?></div>

														<input type="hidden" name="course_id" value="<?php echo esc_html( $review->comment_post_ID ); ?>"/>
														<input type="hidden" name="review_id" value="<?php echo esc_html( $review->comment_ID ); ?>"/>
														<input type="hidden" name="action" value="tutor_place_rating" />

														<div class="tutor-ratings tutor-ratings-xl tutor-ratings-selectable tutor-justify-center tutor-mt-16" tutor-ratings-selectable>
														<?php
															tutor_utils()->star_rating_generator( tutor_utils()->get_rating_value( $review->rating ) );
														?>
														</div>

														<textarea class="tutor-form-control tutor-mt-28" name="review" placeholder="<?php esc_html_e( 'write a review', 'tutor' ); ?>"><?php echo esc_html( stripslashes( $review->comment_content ) ); ?></textarea>

														<div class="rbt-button-group mt--20">
															<button type="button" class="rbt-btn btn-gradient btn-sm" data-tutor-modal-close data-action="back">
															<?php esc_html_e( 'Cancel', 'tutor' ); ?>
															</button>
															<button type="submit" class="tutor_submit_review_btn rbt-btn btn-border hover-icon-reverse btn-sm" data-action="next">
															<?php esc_html_e( 'Update Review', 'tutor' ); ?>
															</button>
														</div>
													</div>
												</div>
											</div>
										</form>

										<!-- Delete Modal -->
										<?php
										tutor_load_template(
											'modal.confirm',
											array(
												'id'      => $delete_id,
												'image'   => 'icon-trash.svg',
												'title'   => __( 'Do You Want to Delete This Review?', 'tutor' ),
												'content' => __( 'Are you sure you want to delete this review permanently from the site? Please confirm your choice.', 'tutor' ),
												'yes'     => array(
													'text'  => __( 'Yes, Delete This', 'tutor' ),
													'class' => 'tutor-list-ajax-action',
													'attr'  => array( 'data-request_data=\'{"action":"delete_tutor_review", "review_id":"' . $review->comment_ID . '"}\'', 'data-delete_element_id="' . $row_id . '"' ),
												),
											)
										);
										?>
									</td>
								</tr>
							<?php endforeach; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		<?php else : ?>
			<?php tutor_utils()->tutor_empty_state( tutor_utils()->not_found_text() ); ?>
		<?php endif; ?>

		<?php
		if ( $all_reviews->count > $per_page ) {
			$pagination_data              = array(
				'total_items' => $all_reviews->count,
				'per_page'    => $per_page,
				'paged'       => $current_page,
			);
			$pagination_template_frontend = tutor()->path . 'templates/dashboard/elements/pagination.php';
			tutor_load_template_from_custom_path( $pagination_template_frontend, $pagination_data );
		}
		?>
	</div>
</div>


