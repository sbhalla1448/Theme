<?php
/**
 * This file is redundant and will be emptied later.
 * It is returned here to fix multiple dashboard issue in Avada.
 * But still need to keep to prevent file not found error in Avada that causes if we delete it permanently.
 * The tutor dashboard actually will be rendered using other hook.
 *
 * @package Tutor\Templates
 * @subpackage Dashboard
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.0.0
 */

return;

