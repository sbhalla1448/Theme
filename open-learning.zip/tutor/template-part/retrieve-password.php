<?php
/**
 * Password retrieve template
 *
 * @package Tutor\Templates
 * @subpackage Template_Part
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.4.3
 */

defined( 'ABSPATH' ) || exit;

use TUTOR\Input;

if ( Input::get( 'reset_key' ) && Input::get( 'user_id' ) ) {
	tutor_load_template( 'template-part.form-retrieve-password' );
} else {
	do_action( 'tutor_before_retrieve_password_form' );
	?>


<div class="form-container clear">
<div class="form-wrapper">
	
	<form method="post" class="tutor-forgot-password-form tutor-ResetPassword lost_reset_password">
		<?php
			tutor_alert( null, 'any' );
			tutor_nonce_field();
		?>
		
		<div class="step-wrap">
			<dfn class="link-button step-button active">Step 1</dfn>
			<dfn class="link-button step-button ">Step 2</dfn>
			<dfn class="link-button step-button ">Step 3</dfn>
		</div>  
		<div class="form-heading">  
			<h2><span>Forgot </span> Password</h2>
		</div>
		
		

		<input type="hidden" name="tutor_action" value="tutor_retrieve_password">
        <p class="highlight-text"><?php echo apply_filters( 'tutor_lost_password_message', esc_html__( 'Lost your password? Please enter your username or email address. You will receive a link to create a new password via email.', 'tutor' ) ); ?></p><?php // @codingStandardsIgnoreLine ?>

		<div class="tutor-form-row tutor-mt-16">
			<div class="tutor-form-col-12">
				<div class="tutor-form-group">
					<label><?php esc_html_e( 'Username or email', 'tutor' ); ?></label>
					<input type="text" name="user_login" id="user_login" autocomplete="username">
				</div>
			</div>
		</div>

		<div class="clear"></div>

		<?php do_action( 'tutor_lostpassword_form' ); ?>

		<div class="tutor-form-row">
			<div class="tutor-form-col-12">
				<div class="tutor-form-group button-wrapp">
					<a href="https://openlearningcollege.ac/dashboard/" class="link-button">Previous</a>
					<button type="submit" class="tutor-btn tutor-btn-primary" value="<?php esc_attr_e( 'Reset password', 'tutor' ); ?>">
						<?php esc_html_e( 'Submit', 'tutor' ); ?>
					</button>
				</div>
			</div>
		</div>
		
		
		<div class="tutor-text-center tutor-text-info tutor-color-secondary tutor-mt-20">
			<?php esc_html_e( 'Don\'t have an account?', 'tutor' ); ?>&nbsp;
			<a href="<?php echo esc_url( add_query_arg( $url_arg, tutor_utils()->student_register_url() ) ); ?>" class="tutor-btn tutor-btn-link">
				<?php esc_html_e( 'Sign Up', 'tutor' ); ?>
			</a>
		</div>

	</form>
	
	<div class="register-thumb-wrap">
		<div class="register-thumb-inner confirm-paswrd">
			<div class="thumb-info">
				<h2>Unlock Your Brilliance with Online Courses</h2>
				<p>Embark on a transformative learning journey by joining our vibrant community of learners. Explore a wide range.</p>
				<div class="top-review-wrap">
					<img src="https://openlearningcollege.ac/wp-content/uploads/2023/12/Frame-1246.png" alt="" >

				</div>
			</div>
		</div>

	</div>
	</div>
	</div>

	<?php
	do_action( 'tutor_after_retrieve_password_form' );
	
	
	
}
