<?php
/**
 * Password retrive form
 *
 * @package Tutor\Templates
 * @subpackage Template_Part
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.4.3
 */

defined( 'ABSPATH' ) || exit;

do_action( 'tutor_before_reset_password_form' ); ?>


<div class="form-container clear">
	<div class="form-wrapper">

		<form method="post" class="tutor-reset-password-form tutor-ResetPassword lost_reset_password">
			<?php tutor_nonce_field(); ?>
			<input type="hidden" name="tutor_action" value="tutor_process_reset_password">
			<input type="hidden" name="reset_key" value="<?php echo esc_attr( \TUTOR\Input::get( 'reset_key' ) ); ?>" />
			<input type="hidden" name="user_id" value="<?php echo esc_attr( \TUTOR\Input::get( 'user_id' ) ); ?>" />

			
			<div class="step-wrap">
				<dfn class="link-button step-button">Step 1</dfn>
				<dfn class="link-button step-button ">Step 2</dfn>
				<dfn class="link-button step-button active">Step 3</dfn>
			</div>  
			<div class="form-heading">  
				<h2>Change Previous <span> Password</span></h2>
			</div>
			
			<p class="password-hints">
				<?php
				echo esc_html(
					apply_filters(
						'tutor_reset_password_message',
						esc_html__( 'Enter Password and Confirm Password to reset your password', 'tutor' )
					)
				);
				?>
			</p>

			
			<div class="tutor-form-row passwrd-row">
				<div class="tutor-form-col-12">
					<div class="tutor-form-group">
						<input type="password" name="password" id="password" placeholder="Choose new password*">
					</div>
				</div>
			</div>

			<div class="tutor-form-row">
				<div class="tutor-form-col-12">
					<div class="tutor-form-group">
						<input type="password" name="confirm_password" id="confirm_password" placeholder="Confirm new password*">
					</div>
				</div>
			</div>

			<div class="clear"></div>

			<?php do_action( 'tutor_reset_password_form' ); ?>

			<div class="tutor-form-row">
				<div class="tutor-form-col-12">
					<div class="tutor-form-group submit-btn">
						<button type="submit" class="tutor-btn" value="Reset password">
							<?php esc_html_e( 'Confirm To Update Password', 'tutor' ); ?>
						</button>
					</div>
				</div>
			</div>

		</form>

		<?php do_action( 'tutor_after_reset_password_form' ); ?>
	
		<div class="register-thumb-wrap">
			<div class="register-thumb-inner confirm-paswrd">
				<div class="thumb-info">
					<h2>Unlock Your Brilliance with Online Courses</h2>
					<p>Embark on a transformative learning journey by joining our vibrant community of learners. Explore a wide range.</p>
					<div class="top-review-wrap">
						<img src="https://openlearningcollege.ac/wp-content/uploads/2023/12/Frame-1246.png" alt="" >

					</div>
				</div>
			</div>

		</div>
	</div>
</div>
	
	
