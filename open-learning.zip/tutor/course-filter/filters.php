<?php
/**
 * Template for course filter
 *
 * @package Tutor\Templates
 * @subpackage Course_Filter
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.0.0
 */

$filter_object = new \TUTOR\Course_Filter();

$filter_prices = array(
	'free' => __( 'Free', 'tutor' ),
	'paid' => __( 'Paid', 'tutor' ),
);
$tutor_course_category_id = $_GET['tutor-course-filter-category'] ?? 0;
$course_levels     = tutor_utils()->course_levels();
$supported_filters = tutor_utils()->get_option( 'supported_course_filters', array() );
$supported_filters = array_keys( $supported_filters );
$reset_link        = remove_query_arg( $supported_filters, get_pagenum_link() );


$category = get_queried_object();  // Get the current category object
$category_id = $category->term_id;
?>

<form class="tutor-course-filter-form tutor-form">
	<aside class="rbt-sidebar-widget-wrapper">
		<div class="tutor-mb-16 tutor-d-block tutor-d-lg-none tutor-text-right">
			<a href="#" class="tutor-iconic-btn tutor-mr-n8" tutor-hide-course-filter><span class="tutor-icon-times" area-hidden="true"></span></a>
		</div>

		<?php do_action( 'tutor_course_filter/before' ); ?>

		<?php if ( in_array( 'search', $supported_filters ) ) : ?>
			<div class="tutor-widget tutor-widget-search">
				<div class="tutor-form-wrap">
					<span class="tutor-icon-search tutor-form-icon" area-hidden="true"></span>
					<input type="Search" class="tutor-form-control" name="keyword" placeholder="<?php esc_attr_e( 'Search', 'tutor' ); ?>"/>
				</div>
			</div>
		<?php endif; ?>

		<?php if ( in_array( 'category', $supported_filters ) ) : ?>
			<!-- Start Widget Area  -->
			<div class="rbt-single-widget rbt-widget-categories has-show-more">
				<div class="inner">
					<h4 class="rbt-widget-title"><?php echo esc_html__('Faculty', 'open-learning'); ?></h4>
					<ul class="rbt-sidebar-list-wrapper categories-list-check has-show-more-inner-content">
						<?php
							$children_cats = array();
							$categories = get_terms(array(
								'taxonomy' 		=> 'course-category',
								'hide_empty'    => false,
								'parent'		=> 0
							));

							if(!empty($categories)):
								foreach($categories as $term):
									$child_terms = get_term_children($term->term_id, 'course-category');

									if (!empty($child_terms)) {
										foreach ($child_terms as $child_term_id) {
											$child_term = get_term_by('id', $child_term_id, 'course-category');
											$children_cats[] = $child_term;
										}
									}
									$post_in_term = new \WP_Query(array('course-category' => $term->slug));
						?>
						<li class="rbt-check-group">
							<input id="<?php echo esc_attr($term->slug); ?>" type="checkbox" name="tutor-course-filter-category" value="<?php echo esc_html($term->term_id); ?>">
							<label for="<?php echo esc_attr($term->slug); ?>"><?php echo esc_html($term->name); ?><span
									class="rbt-lable count"><?php echo esc_html($post_in_term->found_posts); ?></span></label>
						</li>
						<?php wp_reset_query(); endforeach; endif; ?>
					</ul>
				</div>
				<div class="rbt-show-more-btn"><?php echo esc_html__('Show More', 'open-learning'); ?></div>
			</div>

			<div class="rbt-single-widget rbt-widget-categories has-show-more">
				<div class="inner">
					<h4 class="rbt-widget-title"><?php echo esc_html__('Departments', 'open-learning'); ?></h4>
					<ul class="rbt-sidebar-list-wrapper categories-list-check has-show-more-inner-content">
						<?php
							if(!empty($children_cats)):
								foreach($children_cats as $term):
									$post_in_term = new \WP_Query(array('course-category' => $term->slug));
						?>
						<li class="rbt-check-group">
							<input id="<?php echo esc_attr($term->slug); ?>" type="checkbox" name="tutor-course-filter-category" value="<?php echo esc_html($term->term_id); ?>">
							<label for="<?php echo esc_attr($term->slug); ?>"><?php echo esc_html($term->name); ?><span
									class="rbt-lable count"><?php echo esc_html($post_in_term->found_posts); ?></span></label>
						</li>
						<?php wp_reset_query(); endforeach; endif; ?>
					</ul>
				</div>
				<div class="rbt-show-more-btn"><?php echo esc_html__('Show More', 'open-learning'); ?></div>
			</div>
			<!-- End Widget Area  -->
		<?php endif; ?>

		<?php /*if ( in_array( 'tag', $supported_filters ) ) : ?>
			<!-- Start Widget Area  -->
			<div class="rbt-single-widget rbt-widget-categories has-show-more">
				<div class="inner">
					<h4 class="rbt-widget-title"><?php echo esc_html__('Tags', 'open-learning'); ?></h4>
					<ul class="rbt-sidebar-list-wrapper categories-list-check has-show-more-inner-content">
						<?php
							$tags = get_terms(array(
								'taxonomy' => 'course-tag',
								'hide_empty'    => false
							));

							if(!empty($tags)):
								foreach($tags as $term):
									$post_in_term = new \WP_Query(array('course-tag' => $term->slug));
						?>
						<li class="rbt-check-group">
							<input id="<?php echo esc_attr($term->slug); ?>" type="checkbox" name="tutor-course-filter-tag" value="<?php echo esc_html($term->term_id); ?>">
							<label for="<?php echo esc_attr($term->slug); ?>"><?php echo esc_html($term->name); ?><span
									class="rbt-lable count"><?php echo esc_html($post_in_term->found_posts); ?></span></label>
						</li>
						<?php wp_reset_query(); endforeach; endif; ?>
					</ul>
				</div>
				<div class="rbt-show-more-btn"><?php echo esc_html__('Show More', 'open-learning'); ?></div>
			</div>
			<!-- End Widget Area  -->
		<?php endif; */ ?>
		<div class="rbt-single-widget rbt-widget-course-type">
			<div class="inner">
				<h4 class="rbt-widget-title"><?php echo esc_html__('Course Type', 'open-learning'); ?></h4>
			</div>
			
			<ul class="rbt-sidebar-list-wrapper">
				<?php
				// $field = get_field_object('course_type');
				// $course_types = $field['choices'] ?? [];
                $course_types = array(
                    'featured' => 'Featured',
                    'popular' => 'Popular',  
                    'trending' => 'Trending',
                    'latest' => 'Latest',  
                );
				foreach ($course_types as $value => $label) {
			
					$post_in_term = new \WP_Query(array(
						'post_type' => tutor()->course_post_type,
						'post_status' => 'publish',
						'tax_query' => array(
							array(
								'taxonomy' => 'course-category',
								'field' => 'term_id',
								'terms' => $category_id,
							),
						),
						'meta_key' => 'course_type',
						'meta_value' => $value,
					));
					?>
					<li class="rbt-check-group" xx="<?php echo tutor()->course_post_type?>">
						<input id="course_type-<?php echo esc_attr($value) ?>" type="checkbox" name="tutor-course-filter-type[]" value="<?php echo esc_attr($value) ?>">

						<label for="course_type-<?php echo esc_attr($value) ?>"><?php echo esc_html($label) ?>
							<span class="rbt-lable count"><?php echo esc_html($post_in_term->found_posts); ?></span>
						</label>
					</li>	
				<?php } ?>
			</ul>
				
		</div>
		<!-- Start Widget Area  -->
		<div class="rbt-single-widget rbt-widget-rating">
			<div class="inner">
				<h4 class="rbt-widget-title"><?php echo esc_html__('Ratings', 'open-learning'); ?></h4>
				<ul class="rbt-sidebar-list-wrapper rating-list-check">
				    
					<?php /*foreach(range(5,1) as $rate): ?>
						<li class="rbt-check-group">
							<input id="rating-radio-<?php echo $rate ?>" type="radio" name="tutor-course-filter-rating" value="<?php echo $rate ?>">
							<label for="rating-radio-<?php echo $rate ?>">
								<span class="rating">
									<?php for($i=1; $i<=5; $i++):?>
										<?php if($i<=$rate): ?>
											<i class="fas fa-star"></i>
										<?php else: ?>
											<i class="off fas fa-star"></i>
										<?php endif ?>
									<?php endfor;?>
								</span>
								<span class="rbt-lable count"><?php echo $rate; ?></span>
							</label>
						</li>
					<?php endforeach; */ ?>


					<?php foreach(range(5,1) as $rate): 
					
			
					
					?>
						<li class="rbt-check-group">
							<input id="rating-checkbox-<?php echo $rate ?>" type="checkbox" name="tutor-course-filter-rating[]" value="<?php echo $rate ?>">
							<label for="rating-checkbox-<?php echo $rate ?>">
								<span class="rating">
									<?php for($i=1; $i<=5; $i++):?>
										<?php if($i<=$rate): ?>
											<i class="fas fa-star"></i>
										<?php else: ?>
											<i class="off fas fa-star"></i>
										<?php endif ?>
									<?php endfor;?>
								</span>
								<span class="rbt-lable count"><?php echo $rate ?></span>
							</label>
						</li>
					<?php endforeach; ?>
					
				</ul>
			</div>
		</div>
		<!-- End Widget Area  -->

		<!-- Start Widget Area  -->
		<!-- <div class="rbt-single-widget rbt-widget-instructor">
			<div class="inner">
				<h4 class="rbt-widget-title"><?php echo esc_html__('Instructors', 'open-learing'); ?></h4>
				<ul class="rbt-sidebar-list-wrapper instructor-list-check">
					<li class="rbt-check-group">
						<input id="ins-list-1" type="checkbox" name="instructors">
						<label for="ins-list-1">Slaughter <span class="rbt-lable count">15</span></label>
					</li>
					<li class="rbt-check-group">
						<input id="ins-list-2" type="checkbox" name="iinstructors">
						<label for="ins-list-2">Patrick <span class="rbt-lable count">20</span></label>
					</li>
					<li class="rbt-check-group">
						<input id="ins-list-3" type="checkbox" name="instructors">
						<label for="ins-list-3">Angela <span class="rbt-lable count">10</span></label>
					</li>
					<li class="rbt-check-group">
						<input id="ins-list-4" type="checkbox" name="instructors">
						<label for="ins-list-4">Fatima Asrafy <span
								class="rbt-lable count">15</span></label>
					</li>
				</ul>
			</div>
		</div> -->
		<!-- End Widget Area  -->

		<!-- Start Widget Area  -->
		<?php
			$is_membership = get_tutor_option( 'monetize_by' ) == 'pmpro' && tutor_utils()->has_pmpro();
			if ( ! $is_membership && in_array( 'price_type', $supported_filters ) ) :
		?>
		<div class="rbt-single-widget rbt-widget-prices">
			<div class="inner">
				<h4 class="rbt-widget-title"><?php echo esc_html__('Prices', 'open-learning'); ?></h4>
				<ul class="rbt-sidebar-list-wrapper prices-list-check">
					<?php foreach ( $filter_prices as $value => $course_title ) : 
						
					
						$post_in_term = new \WP_Query(array(
							'post_type' => tutor()->course_post_type,
							'post_status' => 'publish',
							'tax_query' => array(
								array(
									'taxonomy' => 'course-category',
									'field' => 'term_id',
									'terms' => $category_id,
								),
							),
							'meta_key' => '_tutor_course_price_type',
							'meta_value' => $value,
						));
						
					?>
					<li class="rbt-check-group">
						<input id="<?php echo esc_html( $value ); ?>" type="checkbox" name="tutor-course-filter-price" value="<?php echo esc_html( $value ); ?>">
						<label for="<?php echo esc_html( $value ); ?>"><?php echo esc_html( $course_title ); ?>
						<span class="rbt-lable count"><?php echo esc_html($post_in_term->found_posts); ?></span></label>
					</li>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>
		<?php endif; ?>
		
		<!-- End Widget Area  -->

		<!-- Start Widget Area  -->
		<?php if ( in_array( 'difficulty_level', $supported_filters ) ) : ?>
		<div class="rbt-single-widget rbt-widget-lavels">
			<div class="inner">
				<h4 class="rbt-widget-title"><?php echo esc_html__('Levels', 'oepn-learning'); ?></h4>
				<ul class="rbt-sidebar-list-wrapper lavels-list-check">
					<?php
						$key = '';
						foreach ( $course_levels as  $value => $course_title ) :
						if ( 'all_levels' == $key ) {
							continue;
						}

						$args = array(
							'post_type' => tutor()->course_post_type,
							'post_status' => 'publish',
							'tax_query' => array(
								array(
									'taxonomy' => 'course-category',
									'field' => 'term_id',
									'terms' => $category_id,
								),
							),
						);


				

						if('all_levels' != $key){
							$args['meta_query'] = [['key' => '_tutor_course_level', 'value'=> $value]];
						}

						$post_in_term = new \WP_Query($args);
					?>
					<li class="rbt-check-group">
						<input id="<?php echo esc_html( $value ); ?>" type="checkbox" name="tutor-course-filter-level" value="<?php echo esc_html( $value ); ?>">
						<label for="<?php echo esc_html( $value ); ?>"><?php echo esc_html( $course_title ); ?>
						<span class="rbt-lable count"><?php echo esc_html($post_in_term->found_posts); ?></span></label>
					</li>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>
		<?php endif; ?>
		
		<!-- End Widget Area  -->
		<div class="rbt-single-widget rbt-widget-duration">
			<div class="inner">
				<h4 class="rbt-widget-title"><?php echo esc_html__('Duration', 'open-learning'); ?></h4>
				<ul class="rbt-sidebar-list-wrapper">
				    <?php foreach ([
				        '<=30' => 'Less Than 30 Hours',
				        '31-60' => '31-60 Hours',
				        '61-100' => '61-100 Hours',
				        '101-150' => '101-150 Hours',
				        '151-200' => '151-200 Hours',
				        '>200' => '200+ Hours',
				    ] as  $value => $label ) : 
				  
							
						$relationSTR = 'BETWEEN';

						$valueArgs = explode('-', $value);

						if($value == '<=30'){

							$relationSTR = '<=';
				
							$valueArgs = [intval(str_replace($relationSTR, '', $value))];
				
						}elseif($value == '>200'){
							$relationSTR = '>';
							$valueArgs = [intval(str_replace($relationSTR, '', $value))];
						}
						
						$meta_query = array();

						if(count($valueArgs) > 1){

							$meta_query[] = [
								'key' => '_course_duration_hours',
								'value' => [intval($valueArgs[0]), intval($valueArgs[1])],
								'compare' => $relationSTR
							];
							
						}else{
							$meta_query[] = [
								'key' => '_course_duration_hours',
								'value' => $valueArgs[0],
								'compare' => $relationSTR,
							];
						}
						
						$post_in_term = new \WP_Query(array(
							'post_type' => tutor()->course_post_type,
							'post_status' => 'publish',
							'tax_query' => array(
								array(
									'taxonomy' => 'course-category',
									'field' => 'term_id',
									'terms' => $category_id,
								),
							),
							'meta_query' => $meta_query
						));

				    ?>
					<li class="rbt-check-group">
						<input id="duration_checbox-<?php echo esc_html( str_replace(['>=','<=','>', '<'], '_', $value) ); ?>" type="checkbox" name="tutor-course-filter-duration[]" value="<?php echo esc_html( $value ); ?>">
						<label for="duration_checbox-<?php echo esc_html( str_replace(['>=','<=','>', '<'], '_', $value) ); ?>"><?php echo esc_html( $label ); ?>
						<span class="rbt-lable count"><?php echo esc_html($post_in_term->found_posts); ?></span>
						</label>
					</li>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>
		
		<div class="rbt-single-widget rbt-widget-language">
			<div class="inner">
				<h4 class="rbt-widget-title"><?php echo esc_html__('Language', 'open-learning'); ?></h4>
				<ul class="rbt-sidebar-list-wrapper">
					<?php foreach ([
							'English' => 'English',
							'Spanish' => 'Spanish',
							'French' => 'French',
							'German' => 'German',
						] as  $value => $label ) : 
							// $post_in_term = new \WP_Query(array(
							// 	//'post_type' => tutor()->course_post_type,
							// 	'cat' => $tutor_course_category_id,
							// 	'post_status' => 'publish',
							// 	'meta_query' => ['relation' => 'OR', ['key' => 'course_language', 'value'=> $value],['key' => 'course_language', 'value'=> strtolower($value)]]
							// ));


							$post_in_term = new \WP_Query(array(
								'post_type' => tutor()->course_post_type,
								'post_status' => 'publish',
								'tax_query' => array(
									array(
										'taxonomy' => 'course-category',
										'field' => 'term_id',
										'terms' => $category_id,
									),
								),
								'meta_key' => 'course_language',
								'meta_value' => $value,
							));

							
						?>
					<li class="rbt-check-group">
						<input id="language_checbox-<?php echo esc_html( str_replace(' ', '_', $value) ); ?>" type="checkbox" name="tutor-course-filter-lang[]" value="<?php echo esc_html( $value ); ?>">
						<label for="language_checbox-<?php echo esc_html( str_replace(' ', '_', $value) ); ?>"><?php echo esc_html( $label ); ?>
						<span class="rbt-lable count"><?php echo esc_html($post_in_term->found_posts); ?></span>
						</label>
					</li>	
					<?php endforeach; ?>
				</ul>
			</div>
		</div>
		
		
		<div class="tutor-widget tutor-widget-course-filter tutor-mt-32">
			<div class="tutor-widget-content">
				<a href="#" class="rbt-btn btn-border radius-round-10 btn-sm refresh-btn" onclick="window.location.replace('<?php echo esc_url( $reset_link ); ?>')" action-tutor-clear-filter>
					<i class="tutor-icon-times tutor-mr-8"></i> <?php esc_html_e( 'Clear All Filters', 'tutor' ); ?>
				</a>
			</div>
		</div>
	</aside>
	<?php do_action( 'tutor_course_filter/after' ); ?>
</form>
