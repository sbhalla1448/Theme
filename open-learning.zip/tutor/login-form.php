<?php
/**
 * Tutor login form template
 *
 * @package Tutor\Templates
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 2.0.1
 */

use TUTOR\Ajax;

$lost_pass = apply_filters( 'tutor_lostpassword_url', wp_lostpassword_url() );
/**
 * Get login validation errors & print
 *
 * @since 2.1.3
 */
$login_errors = get_transient( Ajax::LOGIN_ERRORS_TRANSIENT_KEY ) ? get_transient( Ajax::LOGIN_ERRORS_TRANSIENT_KEY ) : array();
foreach ( $login_errors as $login_error ) {
?>


<div class="tutor-alert tutor-warning tutor-mb-12" style="display:block; grid-gap: 0px 10px;">
		<?php
		echo wp_kses(
			$login_error,
			array(
				'strong' => true,
				'a'      => array(
					'href'  => true,
					'class' => true,
					'id'    => true,
				),
				'p'      => array(
					'class' => true,
					'id'    => true,
				),
				'div'    => array(
					'class' => true,
					'id'    => true,
				),
			)
		);
		?>
	</div>
	<?php
}

do_action( 'tutor_before_login_form' );
?>

<div class="form-wrapper">
	
	
	
	
<form class="max-width-auto form-holder" id="tutor-login-form" method="post">
	<?php if ( is_single_course() ) : ?>
		<input type="hidden" name="tutor_course_enroll_attempt" value="<?php echo esc_attr( get_the_ID() ); ?>">
	<?php endif; ?>
	<?php tutor_nonce_field(); ?>
	<input type="hidden" name="tutor_action" value="tutor_user_login" />
	<input type="hidden" name="redirect_to" value="<?php echo esc_url( apply_filters( 'tutor_after_login_redirect_url', tutor()->current_url ) ); ?>" />
	<div class="form-heading">  
		<h2>Welcome Back To <span>Log In</span> </h2>
		<p>Embark on a transformative learning journey by joining our vibrant community of learners. Explore a wide range.</p>
	</div>
	<div class="form-group">
		<select class="form-control" required>
			<option value="">Registration Type*</option>
			<option value="Student">Student</option>
			<option value="Educators">Educators</option>
			<option value="Course Provider">Course Provider</option>
			<option value="Business Pro">Business Pro</option>
			<option value="Business (SME)">Business (SME)</option>
			<option value="Registered Charity">Registered Charity</option>
			<option value="Nursery & Schools">Nursery & Schools</option>
		</select>
	  </div>
	<div class="form-group">
		<input type="email" name="log" value="" size="20" required>
		<label><?php esc_html_e('Email', 'open-learning'); ?>*</label>
	</div>
	<div class="form-group password-wrap">
		<input type="password" class="tutor-form-control" name="pwd" value="" size="20" required>
		<label><?php esc_html_e('Choose a Password', 'open-learning'); ?>*</label>
	</div>
	<div class="forgot-password-wrap">
		<a class="rbt-btn-link" href="<?php echo esc_url( $lost_pass ); ?>"><?php esc_html_e('Forgot Password?', 'open-learning'); ?></a>
	</div>
		
	
	<div class="tutor-login-error"></div>
	
	<?php
		do_action( 'tutor_login_form_middle' );
		do_action( 'login_form' );
		apply_filters( 'login_form_middle', '', '' );
	?>

	

	<?php do_action( 'tutor_login_form_end' ); ?>
	<div class="form-submit-group">
		<button type="submit" class="rbt-btn btn-md btn-gradient hover-icon-reverse w-100 mt-50">
			<span class="icon-reverse-wrapper">
				<span class="btn-text"><?php esc_html_e('Log In', 'open-learning'); ?></span>
				<span class="btn-icon"><i class="feather-arrow-right"></i></span>
				<span class="btn-icon"><i class="feather-arrow-right"></i></span>
			</span>
		</button>
	</div>
	<?php if ( get_option( 'users_can_register', false ) ) : ?>
		<?php
			$url_arg = array(
				'redirect_to' => tutor()->current_url,
			);
			if ( is_single_course() ) {
				$url_arg['enrol_course_id'] = get_the_ID();
			}
			?>
		<div class="tutor-text-center tutor-text-info tutor-color-secondary tutor-mt-20">
			<?php esc_html_e( 'Don\'t have an account?', 'tutor' ); ?>&nbsp;
			<a href="<?php echo esc_url( add_query_arg( $url_arg, tutor_utils()->student_register_url() ) ); ?>" class="tutor-btn tutor-btn-link">
				<?php esc_html_e( 'Sign Up', 'tutor' ); ?>
			</a>
		</div>
	<?php endif; ?>
	<?php do_action( 'tutor_after_sign_in_button' ); ?>
</form>

	

	
	<div class="register-thumb-wrap">
		<div class="register-thumb-inner">
			<div class="thumb-info">
			<h2>Unlock Your Brilliance with Online Courses</h2>
			<p>Embark on a transformative learning journey by joining our vibrant community of learners. Explore a wide range.</p>
			<div class="top-review-wrap">
				<img src="https://openlearningcollege.ac/wp-content/uploads/2023/12/Frame-1246.png" alt="" >
			
			</div>
		</div>
		</div>
		
	</div>
</div>

<?php
do_action( 'tutor_after_login_form' );
if ( ! tutor_utils()->is_tutor_frontend_dashboard() ) : ?>
<script>
	document.addEventListener('DOMContentLoaded', function() {
		var { __ } = wp.i18n;
		var loginModal = document.querySelector('.tutor-modal.tutor-login-modal');
		var errors = <?php echo wp_json_encode( $login_errors ); ?>;
		if (loginModal && errors.length) {
			loginModal.classList.add('tutor-is-active');
		}
	});
</script>
<?php endif; ?>
<?php delete_transient( Ajax::LOGIN_ERRORS_TRANSIENT_KEY ); ?>
