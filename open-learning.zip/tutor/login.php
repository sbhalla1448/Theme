<?php
/**
 * Display single login
 *
 * @package Tutor\Templates
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! tutor_utils()->get_option( 'enable_tutor_native_login', null, true, true ) ) {
	// Redirect to wp native login page.
	header( 'Location: ' . wp_login_url( tutor_utils()->get_current_url() ) );
	exit;
}

tutor_utils()->tutor_custom_header();
$login_url = tutor_utils()->get_option( 'enable_tutor_native_login', null, true, true ) ? '' : wp_login_url( tutor()->current_url );
?>

<?php
//phpcs:ignore WordPress.NamingConventions.ValidHookName.UseUnderscores
do_action( 'tutor/template/login/before/wrap' );
?>

<div <?php tutor_post_class( 'tutor-page-wrap' ); ?>>
	<div class="rbt-elements-area bg-color-white rbt-section-gap">
		<div class="container">
			<div class="row gy-5 row--30">
				<div class="col-lg-6 m-auto">
					<div class="rbt-contact-form contact-form-style-1 max-width-auto">
						<h3 class="title"><?php esc_html_e( 'Hi, Welcome back!', 'tutor' ); ?></h3>
						<?php
							// load form template.
							$login_form = trailingslashit( get_parent_theme_file_path('/tutor') ) . '/login-form.php';
							tutor_load_template_from_custom_path(
								$login_form,
								false
							);
						?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
	//phpcs:ignore WordPress.NamingConventions.ValidHookName.UseUnderscores
	do_action( 'tutor/template/login/after/wrap' );
	tutor_utils()->tutor_custom_footer();
?>