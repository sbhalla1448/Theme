<?php
/**
 * Course thumb header
 *
 * @package Tutor\Templates
 * @subpackage CourseLoopPart
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.5.8
 */

?>

<?php tutor_course_loop_thumbnail(); ?>
