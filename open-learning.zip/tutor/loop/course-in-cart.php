<?php
/**
 * Course loop show view cart if in added to.
 *
 * @package Tutor\Templates
 * @subpackage CourseLoopPart
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.7.5
 */

?>

<?php
	$course_id     = get_the_ID();
	$cart_url      = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : '#';
	$enroll_btn    = '<a href="' . $cart_url . '" class="rbt-btn-custom"><span class="tutor-icon-cart-line tutor-mr-8"></span><span>' . __( 'View Cart', 'tutor' ) . '</span></a>';
	$default_price = apply_filters( 'tutor-loop-default-price', __( 'Free', 'tutor' ) );
	$price_html    = '<div class="price"> ' . $default_price . $enroll_btn . '</div>';
	if ( tutor_utils()->is_course_purchasable() ) {

		$product_id = tutor_utils()->get_course_product_id( $course_id );
		$product    = wc_get_product( $product_id );

		if ( $product ) {
			$price_html = '<div class="rbt-price">';
			if( $product->get_sale_price() ){
				$price_html .= '<span class="current-price">'.get_woocommerce_currency_symbol().$product->get_sale_price().'</span>';
				$price_html .= '<span class="off-price">'.get_woocommerce_currency_symbol().$product->get_regular_price().'</span>';
			}else{
				$price_html .= '<span class="current-price">'.get_woocommerce_currency_symbol().$product->get_price().'</span>';
			}
			$price_html .= '</div>';
			$cart_html  = apply_filters( 'tutor_course_restrict_new_entry', $enroll_btn );
		}
	}
	echo wp_kses_post( $price_html );
	echo wp_kses_post( $cart_html );
?>