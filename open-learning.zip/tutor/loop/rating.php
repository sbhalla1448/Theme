<?php
/**
 * A single course loop rating
 *
 * @package Tutor\Templates
 * @subpackage CourseLoopPart
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.4.3
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$class               = isset( $class ) ? ' ' . $class : ' tutor-mb-8';
$show_course_ratings = apply_filters( 'tutor_show_course_ratings', true, get_the_ID() );
$course_rating = tutor_utils()->get_course_rating();
?>
<div class="rbt-card-top">
	<div class="rbt-review d-flex align-items-center">
		<div class="rating">
			<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
				<path d="M14.1392 6.11669L10.172 5.54013L8.3986 1.94482C8.35016 1.84638 8.27048 1.76669 8.17204 1.71826C7.92516 1.59638 7.62516 1.69794 7.50173 1.94482L5.72829 5.54013L1.7611 6.11669C1.65173 6.13232 1.55173 6.18388 1.47516 6.262C1.3826 6.35714 1.3316 6.48513 1.33336 6.61785C1.33511 6.75057 1.38949 6.87717 1.48454 6.96982L4.35485 9.76825L3.67673 13.7198C3.66082 13.8117 3.671 13.9063 3.70609 13.9927C3.74118 14.0791 3.79979 14.154 3.87527 14.2088C3.95075 14.2637 4.04008 14.2962 4.13313 14.3029C4.22618 14.3095 4.31923 14.2899 4.40173 14.2464L7.95016 12.3808L11.4986 14.2464C11.5955 14.2979 11.708 14.3151 11.8158 14.2964C12.0877 14.2495 12.2705 13.9917 12.2236 13.7198L11.5455 9.76825L14.4158 6.96982C14.4939 6.89325 14.5455 6.79325 14.5611 6.68388C14.6033 6.41044 14.4127 6.15732 14.1392 6.11669Z" fill="#FFDC5D"/>
			</svg>
		</div>
		<span class="rating-count"> <?php echo esc_html( apply_filters( 'tutor_course_rating_average', $course_rating->rating_avg ) ); ?> (<?php echo esc_html( $course_rating->rating_count > 0 ? $course_rating->rating_count : 0 ); ?> Reviews)</span>
	</div>
</div>
<?php do_action( 'tutor_after_course_loop_rating', get_the_ID() ); ?>
