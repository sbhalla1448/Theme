<?php
/**
 * Walker Menu Class
 */
class OLC_Menu_Walker extends Walker_Nav_Menu {

    public function start_el(&$output, $item, $depth=0, $args=[], $id=0) {
   
        $mega_menu = function_exists('get_field')? get_field('mega_menu', $item) : false;
        $position = 'static';
        $classes = $item->classes;

        if ($mega_menu && $position == 'static' ) {
            $classes[] = ' with-megamenu has-menu-child-item position-static';
        }
        if($mega_menu && $position == 'relative'){
            $classes[] = ' with-megamenu has-menu-child-item';
        }
        if( is_object($args) && $args->walker->has_children){
            $classes[] = ' has-dropdown has-menu-child-item';
        }

        if( !empty($classes) ){
            $output .= "<li class='" .  implode(" ", $classes) . "'>";
        }

        if ($item->url && $item->url != '#') {
            $output .= '<a href="' . $item->url . '">';
        } else {
            $output .= '<a href="' . $item->url . '">';
        }
 
        $output .= $item->title;
        if ( (is_object($args) && $args->walker->has_children) || $mega_menu) {
            $output .= '<i class="feather-chevron-down"></i>';
        }
 
        if ($item->url && $item->url != '#') {
            $output .= '</a>';
        } else {
            $output .= '</a>';
        }

        if($mega_menu){
            $output .= "<div class='rbt-megamenu'>";
            $output .= \Elementor\Plugin::instance()->frontend->get_builder_content_for_display($mega_menu->ID);
            $output .= '</div>';
        }
 
    }

    public function start_lvl(&$output, $depth = 0, $args = array()) {
        // $indent = str_repeat("\t", $depth);
        // $output .= "\n$indent<ul class=\"my-sub-menu\">\n";
        $output .= "<ul class='submenu'>";
    }
}