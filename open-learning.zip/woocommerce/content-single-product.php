<?php
/**
 * The template for displaying product content in the single-product.php template
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.6.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

if ( post_password_required() ) {
	echo get_the_password_form(); // WPCS: XSS ok.
	return;
}
?>
<div class="rbt-single-product-area rbt-single-product rbt-section-gap">
    <div class="container">
        <div class="row g-5 row--30 align-items-center">
            <div class="col-md-12">
                <?php
                /**
                 * Hook: woocommerce_before_single_product.
                 *
                 * @hooked woocommerce_output_all_notices - 10
                 */
                do_action( 'woocommerce_before_single_product' );
                ?>
            </div>
        </div>
        <div class="row g-5 row--30 align-items-center">
            <div class="col-lg-6">
                <div class="thumbnail">
                    <?php woocommerce_show_product_images(); ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="content">
                    <div class="rbt-review justify-content-start">
                        <div class="rating">
                            <?php woocommerce_template_single_rating(); ?>
                        </div>
                        <span class="rating-count">(75) - 100% Positive Reviews</span>
                    </div>

                    <h2 class="title mt--10 mb--10"><?php woocommerce_template_single_title(); ?></h2>
                    <span class="rbt-label-style description">By: Hal Elrod</span>

                    <div class="rbt-price justify-content-start mt--10">
                        <?php woocommerce_template_single_price(); ?>
                    </div>

                    <p class="mt--20"><?php woocommerce_template_single_excerpt(); ?></p>

                    
                    <?php woocommerce_template_single_add_to_cart(); ?>

                    <ul class="product-feature">
                        <?php if ( wc_product_sku_enabled() && ( $product->get_sku() || $product->is_type( 'variable' ) ) ) : ?>
                            <li>
                                <span><?php echo esc_html__( 'SKU : ', 'open-learning' ); ?></span>
                                <?php if( $sku = $product->get_sku() ) { echo esc_html($sku); } else { echo esc_html( 'N/A' ); } ?>
                            </li>
                        <?php endif; ?>
                        <?php
                            $categories = get_the_terms( $product->get_id(), 'product_cat' );
                        ?>
                        <?php if(!empty($categories)): ?>
                        <li>
                            <span><?php _e('Categories:', 'open-learning'); ?></span> 
                            <?php
                                $cat_html = '';
                                foreach($categories as $category){
                                    $cat_html .= '<a href="'.get_term_link( $category ).'">'.esc_html($category->name).'</a>, ';
                                }

                                echo rtrim($cat_html, ', ');
                            ?>
                        </li>
                        <?php endif; ?>
                        <?php
                            $tags = get_the_terms( $product->get_id(), 'product_tag' );
                        ?>
                        <?php if(!empty($tags)): ?>
                        <li>
                            <span><?php _e('Tags:', 'open-learning'); ?></span>
                            <?php
                                $tags_html = '';
                                foreach($tags as $tag){
                                    $tags_html .= '<a href="'.get_term_link( $tag ).'">'.esc_html($tag->name).'</a>, ';
                                }

                                echo rtrim($tags_html, ', ');
                            ?>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
    woocommerce_output_product_data_tabs();
    woocommerce_output_related_products();
?>
