<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.6.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

// Ensure visibility.
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}
?>

<!-- Start Single Product  -->
<div class="col-lg-4 col-md-6 col-12">
    <div class="rbt-default-card style-three rbt-hover">
        <div class="inner">
            <div class="content pt--0 pb--10">
                <h2 class="title"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h2>
                <span class="team-form">
                    <span class="location"><?php echo sprintf('By %s', ucwords(get_the_author())); ?></span>
                </span>
            </div>
            <div class="thumbnail"><a href="<?php echo get_the_permalink(); ?>"><img src="<?php echo wp_get_attachment_image_url( $product->get_image_id(), 'large' )?>" alt="<?php echo get_the_title(); ?>"></a></div>
            <div class="content">
                <div class="rbt-review justify-content-center">
                    <?php woocommerce_template_loop_rating(); ?>
                </div>
                <div class="rbt-price justify-content-center mt--10">
                    <?php woocommerce_template_loop_price(); ?>
                </div>
                <div class="addto-cart-btn mt--20">
                    <?php woocommerce_template_loop_add_to_cart(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Single Product  -->