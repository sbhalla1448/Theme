<?php
/**
 * Review order table
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/review-order.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 5.2.0
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="woocommerce-checkout-review-order-table">
    <!-- Cart Total -->
    <div class="col-12 mb--60">
        <h4 class="checkout-title">Cart Total</h4>
        <div class="checkout-cart-total">
            <h4>Product <span>Total</span></h4>
            <ul>
            <?php
            foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
                $_product = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );

                if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_checkout_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
                    ?>
            <li
                class="<?php echo esc_attr( apply_filters( 'woocommerce_cart_item_class', 'cart_item', $cart_item, $cart_item_key ) ); ?>">
                <?php echo wp_kses_post( apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key ) ) . '&nbsp;'; ?>
                <?php echo wc_get_formatted_cart_item_data( $cart_item ); ?>
                X
                <?php echo apply_filters( 'woocommerce_checkout_cart_item_quantity', ' <strong class="product-quantity">' . sprintf( '&nbsp;%s', $cart_item['quantity'] ) . '</strong>', $cart_item, $cart_item_key );?>
                <span><?php echo apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $_product, $cart_item['quantity'] ), $cart_item, $cart_item_key ); ?></span>
            </li>
            <?php
                }
            }
            ?>
            </ul>

            <p><?php _e('Sub Total', 'open-learning'); ?> <span><?php echo get_woocommerce_currency_symbol().WC()->cart->subtotal; ?></span></p>
            <?php foreach ( WC()->cart->get_coupons() as $code => $coupon ) : ?>
            <p class="cart-discount coupon-<?php echo esc_attr( sanitize_title( $code ) ); ?>">
                <?php wc_cart_totals_coupon_label( $coupon ); ?>
                <?php
                    $discount_amount_html = '';

                    $amount               = WC()->cart->get_coupon_discount_amount( $coupon->get_code(), WC()->cart->display_cart_ex_tax );
                    $discount_amount_html = '-' . wc_price( $amount );
                
                    if ( $coupon->get_free_shipping() && empty( $amount ) ) {
                    $discount_amount_html = esc_html__( 'Free shipping coupon', 'open-learning' );
                    }
                    echo apply_filters( 'woocommerce_coupon_discount_amount_html', $discount_amount_html, $coupon );

                    $coupon_html = ' <a href="' . esc_url( add_query_arg( 'remove_coupon', rawurlencode( $coupon->get_code() ), defined( 'WOOCOMMERCE_CHECKOUT' ) ? wc_get_checkout_url() : wc_get_cart_url() ) ) . '" class="woocommerce-remove-coupon py-2 px-3 btn btn-sm text-white" data-coupon="' . esc_attr( $coupon->get_code() ) . '">' . esc_html__( 'Remove', 'open-learning' ) . '</a>';

                    echo apply_filters( 'woocommerce_cart_totals_coupon_html', $coupon_html);
                ?>
            </p>
            <?php endforeach; ?>

            <?php if ( WC()->cart->needs_shipping() && WC()->cart->show_shipping() ) : ?>

            <?php // wc_cart_totals_shipping_html(); ?>

            <?php endif; ?>

            <?php foreach ( WC()->cart->get_fees() as $fee ) : ?>
            <p class="fee">
                <?php echo esc_html( $fee->name ); ?>
                <span><?php wc_cart_totals_fee_html( $fee ); ?></span>
            </p>
            <?php endforeach; ?>

            <?php if ( wc_tax_enabled() && ! WC()->cart->display_prices_including_tax() ) : ?>
            <?php if ( 'itemized' === get_option( 'woocommerce_tax_total_display' ) ) : ?>
            <?php foreach ( WC()->cart->get_tax_totals() as $code => $tax ) : ?>
            <p class="tax-rate tax-rate-<?php echo esc_attr( sanitize_title( $code ) ); ?>">
                <?php echo esc_html( $tax->label ); ?>
                <span><?php echo wp_kses_post( $tax->formatted_amount ); ?></span>
            </p>
            <?php endforeach; ?>
            <?php else : ?>
            <p class="tax-total">
                <?php echo esc_html( WC()->countries->tax_or_vat() ); ?>
                <span><?php wc_cart_totals_taxes_total_html(); ?></span>
            </p>
            <?php endif; ?>
            <?php endif; ?>
            <h4 class="mt--30"><?php _e('Grand Total', 'open-learning'); ?> <span><?php echo get_woocommerce_currency_symbol().WC()->cart->total;?></span></h4>
        </div>
    </div>
</div>