<?php
/**
 * Checkout shipping information form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/form-shipping.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.6.0
 * @global WC_Checkout $checkout
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="col-12">
	<?php if ( true === WC()->cart->needs_shipping_address() ) : ?>

		<div class="different-address custom-control custom-checkbox" id="ship-to-different-address">
            <input class="custom-control-input" id="stda" <?php checked( apply_filters( 'woocommerce_ship_to_different_address_checked', 'shipping' === get_option( 'woocommerce_ship_to_destination' ) ? 1 : 0 ), 1 ); ?> type="checkbox" name="ship_to_different_address" value="1" /> <label class="custom-control-label" for="stda"><?php esc_html_e( 'Ship to a different address?', 'open-learning' ); ?></label>
        </div>

		<div class="shipping_address">

			<?php do_action( 'woocommerce_before_checkout_shipping_form', $checkout ); ?>

			<div class="row">
				<?php
					$fields = $checkout->get_checkout_fields( 'shipping' );
					$fields_type = array('shipping_company', 'shipping_country', 'shipping_address_1', 'shipping_address_2');
					foreach($fields as $key => $field){
						if( in_array($key, $fields_type)){
							$field['class'][] = 'form-grp col-12';
						}else{
							$field['class'][] = 'form-grp col-sm-6';
						}
						woocommerce_form_field( $key, $field, $checkout->get_value( $key ) );
					}
				?>
			</div>

			<?php do_action( 'woocommerce_after_checkout_shipping_form', $checkout ); ?>

		</div>

	<?php endif; ?>
</div>
<div class="col-12">
    <div class="form-grp mb-0">
	<?php do_action( 'woocommerce_before_order_notes', $checkout ); ?>

	<?php if ( apply_filters( 'woocommerce_enable_order_notes_field', 'yes' === get_option( 'woocommerce_enable_order_comments', 'yes' ) ) ) : ?>

		<?php 
            $order_fields = $checkout->get_checkout_fields( 'order' );
        ?>
        <label for="<?php echo esc_attr('order_comments'); ?>"><?php echo esc_html__('ORDER you have NOTES', 'open-learning'); ?> <small>(<?php echo esc_html__( 'OPTIONAL', 'open-learning' ); ?>)</small></label>
        <textarea name="<?php echo esc_attr('order_comments'); ?>" id="<?php echo esc_attr('order_comments'); ?>" placeholder="<?php echo esc_html($order_fields['order_comments']['placeholder']); ?>"></textarea>

	<?php endif; ?>

	<?php do_action( 'woocommerce_after_order_notes', $checkout ); ?>
    </div>
</div>
