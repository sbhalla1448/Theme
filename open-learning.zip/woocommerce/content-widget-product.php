<?php
/**
 * The template for displaying product widget entries.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-widget-product.php.
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.5.5
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $product;

if ( ! is_a( $product, 'WC_Product' ) ) {
	return;
}

$average      = $product->get_average_rating();
?>
<li>
    
    <?php do_action( 'woocommerce_widget_product_item_start', $args ); ?>


    <div class="sidebar-product-thumb">
        <a href="<?php echo esc_url( $product->get_permalink() ); ?>">
            <?php echo wp_kses_post( $product->get_image() ); ?>
        </a>
    </div>
    <div class="sidebar-product-content">
        <?php if ( ! empty( $show_rating ) ) : ?>
        <div class="rating">
            <?php for($i = 1; $i <= $average; $i++):?>
                <i class="fas fa-star"></i>
            <?php endfor; ?>
            <?php if( $average % 2 == 1 && $average != 5 ): ?>
                <i class="fas fa-star-half"></i>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <h5>
            <a href="<?php echo esc_url( $product->get_permalink() ); ?>"><?php echo esc_html( $product->get_name() ); ?></a>
        </h5>
        <?php echo sprintf( '<span>%1$s %2$s</span>', get_woocommerce_currency_symbol(), $product->get_price() ); ?>
    </div>

    

    <?php do_action( 'woocommerce_widget_product_item_end', $args ); ?>
</li>