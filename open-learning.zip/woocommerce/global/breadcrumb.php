<?php
/**
 * Shop breadcrumb
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/global/breadcrumb.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     2.3.0
 * @see         woocommerce_breadcrumb()
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<?php if(is_shop() || is_product_category()): ?>
<div class="rbt-page-banner-wrapper">
    <!-- Start Banner BG Image  -->
    <div class="rbt-banner-image"></div>
    <!-- End Banner BG Image  -->
    <div class="rbt-banner-content">

        <!-- Start Banner Content Top  -->
        <div class="rbt-banner-content-top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <!-- Start Breadcrumb Area  -->
                        <ul class="page-list">
                            <li class="rbt-breadcrumb-item"><a href="<?php echo home_url('/'); ?>">Home</a></li>
                            <li>
                                <div class="icon-right"><i class="feather-chevron-right"></i></div>
                            </li>
                            <li class="rbt-breadcrumb-item active"><?php _e('All Products', 'open-learning'); ?></li>
                        </ul>
                        <!-- End Breadcrumb Area  -->

                        <div class=" title-wrapper">
                            <h1 class="title mb--0"><?php _e('All Products', 'open-learning'); ?></h1>
                            <a href="#" class="rbt-badge-2">
                                <div class="image">🎉</div>
                                <?php echo sprintf('%s Products', esc_html(wc_get_loop_prop( 'total' ))); ?>
                            </a>
                        </div>

                        <p class="description">Products that help beginner designers become true unicorns.</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Banner Content Top  -->

        <!-- Start Course Top  -->
        <div class="rbt-course-top-wrapper mt--40">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-5 col-md-12">
                        <div class="rbt-sorting-list d-flex flex-wrap align-items-center">
                            <div class="rbt-short-item">
                                <span class="course-index"><?php woocommerce_result_count(); ?></span>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-7 col-md-12">
                        <div class="rbt-sorting-list d-flex flex-wrap align-items-center justify-content-start justify-content-lg-end">
                            <div class="rbt-short-item">
                                <div class="filter-select">
                                    <span class="select-label d-block"><?php _e('Short By', 'open-learning'); ?></span>
                                    <div class="filter-select rbt-modern-select search-by-category">
                                        <div class="dropdown bootstrap-select">
                                        <?php woocommerce_catalog_ordering(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- End Course Top  -->
    </div>
</div>
<?php endif; ?>
<?php if(is_singular()): ?>
    <!-- <div class="rbt-breadcrumb-default ptb--100 ptb_md--50 ptb_sm--30 bg-gradient-1">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-inner text-center">
                        <h2 class="title"><?php single_post_title(); ?></h2>
                        <ul class="page-list">
                            <li class="rbt-breadcrumb-item"><a href="<?php echo home_url('/'); ?>">Home</a></li>
                            <li>
                                <div class="icon-right"><i class="feather-chevron-right"></i></div>
                            </li>
                            <li class="rbt-breadcrumb-item active"><?php single_post_title(); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
<?php endif; ?>