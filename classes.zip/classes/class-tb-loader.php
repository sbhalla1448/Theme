<?php

use JetBrains\PhpStorm\Internal\ReturnTypeContract;

/**
 * 
 * This is the loader class for loading assets and other files
 * @package OLC
 * @version 1.0.0
 * 
 */

 final class Loader {

   private static $styles = array();
   private static $scripts = array();
   private static $instance = false;


   function __construct(){
      add_action( 'wp_enqueue_scripts',  array($this, 'enqueue') );
   }

   static function style($name, $src){
      array_push(
         self::$styles,
         array($name => $src)
      );
   }


   static function script($name, $src){
      array_push(
         self::$scripts,
         array($name => $src)
      );
   }


   static function enqueue(){
      wp_enqueue_style( 'fontawesome-cdn', '//cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', array(), time(), 'all' );
      foreach(self::$styles as $style){
         foreach($style as $key => $val){
            if( $val == 'main' ){
               wp_enqueue_style( $key, get_stylesheet_uri(), array(), time(), 'all' );
            }else{
               wp_enqueue_style( $key, get_template_directory_uri() . $val, array(), time(), 'all' );
            }
         }
      }

      foreach(self::$scripts as $script){
         foreach($script as $key => $val){
            wp_enqueue_script( $key, get_template_directory_uri() . $val, array('jquery'), time(), true );
         }
      }
   }


   static function load(){
      if( !self::$instance ){
         self::$instance = new self();
      }

      return self::$instance;
   }
 }

