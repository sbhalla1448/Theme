jQuery(document).ready(function ($) {
	$(document).on('click', '.tutor-course-content-list-item', function () {
		window.location.href = $(this).find('a').attr('href')
	})
	$(document).on('click', '.tutor-course-wishlist-btn-custom', function (e) {
		e.preventDefault();
		var $that = $(this);
		var course_id = $that.attr('data-course-id');

		$.ajax({
			url: _tutorobject.ajaxurl,
			type: 'POST',
			data: {
				course_id,
				action: 'tutor_course_add_to_wishlist',
			},
			beforeSend: function () {
				$that.attr('disabled', 'disabled').addClass('is-loading');
				let icon = $that.find('i').hasClass('tutor-icon-bookmark-bold') ? 'tutor-icon-bookmark-bold' : 'tutor-icon-bookmark-line'
				$that
					.find('i')
					.removeClass(icon)
					.addClass('fa fa-spinner fa-spin')
			},
			success: function (data) {
				console.log(data)
				if (data.success) {
					if (data.data.status === 'added') {
						$that
							.find('i')
							.removeClass('fa fa-spinner fa-spin')
							.addClass('tutor-icon-bookmark-bold')
					} else {
						$that
							.find('i')
							.removeClass('fa fa-spinner fa-spin')
							.addClass('tutor-icon-bookmark-line')
					}
				} else {
					//window.location = data.data.redirect_to;
					$('.tutor-login-modal').addClass('tutor-is-active');
				}
			},
			error: function (err) {
				//window.location = data.data.redirect_to;
				console.log(err)
			},
			complete: function () {
				$that.removeAttr('disabled').removeClass('is-loading');
			},
		});
	})
	// Search filter 

	$('.search-container').on('keyup', '.search-input', function () {
		var $searchInput = $(this);
		var $searchContainer = $searchInput.closest('.search-container');

		var searchQuery = $searchInput.val();

		if (searchQuery.length >= 3) {
			var formData = $searchContainer.find('form').serialize();
			var $searchResults = $searchContainer.find('.search-results');

			$.ajax({
				type: 'GET',
				url: ajax_object.ajax_url,
				data: formData + '&action=search_courses',
				success: function (response) {
					$searchResults.html(response);
				}
			});
		} else {
			$searchContainer.find('.search-results').html('');
		}
		if (!$searchInput.val()) {
			$searchContainer.find('.search-results').html(''); // Clear search results
		}
	});

	$(document).keyup(function(e) {
		if (e.key === "Escape") {
				$('.premium-modal-box-modal').css('display', 'none'); // Set display property to none with !important
				$('.premium-modal-box-modal').removeClass('premium-in');
		}
	  });

	// Video
	if (jQuery('.popup-video').length > 0) {
// 		jQuery('.popup-video').magnificPopup({
// 			type: 'iframe',
// 			mainClass: 'mfp-fade',
// 			removalDelay: 160,
// 			preloader: false,
// 			fixedContentPos: false
// 		});
	}
})