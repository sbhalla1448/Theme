<?php
/**
 * Template for review loop
 *
 * @package Tutor\Templates
 * @subpackage Single\Course
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.0.0
 */

foreach ( $reviews as $review ) : ?>
	<?php $profile_url = tutor_utils()->profile_url( $review->user_id, false ); ?>
	<div class="tutor-review-list-item tutor-card-list-item">
		<div class="tutor-row" style="display:flex;flex-direction:column;gap:24px;">
			<div class="tutor-col-lg-3 tutor-mb-16 tutor-mb-lg-0" style="display:flex;flex-direction:row;width:100%;justify-content:space-between;align-items:center;">
				<div class="tutor-student-profile" style="display:flex;flex-direction:row;gap:16px;align-items:center;">
					<!-- <div class="tutor-mb-12"> -->
						<?php
						echo wp_kses(
							tutor_utils()->get_tutor_avatar( $review->user_id, 'md' ),
							tutor_utils()->allowed_avatar_tags()
						);
						?>
					<!-- </div> -->
					<div class="tutor-reviewer-name tutor-fs-6 tutor-mb-4">
						<a href="<?php echo esc_url( $profile_url ); ?>" class="tutor-color-black">
							<?php echo esc_html( $review->display_name ); ?>
						</a>
					</div>
				</div>
				<div class="tutor-reviewed-on tutor-fs-7 tutor-color-muted">
					<?php echo esc_html( date('d F, Y',strtotime( $review->comment_date ) ) ); ?>
				</div>
			</div>

			<div class="tutor-col-lg-9">
				<?php if ( 'hold' == $review->comment_status ) : ?>
					<div style="position:absolute; right:15px">
						<span class="tutor-badge-label label-warning">
							<?php esc_html_e( 'Pending', 'tutor' ); ?>
						</span>
					</div>
				<?php endif; ?>
				<div style="display:flex;gap:8px;align-items:center;">
					<?php tutor_utils()->star_rating_generator_v2( $review->rating, null, true, 'tutor-is-sm' ); ?>
					<span style="color: var(--secondary-100, #243C45);font-family: Arial;font-size: 18px;font-style: normal;font-weight: 700;line-height: 138%;"><?php echo number_format( $review->rating, 1 ); ?></span>
				</div>
				<div class="tutor-fs-7 tutor-color-secondary tutor-mt-12 tutor-review-comment">
					<?php
					//phpcs:ignore
					echo tutor_utils()->clean_html_content(
						nl2br( stripslashes( $review->comment_content ) ),
						array( 'br' => array() )
					);
					?>
				</div>
			</div>
		</div>
	</div>
<?php endforeach; ?>
