<?php
/**
 * Template for displaying course content
 *
 * @package Tutor\Templates
 * @subpackage Single\Course
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.0.0
 */

global $post;

do_action( 'tutor_course/single/before/content' );

if ( tutor_utils()->get_option( 'enable_course_about', true, true ) ) {
	$string             = apply_filters( 'tutor_course_about_content', get_the_content() );
	$content_summary    = (bool) get_tutor_option( 'course_content_summary', true );
	$post_size_in_words = sizeof( explode( ' ', $string ) );
		$word_limit     = 100;
		$has_show_more  = false;

	// if ( $content_summary && ( $post_size_in_words > $word_limit ) ) {
	// 	$has_show_more = true;
	// }
	?>
	<?php if ( ! empty( $string ) ) : ?>
	<div class="tutor-course-details-content <?php echo $has_show_more ? 'tutor-toggle-more-content tutor-toggle-more-collapsed' : ''; ?>"<?php echo $has_show_more ? ' data-tutor-toggle-more-content data-toggle-height="200" style="height: 200px;"' : ''; ?>>
		<!-- <h2 class="tutor-fs-3 tutor-fw-bold tutor-color-black tutor-mb-24" style="font-size: 24px;">
			<?php echo esc_html( apply_filters( 'tutor_course_about_title', __( 'Course & College Informations', 'tutor' ) ) ); ?>
		</h2> -->
		<!-- Course overview -->
		<div class="tutor-fs-3 tutor-color-secondary">
			<!-- <h2 class="tutor-content-title">
				<?php echo tb_get_icon('course_overview'); ?>
				<span><?php _e('Course Overview','open-learning'); ?><span>
			</h2> -->
			<p><?php echo apply_filters( 'the_content', $string ); //phpcs:ignore ?></p>
		</div>
		<?php
		$tech_support = function_exists('get_field') ? get_field('tech_support') : '';
		if( $tech_support ) {
		?>
		<!-- Tutor Support -->
		<div class="tutor-fs-3 tutor-color-secondary">
			<h2 class="tutor-content-title">
				<?php echo tb_get_icon('tech_support'); ?>
				<?php _e('Tutor Support','open-learning'); ?>
			</h2>
			<?php echo $tech_support; ?>
		</div>
		<?php }
		$course_assessments = function_exists('get_field') ? get_field('course_assessments') : '';
		if( $course_assessments ) {
		?>
		<!-- Course Assessments -->
		<div class="tutor-fs-3 tutor-color-secondary">
			<h2 class="tutor-content-title">
				<?php echo tb_get_icon('couse_assessments'); ?>
				<?php _e('Course Assessments','open-learning'); ?>
			</h2>
			<?php echo $course_assessments; ?>
		</div>
		<?php
		}
		$course_duration = 0;//function_exists('get_field') ? get_field('course_duration') : '';
		if( $course_duration ) {
		?>
		<!-- Course duration -->
		<div class="tutor-fs-3 tutor-color-secondary">
			<h2 class="tutor-content-title">
				<?php echo tb_get_icon('course_duration'); ?>
				<?php _e('Course duration','open-learning'); ?>
			</h2>
			<?php echo $course_duration; ?>
		</div>
		<?php }
		$course_entry_requirements = function_exists('get_field') ? get_field('course_entry_requirements') : '';
		if( $course_entry_requirements ) {
		?>
		<!-- Course Entry Requirements -->
		<div class="tutor-fs-3 tutor-color-secondary">
			<h2 class="tutor-content-title">
				<?php echo tb_get_icon('couse_entry_requirements'); ?>
				<?php _e('Course Entry Requirements','open-learning'); ?>
			</h2>
			<?php echo $course_entry_requirements; //phpcs:ignore ?>
		</div>
		<?php }
		$course_enrollment_fees = function_exists('get_field') ? get_field('course_enrollment_fees') : '';
		if( $course_enrollment_fees ) {
		?>
		<!-- Course Enrolment Fees -->
		<div class="tutor-fs-3 tutor-color-secondary">
			<h2 class="tutor-content-title">
				<?php echo tb_get_icon('couse_enrollment_fee'); ?>
				<?php _e('Course Enrolment Fees','open-learning'); ?>
			</h2>
			<?php echo $course_enrollment_fees; //phpcs:ignore ?>
		</div>
		<?php }
		$course_qualifications = function_exists('get_field') ? get_field('course_qualifications') : '';
		if( $course_qualifications ) {
		?>
		<!-- Course Qualifications -->
		<div class="tutor-fs-3 tutor-color-secondary">
			<h2 class="tutor-content-title">
				<?php echo tb_get_icon('couse_qualifications'); ?>
				<?php _e('Course Qualifications','open-learning'); ?>
			</h2>
			<?php echo $course_qualifications; //phpcs:ignore ?>
		</div>
		<?php
		}
		$whats_included = function_exists('get_field') ? get_field('whats_included') : '';
		if( $whats_included ) {
		?>
		<!-- What’s Included -->
		<div class="tutor-fs-3 tutor-color-secondary">
			<h2 class="tutor-content-title">
				<?php echo tb_get_icon('whats_include'); ?>
				<?php _e('What’s Included','open-learning'); ?>
			</h2>
			<?php echo $whats_included; ?>
		</div>
		<?php } ?>
	</div>

		<?php if ( $has_show_more ) : ?>
		<a href="#" class="tutor-btn-show-more tutor-btn tutor-btn-ghost tutor-mt-32" data-tutor-toggle-more=".tutor-toggle-more-content">
			<span class="tutor-toggle-btn-icon tutor-icon tutor-icon-plus tutor-mr-8" area-hidden="true"></span>
			<span class="tutor-toggle-btn-text"><?php esc_html_e( 'Show More', 'tutor' ); ?></span>
		</a>
	<?php endif; ?>
<?php endif; ?>
	<?php
}

do_action( 'tutor_course/single/after/content' ); ?>
