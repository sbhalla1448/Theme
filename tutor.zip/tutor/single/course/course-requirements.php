<?php
/**
 * Template for displaying course requirements
 *
 * @package Tutor\Templates
 * @subpackage Single\Course
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.0.0
 */

do_action( 'tutor_course/single/before/requirements' );

$course_requirements = tutor_course_requirements();

if ( empty( $course_requirements ) ) {
	return;
}

if ( is_array( $course_requirements ) && count( $course_requirements ) ) {
	?>

	<div class="tutor-course-details-widget">
		<h3 class="tutor-course-details-widget-title tutor-fs-3 tutor-color-black tutor-fw-bold tutor-mb-12">
			<?php esc_html_e( 'Course Requirements', 'tutor' ); ?>
		</h3>
		<ul class="tutor-course-details-widget-list tutor-fs-4 tutor-color-black">
			<?php
			foreach ( $course_requirements as $requirement ) {
				echo '<li class="tutor-d-flex tutor-mb-12"><span class="tutor-icon-bullet-point tutor-color-muted tutor-mt-2 tutor-mr-8 tutor-fs-5" area-hidden="true"></span><span>' . esc_html( $requirement ) . '</span></li>';
			}
			?>
		</ul>
	</div>

<?php } ?>
<?php
$learning_resources = get_field('learning_resources');
if( !empty($learning_resources) ) {
?>
<div class="tutor-course-details-widget">
	<h3 class="tutor-course-details-widget-title tutor-fs-3 tutor-color-black tutor-fw-bold tutor-mb-12">
		<?php esc_html_e( 'Course Resources', 'tutor' ); ?>
	</h3>
	<div class="tutor-course-resource-holder">
		<?php
		foreach ( $learning_resources as $a_resource ) {
			?>
			<a class="tutor-course-resource" href="<?php echo $a_resource['resource_file']; ?>" download>
				<span><?php echo $a_resource['resource_title']; ?></span>
				<?php echo tb_get_icon('download'); ?>
			</a>
			<?php
		}
		?>
	</div>
</div>
<?php } // end of resource ?>
<?php
$downloads = get_field('downloads');
if( !empty($downloads) ) {
?>
<div class="tutor-course-details-widget">
	<h3 class="tutor-course-details-widget-title tutor-fs-3 tutor-color-black tutor-fw-bold tutor-mb-12">
		<?php esc_html_e( 'Downloads', 'tutor' ); ?>
	</h3>
	<div class="tutor-course-resource-holder">
		<?php
		foreach ( $downloads as $a_resource ) {
			?>
			<a class="tutor-course-resource" href="<?php echo $a_resource['file']; ?>" download>
				<span><?php echo $a_resource['title']; ?></span>
				<?php echo tb_get_icon('download'); ?>
			</a>
			<?php
		}
		?>
	</div>
</div>
<?php } // end of resource ?>
<?php do_action( 'tutor_course/single/after/requirements' ); ?>