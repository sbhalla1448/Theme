<?php
/**
 * Announcements
 *
 * @package Tutor\Templates
 * @subpackage Single\Course\Enrolled
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.0.0
 */

$announcements = tutor_utils()->get_announcements( get_the_ID() );
?>

<?php do_action( 'tutor_course/announcements/before' ); ?>
<h3 class="tutor-fs-3 tutor-fw-bold tutor-color-black tutor-mb-0 tutor-course-content-title">College Announcements</h3>
<?php if ( is_array( $announcements ) && count( $announcements ) ) : ?>
	<?php foreach ( $announcements as $announcement ) : ?>
		<div class="tutor-card tutor-announcement-card" style="border:0px;display: flex;flex-direction: column;gap: 12px;">
			<h3 style="color: var(--secondary-100, #243C45);font-family: Arial;font-size: 18px;font-style: normal;font-weight: 700;line-height: 138%;" class="tutor-card-title"><?php echo esc_html( $announcement->post_title ); ?></h3>
			<?php
				echo tutor_utils()->announcement_content( wpautop( stripslashes( $announcement->post_content ) ) ) //phpcs:ignore;
			?>
			<!-- <div class="tutor-card-body">
				<div class="tutor-fs-6 tutor-color-secondary">
					
				</div>
			</div> -->
		</div>
	<?php endforeach; ?>
<?php else : ?>
	<div>
		<?php tutor_utils()->tutor_empty_state( tutor_utils()->not_found_text() ); ?>
	</div>
<?php endif; ?>

<?php do_action( 'tutor_course/announcements/after' ); ?>
