<?php
/**
 * Tutor add to cart for WC product that will be visible on the course details page
 *
 * @package Tutor\Templates
 * @subpackage Single\Course
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.4.3
 */
global $post;
$product_id = tutor_utils()->get_course_product_id();
$product    = wc_get_product( $product_id );

$is_logged_in             = is_user_logged_in();
$enable_guest_course_cart = tutor_utils()->get_option( 'enable_guest_course_cart' );
$required_loggedin_class  = '';
if ( ! $is_logged_in && ! $enable_guest_course_cart ) {
	$required_loggedin_class = apply_filters( 'tutor_enroll_required_login_class', 'tutor-open-login-modal' );
}
$is_wish_listed    = tutor_utils()->is_wishlisted( $post->ID, get_current_user_id() );

if ( $product ) {
	if ( tutor_utils()->is_course_added_to_cart( $product_id, true ) ) {
		?>
			<a href="<?php echo esc_url( wc_get_checkout_url() ); ?>" class="tutor-btn tutor-btn-outline-primary tutor-btn-lg tutor-btn-block tutor-woocommerce-view-cart">
				<?php esc_html_e( 'View Checkout', 'tutor' ); ?>
			</a>
		<?php
	} else {
		$sale_price    = $product->get_sale_price();
		$regular_price = $product->get_regular_price();
		?>
		<style>
			.totor-enroll-options{
				display:flex;
				flex-direction: column;
				gap: 32px;
			}
			.tutor-enroll-option{
				display:flex;
				flex-direction:column;
				gap:10px;
			}
			.tutor-options{
				display:flex;
				flex-direction:row;
				gap:16px;
			}
			.tutor-option-title{
				color: var(--secondary-100, #243C45);
				/* Heading/Medium/Bold */
				font-family: Arial;
				font-size: 20px;
				font-style: normal;
				font-weight: 700;
				line-height: 138%; /* 27.6px */
			}
			.tutor-option{
				width:50%;
			}
			.tutor-option-selector{
				border-radius: 32px;
				border: 1px solid var(--secondary-10, #EAECED);
				background: var(--White, #FFF);
				padding: 7px 0px;
				text-align:center;
				/** typography */
				color: var(--secondary-60, #7C8A8F);
				/* Body/Large/Bold */
				font-family: Arial;
				font-size: 16px;
				font-style: normal;
				font-weight: 700;
				line-height: 138%; /* 22.08px */
			}

				
			
		</style>
		<div class="totor-enroll-options" id="totor-enroll-section">
			<div class="tutor-enroll-option">
				<div class="tutor-option-title">Study Options</div>
				
				<div class="tutor-options" id="study_options">
					<label class="tutor-option" id="study-online">
					  <input type="radio" value="study_online" name="tutor_option_study_pack" checked>
					  <div class="tutor-option-selector">
						<span class="checkmark"></span>
						<span>Study Online</span>
					  </div>
					</label>
					<label class="tutor-option" id="study_pack">
					  <input type="radio" value="study_pack" name="tutor_option_study_pack">
					  <div class="tutor-option-selector">
						<span class="checkmark"></span>
						<span>Study Pack</span>
					  </div>
					</label>
				</div>
				
			</div>
			<div class="tutor-enroll-option">
				<div class="tutor-option-title">Payment Options</div>
				<div class="tutor-options" id="payment_options">
				
					<label class="tutor-option" id="pay-in-full">
					  <input type="radio" value="pay_in_full" name="tutor_option_study_payment" checked>
					  <div class="tutor-option-selector">
						<span class="checkmark"></span>
						<span>Pay In Full</span>
					  </div>
					</label>
					<label class="tutor-option" id="pay-month">
					  <input type="radio" value="pay_monthly" name="tutor_option_study_payment">
					  <div class="tutor-option-selector">
						<span class="checkmark"></span>
						<span>Pay Monthly</span>
					  </div>
					</label>
				
			</div>	
			</div>
		</div>
		<div class="tutor-course-code">
			<div class="tutor-course-line"></div>
			<span> Course Code: <?php the_field('course_code'); ?> </span>
		</div>
		<div class="tutor-course-sidebar-card-pricing tutor-d-flex tutor-align-end tutor-justify-between">
			<?php ob_start(); ?>
				<div class="rbt-price-flex">
					<span class="tutor-fs-2 tutor-fw-bold tutor-color-black rbt-price-2 olc-checkout-regular-price olc-checkout-regular-sale-price">
						<?php echo wc_price( $sale_price ? $sale_price : $regular_price ); //phpcs:ignore?>
					</span>
					<span class="tutor-fs-2 tutor-fw-bold tutor-color-black rbt-price-2 olc-checkout-monthly-price" style="display:none;gap:8px;align-items:center;">
<!-- 						<span>From </span> -->
						<?php 
						$course_price = $sale_price ? $sale_price : $regular_price;
						$payment_slot = floatval(get_option('olc_checkout_instalment_qty') ?: 5);
						$sub_fee = floatval(get_option('olc_checkout_additional_fee') ?: 0);
						$total = floatval($course_price);
						$monthly_fee = ( $total + ($total * $sub_fee / 100) ) / $payment_slot;
						echo wc_price( $monthly_fee );
						?>
						
					</span>
					<?php if ( $regular_price && $sale_price && $sale_price != $regular_price ) : ?>
						<del class="tutor-fs-3 tutor-color-muted tutor-ml-8 rbt-del-price-2 olc-checkout-regular-price olc-checkout-regular-gross-price">
							<?php echo wc_price( $regular_price ); //phpcs:ignore?>
							
						</del>
					<?php endif; ?>
				</div>
				<script>
					jQuery(document).ready(function($){
						  // Function to handle the display logic
						  function handleDisplay() {
							var valueGroup1 = $('#study_options input[type="radio"]:checked').val();
							var valueGroup2 = $('#payment_options input[type="radio"]:checked').val(); 
							  <?php $delivery_fee = get_option('olc_checkout_study_pack_delivery_fee') ?: '49.99';?>
							let sale_price_for_study_pack = '<?php echo wc_price(floatval($sale_price) + floatval($delivery_fee)); ?>'
							let regular_price_for_study_pack = '<?php echo wc_price(floatval($regular_price) + floatval($delivery_fee)); ?>'
							let monthly_price_for_study_pack = '<?php echo wc_price(floatval($monthly_fee) + floatval($delivery_fee)); ?>'
							let sale_price = '<?php echo wc_price( $sale_price ); ?>'
							let regular_price = '<?php echo wc_price( $regular_price ); ?>'
							let monthly_price = '<?php echo wc_price( $monthly_fee ); ?>'
							  
							// Hide all sections first
							$('.saving-info-item').hide();

							// Example logic to show a section based on the combination
							if (valueGroup1 === 'study_online' && valueGroup2 === 'pay_in_full') {
								$('.olc-checkout-regular-price').show();
								$('.olc-checkout-monthly-price').hide();
								$('.olc-checkout-regular-sale-price').html(sale_price)
								$('.olc-checkout-regular-gross-price').html(regular_price)
								$('.olc-checkout-monthly-price').html(monthly_price)
							  	$('#default-saving-info-item').show();
							} else if (valueGroup1 === 'study_online' && valueGroup2 === 'pay_monthly') {
								$('.olc-checkout-regular-price').hide()
								$('.olc-checkout-monthly-price').css("display","flex")
								$('.olc-checkout-regular-sale-price').html(sale_price)
								$('.olc-checkout-regular-gross-price').html(regular_price)
								$('.olc-checkout-monthly-price').html(monthly_price)
							  	$('#studyonline-paymonth-discount-saving-info-item').show();
							} else if (valueGroup1 === 'study_pack' && valueGroup2 === 'pay_in_full') {
								$('.olc-checkout-regular-price').show();
								$('.olc-checkout-monthly-price').hide();
							  	$('.olc-checkout-regular-sale-price').html(sale_price_for_study_pack)
								$('.olc-checkout-regular-gross-price').html(regular_price_for_study_pack)
								$('.olc-checkout-monthly-price').html(monthly_price_for_study_pack)
								$('#studypack-payinfullmonth-discount-saving-info-item').show();
								
							} else if (valueGroup1 === 'study_pack' && valueGroup2 === 'pay_monthly') {
								$('.olc-checkout-regular-price').hide()
								$('.olc-checkout-monthly-price').css("display","flex")
								$('.olc-checkout-regular-sale-price').html(sale_price_for_study_pack)
								$('.olc-checkout-regular-gross-price').html(regular_price_for_study_pack)
								$('.olc-checkout-monthly-price').html(monthly_price_for_study_pack)
							  	$('#studypack-paymonth-discount-saving-info-item').show();
							}
						  }

						  // Bind the change event to radio buttons in both groups
						  $('#study_options input[type="radio"], #payment_options input[type="radio"]').change(handleDisplay);
					
					})
				</script>
				<?php
					/**
					 * Added to show info about price.
					 *
					 * @since 2.2.0
					 */
					do_action( 'tutor_after_course_details_wc_cart_price', $product, get_the_ID() );
				?>
            <?php echo apply_filters( 'tutor_course_details_wc_add_to_cart_price', ob_get_clean(), $product ); //phpcs:ignore ?>
			<div class="tutor-col-auto">
				<div class="tutor-course-details-actions tutor-mt-12 tutor-mt-sm-0">
					<a href="#" class="tutor-course-wishlist-btn tutor-btn tutor-btn-ghost" data-course-id="<?php echo get_the_ID(); ?>">
					<svg xmlns="http://www.w3.org/2000/svg" width="22" height="28" viewBox="0 0 22 28" fill="none">
					<path fill-rule="evenodd" clip-rule="evenodd" d="M14.9806 0.666504H7.01879C2.87853 0.666504 0.333008 2.66556 0.333008 6.57896V25.1077C0.338985 25.4838 0.426895 25.8374 0.589842 26.1563L0.714707 26.3624L0.845419 26.5299C1.52693 27.3291 2.61461 27.5497 3.51223 27.0714L10.965 22.8845L18.4481 27.0627C18.782 27.2387 19.1284 27.3274 19.4807 27.3332C20.0714 27.3333 20.6235 27.0988 21.0306 26.6814C21.4376 26.2641 21.6663 25.698 21.6663 25.1077V6.34337C21.6663 2.57987 19.0639 0.666504 14.9806 0.666504ZM7.01833 2.59668H14.9801C18.1326 2.59668 19.7831 3.8102 19.7831 6.34322V25.1076C19.7831 25.1859 19.7528 25.261 19.6988 25.3163C19.6448 25.3717 19.5716 25.4028 19.4952 25.4028C19.4466 25.4019 19.3841 25.3859 19.3276 25.3561L11.8572 21.1855C11.2993 20.8765 10.6302 20.8765 10.075 21.184L2.62537 25.3684C2.51235 25.4283 2.35085 25.3891 2.2648 25.2689L2.21484 25.186C2.22447 25.1997 2.22273 25.1831 2.21974 25.1546C2.21787 25.1367 2.21551 25.1142 2.21515 25.0915L2.21528 6.57881C2.21528 3.86073 3.82488 2.59668 7.01833 2.59668ZM16.4849 10.0538C16.4849 9.5208 16.0634 9.08868 15.5435 9.08868H6.38691L6.25917 9.09749C5.79969 9.1614 5.44554 9.56522 5.44554 10.0538C5.44554 10.5869 5.867 11.019 6.38691 11.019H15.5435L15.6712 11.0102C16.1307 10.9463 16.4849 10.5425 16.4849 10.0538Z" fill="#7C8A8F"/>
					</svg>
						<!-- <i class="<?php echo $is_wish_listed ? 'tutor-icon-bookmark-bold' : 'tutor-icon-bookmark-line'; ?> tutor-mr-8"></i> -->
					</a>
					<a href="#" data-tutor-modal-target="tutor-course-share-opener" class="tutor-course-share-btn">
					<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">
					<path d="M24 10.6665C26.2091 10.6665 28 8.87564 28 6.6665C28 4.45736 26.2091 2.6665 24 2.6665C21.7909 2.6665 20 4.45736 20 6.6665C20 8.87564 21.7909 10.6665 24 10.6665Z" stroke="#7C8A8F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
					<path d="M8 20C10.2091 20 12 18.2091 12 16C12 13.7909 10.2091 12 8 12C5.79086 12 4 13.7909 4 16C4 18.2091 5.79086 20 8 20Z" stroke="#7C8A8F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
					<path d="M24 29.3335C26.2091 29.3335 28 27.5426 28 25.3335C28 23.1244 26.2091 21.3335 24 21.3335C21.7909 21.3335 20 23.1244 20 25.3335C20 27.5426 21.7909 29.3335 24 29.3335Z" stroke="#7C8A8F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
					<path d="M11.4534 18.0132L20.56 23.3198" stroke="#7C8A8F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
					<path d="M20.5467 8.68018L11.4534 13.9868" stroke="#7C8A8F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
					</svg>
					</a>
				</div>
				<?php
					$tutor_social_share_icons = tutor_utils()->tutor_social_share_icons();
					if ( ! tutor_utils()->count( $tutor_social_share_icons ) ) {
						return;
					}
					
					$share_config = array(
						'title' => get_the_title(),
						'text'  => get_the_excerpt(),
						'image' => get_tutor_course_thumbnail( 'post-thumbnail', true ),
					);
				?>
				<div id="tutor-course-share-opener" class="tutor-modal">
					<span class="tutor-modal-overlay"></span>
					<div class="tutor-modal-window">
						<div class="tutor-modal-content tutor-modal-content-white">
							<button class="tutor-iconic-btn tutor-modal-close-o" data-tutor-modal-close>
								<span class="tutor-icon-times" area-hidden="true"></span>
							</button>
							<div class="tutor-modal-body">
								<div class="tutor-fs-5 tutor-fw-medium tutor-color-black tutor-mb-16">
									<?php esc_html_e( 'Share Course', 'tutor' ); ?>
								</div>
								<div class="tutor-fs-7 tutor-color-secondary tutor-mb-12">
									<?php esc_html_e( 'Page Link', 'tutor' ); ?>
								</div>
								<div class="tutor-mb-32">
									<input class="tutor-form-control" value="<?php echo esc_attr( get_permalink( get_the_ID() ) ); ?>" />
								</div>
								<div>
									<div class="tutor-color-black tutor-fs-6 tutor-fw-medium tutor-mb-16">
										<?php esc_html_e( 'Share On Social Media', 'tutor' ); ?>
									</div>
									<div class="tutor-social-share-wrap" data-social-share-config="<?php echo esc_attr( wp_json_encode( $share_config ) ); ?>">
										<?php foreach ( $tutor_social_share_icons as $icon ) : ?>
											<button class="tutor_share <?php echo esc_attr( $icon['share_class'] ); ?>" style="background: <?php echo esc_attr( $icon['color'] ); ?>">
												<?php echo wp_kses( $icon['icon_html'], tutor_utils()->allowed_icon_tags() ); ?>
												<span>
													<?php echo esc_html( $icon['text'] ); ?>
												</span>
											</button>
										<?php endforeach; ?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
<!-- add to busket button -->
<!-- 		<form action="<?php echo esc_url( apply_filters( 'tutor_course_add_to_cart_form_action', get_permalink( get_the_ID() ) ) ); ?>" method="post" enctype="multipart/form-data">
			<button type="submit" name="add-to-cart" value="<?php echo esc_attr( $product->get_id() ); ?>"  class="rbt-btn d-block w-100 tutor-mt-24 tutor-add-to-cart-button <?php echo esc_attr( $required_loggedin_class ); ?>">
				<span><?php echo esc_html( $product->single_add_to_cart_text() ); ?></span>
			</button>
		</form> -->
<!-- 		<a class="rbt-btn rbt-btn-7 d-block text-center tutor-mt-24 tutor-add-to-cart-button <?php echo esc_attr( $required_loggedin_class ); ?>" href="<?php echo wc_get_checkout_url() .'?add-to-cart='. $product->get_id(); ?>">
			<span><?php _e('Enrol Now', 'open-learning'); ?></span>
		</a> -->


<?php 
		$additional_price = 49.99;		
		$regular_price = $regular_price; 
		$discount_price = $sale_price;
		$total_value = $regular_price - $discount_price;
		$additional_reprice_total = $regular_price + $additional_price;
		$additional_saleprice_total = $sale_price + $additional_price;
if ( $regular_price && $sale_price && $sale_price != $regular_price ) :

?>
<div class="saving-info-wrap">
    <div class="saving-info-wrap-inner">
        <div class="saving-info-img"><img src="https://openlearningcollege.ac/wp-content/uploads/2024/04/group-checkout.svg"></div>
        <div class="saving-info-item" id="default-saving-info-item">			
			<h6 id="discount-main-text">You are saving<span id="discount-price-text-result"><?php echo get_woocommerce_currency_symbol(); //phpcs:ignore?><?php echo $total_value; ?></span> by buying this course and paying in full.</h6>
			
            <p id="default-total-price">All for just <em id="regular-price-text">
				<?php echo wc_price( $sale_price ? $sale_price : $regular_price );
		//phpcs:ignore?></em> 				
				<span class="discount-price-text"><?php if ( $regular_price && $sale_price && $sale_price != $regular_price ) : ?>
						<del class="tutor-fs-3 tutor-color-muted tutor-ml-8 rbt-del-price-2" id="sale-price-text">
							<?php echo wc_price( $regular_price); //phpcs:ignore?>	
						</del>
					<?php endif; ?>
				</span></p>

        </div>
		<div class="saving-info-item" id="studypack-payinfullmonth-discount-saving-info-item">			
			<h6 id="discount-main-text">You are saving<span id="discount-price-text-result"><?php echo get_woocommerce_currency_symbol(); //phpcs:ignore?><?php echo $total_value; ?></span> by buying this course and paying in full.</h6>
			
            <p id="default-total-price">All for just <em id="regular-price-text">
				<span><?php echo get_woocommerce_currency_symbol(); //phpcs:ignore?><?php echo $additional_saleprice_total;	//phpcs:ignore?></span>	
				</em> 				
				<span class="discount-price-text"><?php if ( $regular_price && $sale_price && $sale_price != $regular_price ) : ?>
						<del class="tutor-fs-3 tutor-color-muted tutor-ml-8 rbt-del-price-2" id="sale-price-text">
							<span><?php echo get_woocommerce_currency_symbol(); //phpcs:ignore?><?php echo $additional_reprice_total; //phpcs:ignore?></span>
							
						</del>
					<?php endif; ?>
				</span></p>

        </div>
		<div class="saving-info-item" id="studypack-paymonth-discount-saving-info-item">
			<h6 id="discount-main-text-pay">Deposit to pay now<span id="discount-price-text-result"><?php echo get_woocommerce_currency_symbol(); //phpcs:ignore?><?php echo $total_value + $additional_price; ?></span>
				<br>4 monthly instalments of <?php echo get_woocommerce_currency_symbol(); //phpcs:ignore?><?php echo $total_value; ?> <br> Next Instalment will be due in 30 days
			</h6>			
			<p id="total-cost-price">
				Total cost 						
							<span><?php echo get_woocommerce_currency_symbol(); //phpcs:ignore?><?php echo $additional_reprice_total; //phpcs:ignore?></span>
					<?//php endif; ?>
			</p>
        </div>
		<div class="saving-info-item" id="studyonline-paymonth-discount-saving-info-item">
			<h6 id="discount-main-text-pay">Deposit to pay now<span id="discount-price-text-result"><?php echo get_woocommerce_currency_symbol(); //phpcs:ignore?><?php echo $total_value; ?></span>
				<br>4 monthly instalments of <?php echo get_woocommerce_currency_symbol(); //phpcs:ignore?><?php echo $total_value; ?> <br> Next Instalment will be due in 30 days
			</h6>			
			<p id="total-cost-price">				
				Total cost <?php if ( $regular_price && $sale_price && $sale_price != $regular_price ) : ?>						
							<?php echo wc_price( $regular_price ); //phpcs:ignore?>	
					<?php endif; ?>
			</p>
        </div>
    </div>
	<div class="what-do-you-get-main-wrap">
		<a href="javascript:void(0)" class="saving-info-item-button">What Extras do you get today?</a>
			<div class="what-do-you-get-wraped">
				<ul>
					<?php
						$what_get_contents = get_field( 'what_get_content');
						if(!empty($what_get_contents)) :
						foreach($what_get_contents as $what_get_content):
					?>
						<li><?php echo $what_get_content['what_get_text'];?></li>
					<?php endforeach; endif; ?>
				</ul>
			</div>
	</div>
</div>
<?php endif; ?>

			<button class="enroll-now rbt-btn rbt-btn-7 d-block text-center tutor-mt-24 tutor-add-to-cart-button <?php echo esc_attr( $required_loggedin_class ); ?>" data-product-id="<?php echo esc_attr( $product->get_id() ); ?>">
			<span><?php _e('Enrol Now', 'open-learning'); ?></span>
			</button>
		<?php
	}
} else {
	?>
	<p class="tutor-alert-warning">
		<?php esc_html_e( 'Please make sure that your product exists and valid for this course', 'tutor' ); ?>
	</p>
	<?php
}
