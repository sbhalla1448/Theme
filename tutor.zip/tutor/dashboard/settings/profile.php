<?php
/**
 * Profile
 *
 * @package Tutor\Templates
 * @subpackage Dashboard\Settings
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.6.2
 */

$user = wp_get_current_user();

// Prepare profile pic.
$profile_placeholder = apply_filters( 'tutor_login_default_avatar', tutor()->url . 'assets/images/profile-photo.png' );
$profile_photo_src   = $profile_placeholder;
$profile_photo_id    = get_user_meta( $user->ID, '_tutor_profile_photo', true );
if ( $profile_photo_id ) {
	$url                                 = wp_get_attachment_image_url( $profile_photo_id, 'full' );
	! empty( $url ) ? $profile_photo_src = $url : 0;
}

// Prepare cover photo.
$cover_placeholder = tutor()->url . 'assets/images/cover-photo.jpg';
$cover_photo_src   = $cover_placeholder;
$cover_photo_id    = get_user_meta( $user->ID, '_tutor_cover_photo', true );
if ( $cover_photo_id ) {
	$url                               = wp_get_attachment_image_url( $cover_photo_id, 'full' );
	! empty( $url ) ? $cover_photo_src = $url : 0;
}

// Prepare display name.
$public_display                     = array();
$public_display['display_nickname'] = $user->nickname;
$public_display['display_username'] = $user->user_login;

if ( ! empty( $user->first_name ) ) {
	$public_display['display_firstname'] = $user->first_name;
}

if ( ! empty( $user->last_name ) ) {
	$public_display['display_lastname'] = $user->last_name;
}

if ( ! empty( $user->first_name ) && ! empty( $user->last_name ) ) {
	$public_display['display_firstlast'] = $user->first_name . ' ' . $user->last_name;
	$public_display['display_lastfirst'] = $user->last_name . ' ' . $user->first_name;
}

if ( ! in_array( $user->display_name, $public_display ) ) { // Only add this if it isn't duplicated elsewhere.
	$public_display = array( 'display_displayname' => $user->display_name ) + $public_display;
}

$public_display = array_map( 'trim', $public_display );
$public_display = array_unique( $public_display );
$max_filesize   = floatval( ini_get( 'upload_max_filesize' ) ) * ( 1024 * 1024 );
?>
<div class="rbt-dashboard-content-wrapper">
	<div class="tutor-bg-photo bg_image bg_image--23 height-245" id="tutor_cover_area" data-fallback="<?php echo esc_attr( $cover_placeholder ); ?>" style="background-image:url(<?php echo esc_url( $cover_photo_src ); ?>)"></div>
	<!-- Start Tutor Information  -->
	<div class="rbt-tutor-information" id="tutor_profile_cover_photo_editor">
		<input class="d-none" id="tutor_photo_dialogue_box" type="file" accept=".png,.jpg,.jpeg"/>
		<input type="hidden" class="upload_max_filesize" value="<?php echo esc_attr( $max_filesize ); ?>">
		<div class="rbt-tutor-information-left">
			<div class="thumbnail rbt-avatars size-lg position-relative">
				<?php if(!$profile_photo_id): ?>
				<div id="tutor_profile_area" data-fallback="<?php echo esc_attr( $profile_placeholder ); ?>" style="background-image:url(<?php echo esc_url( $profile_photo_src ); ?>)"></div>
				<?php else: ?>
				<img src="<?php echo esc_url( $profile_photo_src ); ?>" alt="Instructor" id="tutor_profile_area">
				<?php endif; ?>
				<div class="rbt-edit-photo-inner">
					<button class="rbt-edit-photo" title="Upload Photo" id="tutor_pp_option">
						<?php if($profile_photo_id): ?>
						<span class="tutor_pp_deleter profile-uploader">
							<i class="feather-trash profile-upload-icon tutor-icon-trash-can-bold"></i>
						</span>
						<?php else: ?>
						<span class="tutor_pp_uploader profile-uploader">
							<i class="feather-camera profile-upload-icon tutor-icon-image-landscape"></i>
						</span>
						<?php endif; ?>
					</button>
				</div>
			</div>
		</div>
		<div class="rbt-tutor-information-right">
			<div class="tutor-btn">
				<?php if ( !$cover_photo_id ): ?>
				<button class="rbt-btn btn-sm btn-border color-white radius-round-10 tutor_cover_uploader"><?php echo esc_html__( 'Upload Cover Photo', 'tutor' ); ?></button>
				<?php else: ?>
				<button class="rbt-btn btn-sm btn-border color-white radius-round-10 tutor_cover_deleter"><?php echo esc_html__( 'Delete Cover Photo', 'tutor' ); ?></button>
				<?php endif; ?>
			</div>
		</div>
	</div>
	<!-- End Tutor Information  -->
</div>
<!-- Start Profile Row  -->
<form action="#" class="rbt-profile-row rbt-default-form row row--15" method="post" enctype="multipart/form-data">
	<?php
		$errors = apply_filters( 'tutor_profile_edit_validation_errors', array() );
		if ( is_array( $errors ) && count( $errors ) ) {
			echo '<div class="tutor-alert-warning tutor-mb-12"><ul class="tutor-required-fields">';
			foreach ( $errors as $error_key => $error_value ) {
				echo '<li>' . esc_html( $error_value ) . '</li>';
			}
			echo '</ul></div>';
		}
	?>
	<div class="col-lg-6 col-md-6 col-sm-6 col-12">
		<div class="rbt-form-group">
			<label for="firstname"><?php esc_html_e( 'First Name', 'tutor' ); ?></label>
			<input id="firstname" type="text" name="first_name" value="<?php echo esc_attr( $user->first_name ); ?>" placeholder="<?php esc_attr_e( 'First Name', 'tutor' ); ?>">
		</div>
	</div>
	<div class="col-lg-6 col-md-6 col-sm-6 col-12">
		<div class="rbt-form-group">
			<label for="lastname"><?php esc_html_e( 'Last Name', 'tutor' ); ?></label>
			<input id="lastname" type="text" name="last_name" value="<?php echo esc_attr( $user->last_name ); ?>" placeholder="<?php esc_attr_e( 'Last Name', 'tutor' ); ?>">
		</div>
	</div>
	<div class="col-lg-6 col-md-6 col-sm-6 col-12">
		<div class="rbt-form-group">
			<label for="username"><?php esc_html_e( 'User Name', 'tutor' ); ?></label>
			<input id="username" type="text" disabled="disabled" value="<?php echo esc_attr( $user->user_login ); ?>">
		</div>
	</div>
	<div class="col-lg-6 col-md-6 col-sm-6 col-12">
		<div class="rbt-form-group">
			<label for="phonenumber"><?php esc_html_e( 'Phone Number', 'tutor' ); ?></label>
			<input id="phonenumber" type="tel" pattern="[0-9]{3}-[0-9]{2}-[0-9]{3}" name="phone_number" value="<?php echo esc_html( filter_var( get_user_meta( $user->ID, 'phone_number', true ), FILTER_SANITIZE_NUMBER_INT ) ); ?>" placeholder="<?php esc_attr_e( 'Phone Number', 'tutor' ); ?>">
		</div>
	</div>
	<div class="col-lg-6 col-md-6 col-sm-6 col-12">
		<div class="rbt-form-group">
			<label for="skill"><?php esc_html_e( 'Skill/Occupation', 'tutor' ); ?></label>
			<input id="skill" type="text" name="tutor_profile_job_title" value="<?php echo esc_attr( get_user_meta( $user->ID, '_tutor_profile_job_title', true ) ); ?>" placeholder="<?php esc_attr_e( 'UX Designer', 'tutor' ); ?>">
		</div>
	</div>
	<div class="col-lg-6 col-md-6 col-sm-6 col-12">
		<div class="filter-select rbt-modern-select">
			<label for="displayname" class=""><?php esc_html_e( 'Display name publicly as', 'tutor' ); ?></label>
			<div class="dropdown bootstrap-select w-100 dropup">
				<select id="displayname" class="w-100" tabindex="null" name="display_name">
					<?php
					foreach ( $public_display as $id => $item ) {
						?>
								<option <?php selected( $user->display_name, $item ); ?>><?php echo esc_html( $item ); ?></option>
							<?php
					}
					?>
				</select>
			</div>
		</div>
	</div>
	<div class="col-12">
		<div class="rbt-form-group">
			<label for="bio"><?php esc_html_e( 'Bio', 'tutor' ); ?></label>
			<textarea id="bio" cols="20" rows="5" name="tutor_profile_bio"><?php echo esc_html( strip_tags( get_user_meta( $user->ID, '_tutor_profile_bio', true ) ) ); ?></textarea>
		</div>
	</div>
	<div class="col-12 mt--20">
		<div class="rbt-form-group">
			<button type="submit" class="rbt-btn btn-gradient tutor-profile-settings-save">
				<?php esc_html_e( 'Update Info', 'tutor' ); ?>
			</button>
		</div>
	</div>
</form>
<!-- End Profile Row  -->
<style>
	.tutor-form-control.invalid{border-color: red;}
</style>
