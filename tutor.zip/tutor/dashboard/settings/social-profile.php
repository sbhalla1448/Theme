<?php
/**
 * Social Profile Template
 *
 * @package Tutor\Templates
 * @subpackage Dashboard\Settings
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 2.0.0
 */

$user = wp_get_current_user();
?>
<div class="rbt-dashboard-content bg-color-white rbt-shadow-box">
	<div class="content">
		<div class="section-title">
			<h4 class="rbt-title-style-3"><?php esc_html_e( 'Settings', 'tutor' ); ?></h4>
		</div>

		<div class="advance-tab-button mb--30">
			<?php tutor_load_template( 'dashboard.settings.nav-bar', array( 'active_setting_nav' => 'social-profile' ) ); ?>
		</div>

		<div class="tab-content">
			<!-- Start Profile Row  -->
			<form id="user_social_form" action="#" class="rbt-profile-row rbt-default-form row row--15" method="post" enctype="multipart/form-data">
				<?php wp_nonce_field( tutor()->nonce_action, tutor()->nonce ); ?>
				<input type="hidden" value="tutor_social_profile" name="tutor_action" />
				<?php
					do_action( 'tutor_profile_edit_before_social_media', $user );
					$tutor_user_social_icons = tutor_utils()->tutor_user_social_icons();
					foreach ( $tutor_user_social_icons as $key => $social_icon ) :
				?>
				<div class="col-12">
					<div class="rbt-form-group">
						<label for="<?php echo esc_attr( $key ); ?>"><i class="<?php echo esc_html( $social_icon['icon_classes'] ); ?>"></i> <?php echo esc_html( $social_icon['label'] ); ?></label>
						<input class="tutor-form-control" type="url" name="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_url( get_user_meta( $user->ID, $key, true ) ); ?>" placeholder="<?php echo esc_html( $social_icon['placeholder'] ); ?>">
					</div>
				</div>
				<?php endforeach; ?>
				<div class="col-12 mt--10">
					<div class="rbt-form-group">
						<button type="submit" class="rbt-btn btn-gradient">
							<?php esc_html_e( 'Update Profile', 'tutor' ); ?>
						</button>
					</div>
				</div>
			</form>
			<!-- End Profile Row  -->
		</div>
	</div>
</div>
