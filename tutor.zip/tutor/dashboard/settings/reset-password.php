<?php
/**
 * Reset password
 *
 * @package Tutor\Templates
 * @subpackage Dashboard\Settings
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @version 1.4.3
 */

?>
<div class="rbt-dashboard-content bg-color-white rbt-shadow-box">
	<div class="content">
		<div class="section-title">
			<h4 class="rbt-title-style-3"><?php esc_html_e( 'Settings', 'tutor' ); ?></h4>
		</div>

		<div class="advance-tab-button mb--30">
			<?php
				tutor_load_template( 'dashboard.settings.nav-bar', array( 'active_setting_nav' => 'reset_password' ) );
			?>
		</div>

		<div class="tab-content">
			<!-- Start Profile Row  -->
			<form action="#" class="rbt-profile-row rbt-default-form row row--15" method="post" enctype="multipart/form-data">
				<div class="col-12">
					<div class="rbt-form-group">
						<label for="currentpassword"><?php esc_html_e( 'Current Password', 'tutor' ); ?></label>
						<input id="currentpassword" type="password" name="previous_password" placeholder="<?php esc_attr_e( 'Current Password', 'tutor' ); ?>">
					</div>
				</div>
				<div class="col-12">
					<div class="rbt-form-group">
						<div class="tutor-password-strength-checker">
							<div class="tutor-password-field">
								<label class="field-label tutor-form-label" for="tutor-new-password">
									<?php esc_html_e( 'New Password', 'tutor' ); ?>
								</label>
								<div class="field-group">
									<input
										class="password-checker tutor-form-control"
										id="tutor-new-password"
										type="password"
										name="new_password"
										placeholder="<?php esc_attr_e( 'Type Password', 'tutor' ); ?>"
									/>
									<span class="show-hide-btn"></span>
								</div>
							</div>

							<div class="tutor-passowrd-strength-hint">
								<div class="indicator">
									<span class="weak"></span>
									<span class="medium"></span>
									<span class="strong"></span>
								</div>
								<div class="text tutor-fs-7 tutor-color-muted"></div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-12">
					<div class="rbt-form-group">
						<div class="tutor-password-field tutor-settings-pass-field">
							<label class="field-label tutor-form-label" for="tutor-confirm-password">
								<?php esc_html_e( 'Re-type New Password', 'tutor' ); ?>
							</label>
							<div class="tutor-form-wrap">
								<span class="tutor-validation-icon tutor-icon-mark tutor-color-success tutor-form-icon tutor-form-icon-reverse" style="display: none;"></span>
								<input
									class="tutor-form-control"
									id="tutor-confirm-password"
									type="password"
									placeholder="<?php esc_attr_e( 'Type Password', 'tutor' ); ?>"
									name="confirm_new_password"
								/>
							</div>
						</div>
					</div>
				</div>
				<div class="col-12 mt--10">
					<div class="rbt-form-group">
						<button type="submit" class="rbt-btn btn-gradient tutor-profile-password-reset">
							<?php esc_html_e( 'Reset Password', 'tutor' ); ?>
						</button>
					</div>
				</div>
			</form>
			<!-- End Profile Row  -->
			<div class="tab-pane fade" id="social" role="tabpanel" aria-labelledby="social-tab">
				<!-- Start Profile Row  -->
				<form action="#" class="rbt-profile-row rbt-default-form row row--15">
					<div class="col-12">
						<div class="rbt-form-group">
							<label for="facebook"><i class="feather-facebook"></i> Facebook</label>
							<input id="facebook" type="text" placeholder="https://facebook.com/">
						</div>
					</div>
					<div class="col-12">
						<div class="rbt-form-group">
							<label for="twitter"><i class="feather-twitter"></i> Twitter</label>
							<input id="twitter" type="text" placeholder="https://twitter.com/">
						</div>
					</div>
					<div class="col-12">
						<div class="rbt-form-group">
							<label for="linkedin"><i class="feather-linkedin"></i> Linkedin</label>
							<input id="linkedin" type="text" placeholder="https://linkedin.com/">
						</div>
					</div>
					<div class="col-12">
						<div class="rbt-form-group">
							<label for="website"><i class="feather-globe"></i> Website</label>
							<input id="website" type="text" placeholder="https://website.com/">
						</div>
					</div>
					<div class="col-12">
						<div class="rbt-form-group">
							<label for="github"><i class="feather-github"></i> Github</label>
							<input id="github" type="text" placeholder="https://github.com/">
						</div>
					</div>
					<div class="col-12 mt--10">
						<div class="rbt-form-group">
							<a class="rbt-btn btn-gradient" href="#">Update Profile</a>
						</div>
					</div>
				</form>
				<!-- End Profile Row  -->
			</div>
		</div>
	</div>
</div>
