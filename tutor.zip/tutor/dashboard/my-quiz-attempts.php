<?php
/**
 * My Quiz Attempts
 *
 * @package Tutor\Templates
 * @subpackage Dashboard
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.1.2
 */

use TUTOR\Input;
use Tutor\Models\QuizModel;

if ( Input::has( 'view_quiz_attempt_id' ) ) {
	// Load single attempt details if ID provided.
	include __DIR__ . '/my-quiz-attempts/attempts-details.php';
	return;
}

$item_per_page = tutor_utils()->get_option( 'pagination_per_page' );
$current_page  = max( 1, Input::get( 'current_page', 1, Input::TYPE_INT ) );
$offset        = ( $current_page - 1 ) * $item_per_page;

// Filter params.
$course_filter = Input::get( 'course-id' );
$order_filter  = Input::get( 'order', 'DESC' );
$date_filter   = Input::get( 'date', '' );
$course_id     = isset( $course_id ) ? $course_id : array();

$quiz_attempts = QuizModel::get_quiz_attempts_by_course_ids( $offset, $item_per_page, $course_id, '', $course_filter, $date_filter, $order_filter, get_current_user_id() );

?>
<div class="rbt-dashboard-content bg-color-white rbt-shadow-box">
	<div class="content">
		<div class="section-title">
			<h4 class="rbt-title-style-3">
				<?php esc_html_e( 'My Quiz Attempts', 'tutor' ); ?>
			</h4>
		</div>
		<!-- Start Filter -->
		<!-- <div class="rbt-dashboard-filter-wrapper">
			<div class="row g-5">
				<div class="col-lg-6">
					<div class="filter-select rbt-modern-select">
						<span class="select-label d-block">Courses</span>
						<select class="w-100" data-live-search="true" title="All" multiple data-size="7" data-actions-box="true" data-selected-text-format="count > 2">
							<option data-subtext="HTML">Web Design</option>
							<option data-subtext="Photoshop">Graphic</option>
							<option data-subtext="Career">English</option>
							<option data-subtext="Career">Spoken English</option>
							<option data-subtext="Experts">Art Painting</option>
							<option data-subtext="Experts">App Development</option>
							<option data-subtext="Experts">Web Application</option>
							<option data-subtext="Experts">Php Development</option>
						</select>
					</div>
				</div>
				<div class="col-lg-3">
					<div class="filter-select rbt-modern-select">
						<span class="select-label d-block">Short By</span>
						<select class="w-100">
							<option>Default</option>
							<option>Latest</option>
							<option>Popularity</option>
							<option>Trending</option>
							<option>Price: low to high</option>
							<option>Price: high to low</option>
						</select>
					</div>
				</div>
				<div class="col-lg-3">
					<div class="filter-select rbt-modern-select">
						<span class="select-label d-block">Short By Offer</span>
						<select class="w-100">
							<option>Free</option>
							<option>Paid</option>
							<option>Premium</option>
						</select>
					</div>
				</div>
			</div>
		</div> -->
		<!-- End Filter -->

		<hr class="mt--30">

		<div class="rbt-dashboard-table table-responsive mobile-table-750 mt--30">
		<?php
			$quiz_attempts_count = QuizModel::get_quiz_attempts_by_course_ids( $offset, $item_per_page, $course_id, '', $course_filter, $date_filter, $order_filter, get_current_user_id(), true );

			tutor_load_template_from_custom_path(
				tutor()->path . '/views/quiz/attempt-table.php',
				array(
					'attempt_list' => $quiz_attempts,
					'context'      => 'frontend-dashboard-my-attempts',
				)
			);
			$pagination_data              = array(
				'total_items' => $quiz_attempts_count,
				'per_page'    => $item_per_page,
				'paged'       => $current_page,
			);
			$pagination_template_frontend = tutor()->path . 'templates/dashboard/elements/pagination.php';
			tutor_load_template_from_custom_path( $pagination_template_frontend, $pagination_data );
		?>
		</div>
	</div>
</div>
