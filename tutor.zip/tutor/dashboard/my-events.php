<?php
/**
 * My Courses Page
 *
 * @package Tutor\Templates
 * @subpackage Dashboard
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.4.3
 */

use TUTOR\Input;
use Tutor\Models\EventModel;

// Get the user ID and active tab.
$current_user_id                     = get_current_user_id();
! isset( $active_tab ) ? $active_tab = 'my-events' : 0;

// Map required course status according to page.
$status_map = array(
	'my-events'                => 'publish',
	'my-events/draft-events'   => 'draft',
	'my-events/pending-events' => 'pending',
);

// Set currently required course status fo rcurrent tab.
$status = isset( $status_map[ $active_tab ] ) ? $status_map[ $active_tab ] : 'publish';

// Get counts for course tabs.
$count_map = array(
	'publish' => EventModel::get_events_by_instructor( $current_user_id, EventModel::STATUS_PUBLISH, 0, 0, true ),
	'pending' => EventModel::get_events_by_instructor( $current_user_id, EventModel::STATUS_PENDING, 0, 0, true ),
	'draft'   => EventModel::get_events_by_instructor( $current_user_id, EventModel::STATUS_DRAFT, 0, 0, true ),
);

$course_archive_arg = isset( $GLOBALS['tutor_course_archive_arg'] ) ? $GLOBALS['tutor_course_archive_arg']['column_per_row'] : null;
$courseCols         = null === $course_archive_arg ? tutor_utils()->get_option( 'courses_col_per_row', 4 ) : $course_archive_arg;
$per_page           = tutor_utils()->get_option( 'courses_per_page', 10 );
$paged              = Input::get( 'current_page', 1, Input::TYPE_INT );
$offset             = $per_page * ( $paged - 1 );

$results = EventModel::get_events_by_instructor( $current_user_id, $status, $offset, $per_page );
?>
<div class="rbt-dashboard-content bg-color-white rbt-shadow-box">
	<div class="content">
		<div class="section-title d-flex justify-content-between align-items-center">
			<h4 class="rbt-title-style-3"><?php esc_html_e( 'My Events', 'tutor' ); ?></h4>
			<a class="rbt-btn-link" href="<?php echo admin_url('post-new.php?post_type=olc_events'); ?>">Create an event<i class="feather-arrow-right"></i></a>
		</div>
		<div class="advance-tab-button mb--30">
			<ul class="nav nav-tabs tab-button-style-2 justify-content-start">
				<li role="presentation">
					<a href="<?php echo esc_url( tutor_utils()->get_tutor_dashboard_page_permalink( 'my-events' ) ); ?>" class="tab-button <?php echo esc_attr( 'my-events' === $active_tab ? 'active' : '' ); ?>">
						<span class="title"><?php esc_html_e( 'Publish', 'tutor' ); ?> <?php echo esc_html( '(' . $count_map['publish'] . ')' ); ?></span>
					</a>
				</li>
				<li role="presentation">
					<a href="<?php echo esc_url( tutor_utils()->get_tutor_dashboard_page_permalink( 'my-events/pending-events' ) ); ?>" class="tab-button <?php echo esc_attr( 'my-events/pending-events' === $active_tab ? 'active' : '' ); ?>">
						<span class="title"><?php esc_html_e( 'Pending', 'tutor' ); ?> <?php echo esc_html( '(' . $count_map['pending'] . ')' ); ?></span>
					</a>
				</li>
				<li role="presentation">
					<a href="<?php echo esc_url( tutor_utils()->get_tutor_dashboard_page_permalink( 'my-events/draft-events' ) ); ?>" class="tab-button <?php echo esc_attr( 'my-events/draft-events' === $active_tab ? 'active' : '' ); ?>">
						<span class="title"><?php esc_html_e( 'Draft', 'tutor' ); ?> <?php echo esc_html( '(' . $count_map['draft'] . ')' ); ?></span>
					</a>
				</li>
			</ul>
		</div>

		<div class="tab-content">
			<div class="tab-pane fade active show">
				<!-- Course list -->
				<?php
				$placeholder_img = tutor()->url . 'assets/images/placeholder.svg';

				if ( ! is_array( $results ) || ( ! count( $results ) && 1 == $paged ) ) {
					tutor_utils()->tutor_empty_state( tutor_utils()->not_found_text() );
				} else {
					?>
					<div class="row g-5">
						<?php
						global $post;
						foreach ( $results as $post ) :
							setup_postdata( $post );
							$event_location 		= function_exists('get_field')? get_field('location', get_the_ID()) : '';
                            $event_start_datetime 	= function_exists('get_field')? get_field('start_date_time', get_the_ID()) : '';
                            $event_end_datetime 	= function_exists('get_field')? get_field('end_date_time', get_the_ID()) : '';

                            $event_start_time 		= !empty($event_start_datetime)? date('hh:mm a', strtotime($event_start_datetime)) : '';
                            $event_end_time 		= !empty($event_end_datetime)? date('hh:mm a', strtotime($event_end_datetime)) : '';


                            $event_time = sprintf('%s - %s', $event_start_time, $event_end_time);
							$_event_thumbnail = get_the_post_thumbnail_url( get_the_ID(), 'large' );
                            $_placeholder_img = olc_get_placeholder_img();
							?>
							<div class="col-lg-4 col-md-6 col-12">
								<div class="rbt-card event-grid-card variation-01 rbt-hover">
									<div class="rbt-card-img">
										<a href="<?php the_permalink(); ?>">
											<img src="<?php echo !$_event_thumbnail? $_placeholder_img : $_event_thumbnail; ?>" alt="<?php echo esc_html(get_the_title()); ?>">
											<div class="rbt-badge-3 bg-white">
												<span><?php echo get_the_date('d M'); ?></span>
												<span><?php echo get_the_date('Y'); ?></span>
											</div>
										</a>
									</div>
									<div class="rbt-card-body">
										<ul class="rbt-meta">
											<li><i class="feather-map-pin"></i><?php echo esc_html($event_location); ?></li>
											<li><i class="feather-clock"></i><?php echo esc_html($event_time); ?></li>
										</ul>
										<h4 class="rbt-card-title"><a href="<?php the_permalink(); ?>"><?php echo esc_html(get_the_title()); ?></a></h4>

										<div class="read-more-btn">
											<a class="rbt-btn btn-border hover-icon-reverse btn-sm radius-round" href="<?php the_permalink(); ?>">
												<span class="icon-reverse-wrapper">
													<span class="btn-text"><?php _e('Get Ticket', 'open-learning'); ?></span>
												<span class="btn-icon"><i class="feather-arrow-right"></i></span>
												<span class="btn-icon"><i class="feather-arrow-right"></i></span>
												</span>
											</a>
										</div>
									</div>
								</div>
							</div>
							<?php
						endforeach;
						wp_reset_postdata();
						?>
					</div>
					<div class="tutor-mt-20">
						<?php
						if ( $count_map[ $status ] > $per_page ) {
							$pagination_data = array(
								'total_items' => $count_map[ $status ],
								'per_page'    => $per_page,
								'paged'       => $paged,
							);

							tutor_load_template_from_custom_path(
								get_parent_theme_file_path() . '/tutor/dashboard/elements/pagination.php',
								$pagination_data
							);
						}
						?>

					</div>
					<?php
				}
				?>
			</div>
		</div>
	</div>
</div>
