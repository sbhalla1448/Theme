<?php
/**
 * Already logged in template
 *
 * @package Tutor\Templates
 * @subpackage Dashboard
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.4.3
 */

?>

<div class="rbt-elements-area bg-color-white rbt-section-gap">
    <div class="container">
        <div class="row gy-5 row--30">
            <div class="col-lg-6 m-auto">
                <div class="rbt-contact-form contact-form-style-1 max-width-auto">
                    <h5 class="title"><?php esc_html_e( 'You are already logged in', 'tutor' ); ?></h5>
                </div>
            </div>
        </div>
    </div>
</div>
