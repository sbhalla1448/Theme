<?php
/**
 * Frontend Settings Page
 *
 * @package Tutor\Templates
 * @subpackage Dashboard
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @version 1.4.3
 */

?>
<div class="rbt-dashboard-content bg-color-white rbt-shadow-box">
	<div class="content">
		<div class="section-title">
			<h4 class="rbt-title-style-3"><?php esc_html_e( 'Settings', 'tutor' ); ?></h4>
		</div>

		<div class="advance-tab-button mb--30">
			<?php
				tutor_load_template( 'dashboard.settings.nav-bar', array( 'active_setting_nav' => 'profile' ) );
			?>
		</div>

		<div class="tab-content">
			<div class="tab-pane fade" id="social" role="tabpanel" aria-labelledby="social-tab">
				<!-- Start Profile Row  -->
				<form action="#" class="rbt-profile-row rbt-default-form row row--15">
					<div class="col-12">
						<div class="rbt-form-group">
							<label for="facebook"><i class="feather-facebook"></i> Facebook</label>
							<input id="facebook" type="text" placeholder="https://facebook.com/">
						</div>
					</div>
					<div class="col-12">
						<div class="rbt-form-group">
							<label for="twitter"><i class="feather-twitter"></i> Twitter</label>
							<input id="twitter" type="text" placeholder="https://twitter.com/">
						</div>
					</div>
					<div class="col-12">
						<div class="rbt-form-group">
							<label for="linkedin"><i class="feather-linkedin"></i> Linkedin</label>
							<input id="linkedin" type="text" placeholder="https://linkedin.com/">
						</div>
					</div>
					<div class="col-12">
						<div class="rbt-form-group">
							<label for="website"><i class="feather-globe"></i> Website</label>
							<input id="website" type="text" placeholder="https://website.com/">
						</div>
					</div>
					<div class="col-12">
						<div class="rbt-form-group">
							<label for="github"><i class="feather-github"></i> Github</label>
							<input id="github" type="text" placeholder="https://github.com/">
						</div>
					</div>
					<div class="col-12 mt--10">
						<div class="rbt-form-group">
							<a class="rbt-btn btn-gradient" href="#">Update Profile</a>
						</div>
					</div>
				</form>
				<!-- End Profile Row  -->
			</div>
		</div>
	</div>
	<?php
	if ( isset( $GLOBALS['tutor_setting_nav']['profile'] ) ) {
		tutor_load_template( 'dashboard.settings.profile' );
	} else {
		foreach ( $GLOBALS['tutor_setting_nav'] as $page ) {
			echo '<script>window.location.replace("', esc_url( $page['url'] ), '");</script>';
			break;
		}
	}
	?>
</div>
