<?php
/**
 * Enrolled Courses Page
 *
 * @package Tutor\Templates
 * @subpackage Dashboard
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.4.3
 */

use TUTOR\Input;

// Pagination.
$per_page = tutor_utils()->get_option( 'pagination_per_page', 10 );
$paged    = max( 1, Input::get( 'current_page', 1, Input::TYPE_INT ) );
$offset   = ( $per_page * $paged ) - $per_page;

$page_tabs = array(
	'enrolled-courses'                   => __( 'Enrolled Courses', 'tutor' ),
	'enrolled-courses/active-courses'    => __( 'Active Courses', 'tutor' ),
	'enrolled-courses/completed-courses' => __( 'Completed Courses', 'tutor' ),
);

// Default tab set.
( ! isset( $active_tab, $page_tabs[ $active_tab ] ) ) ? $active_tab = 'enrolled-courses' : 0;

// Get Paginated course list.
$courses_list_array = array(
	'enrolled-courses'                   => tutor_utils()->get_enrolled_courses_by_user( get_current_user_id(), array( 'private', 'publish' ), $offset, $per_page ),
	'enrolled-courses/active-courses'    => tutor_utils()->get_active_courses_by_user( null, $offset, $per_page ),
	'enrolled-courses/completed-courses' => tutor_utils()->get_courses_by_user( null, $offset, $per_page ),
);

// Get Full course list.
$full_courses_list_array = array(
	'enrolled-courses'                   => tutor_utils()->get_enrolled_courses_by_user( get_current_user_id(), array( 'private', 'publish' ) ),
	'enrolled-courses/active-courses'    => tutor_utils()->get_active_courses_by_user(),
	'enrolled-courses/completed-courses' => tutor_utils()->get_courses_by_user(),
);


// Prepare course list based on page tab.
$courses_list           = $courses_list_array[ $active_tab ];
$paginated_courses_list = $full_courses_list_array[ $active_tab ];

?>
<div class="rbt-dashboard-content bg-color-white rbt-shadow-box">
	<div class="content">
		<div class="section-title">
			<h4 class="rbt-title-style-3"><?php echo esc_html( $page_tabs[ $active_tab ] ); ?></h4>
		</div>
	</div>
	<div class="advance-tab-button mb--30">
		<ul class="nav nav-tabs tab-button-style-2 justify-content-start" tutor-priority-nav>
			<?php foreach ( $page_tabs as $slug => $tab ) : ?>
				<li class="tutor-nav-item">
					<a class="tab-button<?php echo $slug == $active_tab ? ' active' : ''; ?>" href="<?php echo esc_url( tutor_utils()->get_tutor_dashboard_page_permalink( $slug ) ); ?>">
						<span class="title">
						<?php
						echo esc_html( $tab );

						$course_count = ( $full_courses_list_array[ $slug ] && $full_courses_list_array[ $slug ]->have_posts() ) ? count( $full_courses_list_array[ $slug ]->posts ) : 0;
						if ( $course_count ) :
							echo esc_html( '&nbsp;(' . $course_count . ')' );
						endif;
						?>
						</span>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
	<div class="tab-content">
		<div class="tab-pane fade active show">
			<?php if ( $courses_list && $courses_list->have_posts() ) : ?>
				<div class="row g-5">
					<?php
					while ( $courses_list->have_posts() ) :
						$courses_list->the_post();
						$course_students    = tutor_utils()->count_enrolled_users_by_course();
						$topics_ids = get_posts(array(
							'post_parent'	=> get_the_ID(),
							'post_type'		=> 'topics',
							'fields' 		=> 'ids'
						));
						
						$lessons_count = 0;
						foreach( $topics_ids as $topic ){
							$lessons_ids = get_posts(array(
								'post_type'		=> 'lesson',
								'post_parent'	=> $topic,
								'fields' 		=> 'ids'
							));
						
							$lessons_count += count($lessons_ids);
						}
					?>
					<div class="col-lg-4 col-md-6 col-12">
                        <div class="rbt-card variation-01 rbt-hover">
						<?php tutor_load_template( 'loop.thumbnail' ); ?>
						<div class="rbt-card-body">
							<?php tutor_load_template( 'loop.rating' ); ?>
							<h4 class="rbt-card-title">
								<a href="<?php echo esc_url( get_the_permalink() ); ?>">
									<?php the_title(); ?>
								</a>
							</h4>
							<ul class="rbt-meta">
								<li><i class="feather-book"></i><?php echo esc_html($lessons_count); ?>  Lessons</li>
								<li><i class="feather-users"></i><?php echo esc_html($course_students); ?> Students</li>
							</ul>
							<?php tutor_load_template( 'loop.enrolled-course-progress' ); ?>
							
							<?php tutor_course_loop_price(); ?>
						</div>
						</div>
					</div>
					<?php
					endwhile;
					wp_reset_postdata();
					?>
				</div>
				
				<div class="tutor-mt-20">
					<?php
					if ( $paginated_courses_list->found_posts > $per_page ) :
						$pagination_data = array(
							'total_items' => $paginated_courses_list->found_posts,
							'per_page'    => $per_page,
							'paged'       => $paged,
						);
						tutor_load_template_from_custom_path(
							tutor()->path . 'templates/dashboard/elements/pagination.php',
							$pagination_data
						);
					endif;
					?>
				</div>
			<?php else : ?>
				<?php tutor_utils()->tutor_empty_state( tutor_utils()->not_found_text() ); ?>
			<?php endif; ?>
		</div>
	</div>
</div>

