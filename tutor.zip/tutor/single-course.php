<?php
/**
 * Template for displaying single course
 *
 * @package Tutor\Templates
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.0.0
 */


$filter_object = new \TUTOR\Course_Filter();
$course_levels   = tutor_utils()->course_levels();
$supported_filters = tutor_utils()->get_option( 'supported_course_filters', array() );
$supported_filters = array_keys( $supported_filters );


$category = get_queried_object();  // Get the current category object
$category_id = $category->term_id;

$course_id       = get_the_ID();

$course_rating   = tutor_utils()->get_course_rating( $course_id );
$is_enrolled     = tutor_utils()->is_enrolled( $course_id, get_current_user_id() );
wp_enqueue_style('tutor-reset-css');

// Prepare the nav items.
$course_nav_item = apply_filters( 'tutor_course/single/nav_items', array(
	'info'          => array(
		'title'  => __( 'Course Info', 'tutor' ),
		'method' => 'tutor_course_info_custom', 
	),
	'curriculam'          => array(
		'title'  => __( 'Course Curriculum', 'tutor' ),
		'method' => 'tutor_course_topics',
	),
	'reviews'       => array(
		'title'  => __( 'Ratings & Reviews', 'tutor' ),
		'method' => 'tutor_course_target_reviews_html',
	),
	'announcements' => array(
		'title'             => __( 'Announcements', 'tutor' ),
		'method'            => 'tutor_course_announcements'
	),
), $course_id );
if( isset($course_nav_item['resources'])) unset($course_nav_item['resources']);
$is_public       = \TUTOR\Course_List::is_public( $course_id );
$is_mobile       = wp_is_mobile();

$enrollment_box_position = tutor_utils()->get_option( 'enrollment_box_position_in_mobile', 'bottom' );
if ( '-1' === $enrollment_box_position ) {
	$enrollment_box_position = 'bottom';
}
$student_must_login_to_view_course = tutor_utils()->get_option( 'student_must_login_to_view_course' );
$total_students_in_course = tutor_utils()->count_enrolled_users_by_course($course_id);
$course_categories 	= get_tutor_course_categories($course_id);
$profile_url       = tutor_utils()->profile_url( $authordata->ID, true );
tutor_utils()->tutor_custom_header();

if ( ! is_user_logged_in() && ! $is_public && $student_must_login_to_view_course ) {
	tutor_load_template( 'login' );
	tutor_utils()->tutor_custom_footer();
	return;
}
$tutor_load_sidebar_actions = apply_filters( 'tutor_load_single_sidebar_actions', true, get_the_ID() );
$default_meta            = array(
	array(
		'icon_class' => 'tutor-icon-mortarboard',
		'label'      => __( 'Course Code', 'tutor' ),
		'value'      => function_exists('get_field') ? get_field('course_code') : ''
	),
	array(
		'icon_class' => 'tutor-icon-mortarboard',
		'label'      => __( 'Enrolment Fee', 'tutor' ),
		'value'      => tutor_utils()->get_course_price( $course_id )
	),
	array(
		'icon_class' => 'tutor-icon-mortarboard',
		'label'      => __( 'Award Level', 'tutor' ),
		'value'      => function_exists('get_field') ? get_field('award_level') : ''
	),
	array(
		'icon_class' => 'tutor-icon-mortarboard',
		'label'      => __( 'Format', 'tutor' ),
		'value'      => function_exists('get_field') ? get_field('formal') : ''
	),
	array(
		'icon_class' => 'tutor-icon-mortarboard',
		'label'      => __( 'Accreditation', 'tutor' ),
		'value'      => function_exists('get_field') ? get_field('accreditation') : ''
	),
	array(
		'icon_class' => 'tutor-icon-clock-line',
		'label'      => __( 'Study Time', 'tutor' ),
		'value'      => function_exists('get_field') ? get_field('study_time') : ''
	),
	array(
		'icon_class' => 'tutor-icon-mortarboard',
		'label'      => __( 'Experience', 'tutor' ),
		'value'      => function_exists('get_field') ? get_field('experience') : ''
	),
	array(
		'icon_class' => 'tutor-icon-refresh-o',
		'label'      => __( 'Type of Award', 'tutor' ),
		'value'      => function_exists('get_field') ? get_field('type_of_certificate') : ''
	)
);


// Right sidebar meta data.
$sidebar_meta = apply_filters( 'tutor/course/single/sidebar/metadata', $default_meta, get_the_ID() );
?>
<?php
if( !empty(generate_breadcrumb($course_categories) )) { ?>
<!-- Start breadcrumb Area -->
<div class="rbt-breadcrumb-default rbt-breadcrumb-style-3 single-page-hero-wrap" style="background: var(--secondary-100, #243C45);">
	<div class="container ">
		<div class="row">
			<div class="col-lg-7">
				<div class="content text-start">
					<ul class="page-list single-breadcrumb">
						<li class="rbt-breadcrumb-item"><a href="<?php echo home_url('/'); ?>"><?php echo esc_html__('Home', 'open-learning'); ?></a></li>
						<?php 
						$category_links = array();							   
						foreach( generate_breadcrumb($course_categories) as $a_cat ) {
							
								$category_link    = get_term_link( $a_cat->term_id );
						?>
						<li>
							<div class="icon-right"><i class="feather-chevron-right"></i></div>
						</li>
						<li class="rbt-breadcrumb-item active"><a href="<?php echo esc_url( $category_link ); ?>"><?php echo esc_html($a_cat->name); ?></a></li>
						<?php } ?>						
					</ul>
					<h2 class="title"><?php the_title(); ?></h2>
					<p style="margin-bottom:30px;" class="description"><?php echo wp_trim_words(get_the_excerpt(), 40); ?></p>

					<div style="margin-bottom:12px;" class="d-flex align-items-center flex-wrap rbt-course-details-feature">
						<?php
						$is_best_seller = function_exists('get_field') ? get_field('is_best_seller') : false;
						if( is_array($is_best_seller) && !empty($is_best_seller) && $is_best_seller[0] == 'yes' ) {
						?>
						<div class="feature-sin best-seller-badge rbt-badge-7">
							<svg xmlns="http://www.w3.org/2000/svg" width="14" height="18" viewBox="0 0 14 18" fill="none">
							<path fill-rule="evenodd" clip-rule="evenodd" d="M7.00327 0.666992C4.55825 0.666992 2.57617 2.65752 2.57617 5.11297C2.57617 7.56842 4.55825 9.55895 7.00327 9.55895C9.44829 9.55895 11.4304 7.56842 11.4304 5.11297C11.4304 2.65752 9.44829 0.666992 7.00327 0.666992ZM7.00327 1.87338C8.78485 1.87338 10.2291 3.3238 10.2291 5.11297C10.2291 6.90214 8.78485 8.35256 7.00327 8.35256C5.22169 8.35256 3.77744 6.90214 3.77744 5.11297C3.77744 3.3238 5.22169 1.87338 7.00327 1.87338ZM5.19236 11.3511C4.54426 11.3961 3.88916 11.4886 3.24298 11.6271C1.9958 11.884 0.998028 12.3972 0.57335 13.2502C0.413174 13.5838 0.332642 13.941 0.334001 14.3026C0.333521 14.6616 0.4134 15.0192 0.567833 15.3464C0.975604 16.1896 1.85715 16.6667 3.04752 16.9312L3.26076 16.9757C3.88939 17.1175 4.54469 17.213 5.20437 17.2579C5.26056 17.2743 5.39446 17.2896 5.54062 17.2971L5.66083 17.3016C5.72265 17.303 5.7928 17.3034 5.89732 17.3034C6.84552 17.3556 7.8285 17.3404 8.80691 17.2571C9.32832 17.2214 9.85323 17.1532 10.3738 17.0533L10.7632 16.9725C12.0486 16.7189 13.0111 16.2367 13.4328 15.3473C13.7454 14.6871 13.7454 13.9209 13.433 13.2609C13.0123 12.3739 12.0621 11.8957 10.7535 11.6261C10.24 11.5165 9.71832 11.4354 9.19288 11.3836L8.80874 11.3511C7.60559 11.2449 6.3955 11.2449 5.19236 11.3511ZM8.70362 12.5528L8.71418 12.5537C9.31722 12.5961 9.91657 12.6808 10.5079 12.807C11.4799 13.0072 12.1395 13.3392 12.3482 13.7793C12.5054 14.1112 12.5054 14.4968 12.3481 14.829C12.1531 15.2402 11.5607 15.5579 10.7044 15.7521L10.5169 15.7918C9.91397 15.9263 9.3166 16.013 8.71528 16.0542C7.78226 16.1336 6.85477 16.1479 5.92962 16.0979L5.60162 16.0923C5.51056 16.0876 5.43383 16.0788 5.36271 16.0646C4.79958 16.0221 4.29287 15.9548 3.80087 15.8573L3.50711 15.7951C2.53207 15.604 1.86661 15.2706 1.65085 14.8245C1.57535 14.6645 1.53502 14.4839 1.53526 14.3011C1.53459 14.1193 1.57438 13.9428 1.65163 13.7819C1.86142 13.3607 2.56664 12.9979 3.48903 12.8079C4.08459 12.6802 4.68366 12.5956 5.28643 12.5537C6.43067 12.4529 7.57042 12.4529 8.70362 12.5528Z" fill="white"/>
							</svg>
							<span>Bestseller</span>
						</div>
						<?php } ?>
						<div class="feature-sin total-rating rbt-badge-7">
							<svg xmlns="http://www.w3.org/2000/svg" width="18" height="16" viewBox="0 0 18 16" fill="none">
							<path fill-rule="evenodd" clip-rule="evenodd" d="M3.51685 15.2497C3.73685 15.6605 4.16602 15.9172 4.63268 15.9163C4.82935 15.9172 5.02435 15.8713 5.19935 15.783L8.99268 13.7997C9.00268 13.7938 9.01435 13.7905 9.02602 13.7913L12.7935 15.758C12.976 15.8563 13.1802 15.9072 13.3868 15.9063C13.4527 15.9063 13.5193 15.9005 13.5843 15.8913C14.2627 15.7805 14.726 15.1455 14.626 14.4663L13.8927 10.2913C13.8884 10.2853 13.8873 10.2849 13.887 10.2843C13.8868 10.284 13.8868 10.2837 13.8868 10.283C13.8868 10.2805 13.8927 10.2747 13.8927 10.2747L16.951 7.31634C17.4027 6.88051 17.4602 6.17801 17.0843 5.67467C16.8802 5.41134 16.581 5.23801 16.251 5.19134L12.0327 4.58301C12.0252 4.58301 12.0168 4.57467 12.0085 4.56634L10.1243 0.783008C9.91185 0.355508 9.47685 0.0855078 8.99935 0.0830078C8.86102 0.0830078 8.72268 0.104674 8.59102 0.149674C8.27518 0.257174 8.01435 0.483841 7.86602 0.783008L5.98435 4.55551C5.98435 4.57301 5.96685 4.58051 5.95018 4.58051L1.74185 5.18884C1.48435 5.23217 1.24435 5.34717 1.05018 5.52217C0.804349 5.76301 0.666016 6.09384 0.666016 6.43884C0.666849 6.76634 0.798516 7.07967 1.03268 7.30801L4.11602 10.2747C4.12268 10.2813 4.12518 10.2905 4.12518 10.2997L3.38268 14.458C3.33852 14.7297 3.38602 15.008 3.51685 15.2497ZM8.97468 1.30539L8.98301 1.29956H8.99884L9.00634 1.30706C9.01384 1.30706 9.02051 1.30873 9.02634 1.31373C9.03134 1.31873 9.03384 1.32539 9.03301 1.33289L10.9163 5.09873C11.0972 5.46956 11.4488 5.72789 11.8572 5.79039L16.0755 6.40373C16.083 6.40373 16.0905 6.40539 16.0972 6.40873C16.1013 6.40956 16.1047 6.40956 16.1088 6.40873L16.1172 6.41623L16.1088 6.43456L13.0505 9.40039C12.7463 9.68539 12.6105 10.1071 12.6913 10.5162L13.4255 14.6671L13.4088 14.6829H13.3913C13.388 14.6846 13.3847 14.6846 13.3813 14.6829C13.373 14.6821 13.3647 14.6787 13.3572 14.6746H13.3497L9.59968 12.7162C9.41968 12.6229 9.21968 12.5729 9.01634 12.5737C8.80718 12.5737 8.60051 12.6262 8.41551 12.7246L4.64134 14.7037C4.63718 14.7046 4.63218 14.7046 4.62801 14.7037C4.61051 14.7037 4.59551 14.6921 4.59134 14.6754V14.6587L5.32468 10.5087C5.39301 10.1029 5.25968 9.68873 4.96634 9.40039L1.88301 6.44206C1.88218 6.42956 1.88384 6.41873 1.89051 6.40789L1.94134 6.39123L6.13301 5.79039C6.54134 5.72706 6.89218 5.46956 7.07384 5.09873L8.95801 1.32373C8.96218 1.31623 8.96718 1.30956 8.97468 1.30539Z" fill="white"/>
							</svg>
							<span><?php the_field('number_of_reviews'); ?></span>
							<span>Reviews</span>
						</div>

						<div class="feature-sin total-student rbt-badge-7">
							<svg xmlns="http://www.w3.org/2000/svg" width="20" height="15" viewBox="0 0 20 15" fill="none">
							<path fill-rule="evenodd" clip-rule="evenodd" d="M9.94763 0.864746C7.81801 0.864746 6.10742 2.57533 6.10742 4.70495C6.10742 6.8352 7.81787 8.54593 9.94763 8.54593C12.0774 8.54593 13.7878 6.8352 13.7878 4.70495C13.7878 2.57533 12.0773 0.864746 9.94763 0.864746ZM9.94763 2.11475C11.3869 2.11475 12.5378 3.26569 12.5378 4.70495C12.5378 6.14489 11.387 7.29593 9.94763 7.29593C8.50827 7.29593 7.35742 6.14489 7.35742 4.70495C7.35742 3.26569 8.50836 2.11475 9.94763 2.11475ZM17.7058 4.69235C17.7058 3.01198 16.3429 1.64964 14.6623 1.64964C14.3172 1.64964 14.0373 1.92946 14.0373 2.27464C14.0373 2.61982 14.3172 2.89964 14.6623 2.89964C15.6527 2.89964 16.4558 3.70246 16.4558 4.69235C16.4558 5.68224 15.6527 6.48506 14.6623 6.48506C14.3172 6.48506 14.0373 6.76488 14.0373 7.11006C14.0373 7.45524 14.3172 7.73506 14.6623 7.73506C16.3429 7.73506 17.7058 6.37272 17.7058 4.69235ZM17.0791 9.29609C16.6789 9.20578 16.2513 9.14404 15.8165 9.11405C15.4721 9.09031 15.1737 9.35021 15.1499 9.69457C15.1262 10.0389 15.3861 10.3373 15.7305 10.3611C16.1026 10.3868 16.4672 10.4394 16.8218 10.5192C17.3732 10.6274 17.7327 10.8067 17.8219 10.9937C17.889 11.1348 17.889 11.3008 17.8213 11.4436C17.7332 11.6287 17.3767 11.8071 16.8331 11.9189C16.495 11.9885 16.2773 12.3189 16.3468 12.657C16.4164 12.9951 16.7468 13.2128 17.0849 13.1433C17.9834 12.9585 18.6416 12.6291 18.9504 11.9799C19.1793 11.4973 19.1793 10.9375 18.9504 10.4561C18.6394 9.8045 17.9699 9.47049 17.0791 9.29609ZM5.24074 1.64966C5.58592 1.64966 5.86574 1.92948 5.86574 2.27466C5.86574 2.61984 5.58592 2.89966 5.24074 2.89966C4.25043 2.89966 3.44727 3.70247 3.44727 4.69237C3.44727 5.68226 4.25043 6.48507 5.24074 6.48507C5.58592 6.48507 5.86574 6.7649 5.86574 7.11007C5.86574 7.45525 5.58592 7.73507 5.24074 7.73507C3.5602 7.73507 2.19727 6.37274 2.19727 4.69237C2.19727 3.012 3.5602 1.64966 5.24074 1.64966ZM4.75329 9.69445C4.72954 9.35009 4.43113 9.09019 4.08677 9.11394C3.65194 9.14392 3.2243 9.20566 2.80699 9.29958L2.63495 9.33598C1.84527 9.51641 1.24281 9.84799 0.953629 10.4559C0.72375 10.9369 0.72375 11.4977 0.953871 11.9803C1.26131 12.6288 1.91945 12.9583 2.81832 13.1432C3.15643 13.2127 3.48688 12.995 3.5564 12.6569C3.62593 12.3188 3.4082 11.9883 3.0701 11.9188C2.52669 11.8071 2.17055 11.6287 2.08278 11.4436C2.0144 11.3002 2.0144 11.1352 2.08194 10.9939C2.17109 10.8065 2.53023 10.6272 3.06429 10.5227L3.34198 10.4658C3.6188 10.4146 3.89369 10.3802 4.17277 10.361C4.51713 10.3372 4.77703 10.0388 4.75329 9.69445ZM4.30664 12.3206C4.30664 10.3323 6.36326 9.63306 9.94886 9.63306L10.2029 9.63423C13.6387 9.66651 15.5911 10.3673 15.5911 12.306C15.5911 14.1991 13.7248 14.924 10.4505 14.9887L9.94886 14.9935C6.35504 14.9935 4.30664 14.3066 4.30664 12.3206ZM14.3411 12.306C14.3411 11.3806 12.8573 10.8831 9.94886 10.8831C7.04327 10.8831 5.55664 11.3885 5.55664 12.3206C5.55664 13.2461 7.03996 13.7435 9.94886 13.7435C12.8536 13.7435 14.3411 13.2377 14.3411 12.306Z" fill="white"/>
							</svg>
							<span><?php the_field('number_of_students'); ?><?//php echo esc_html($total_students_in_course); ?></span>
							<span>Students</span>
						</div>

					</div>
					
					<ul class="rbt-meta">
						<li>
						<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
						<path d="M17.9627 8.59207L17.9538 8.60785L17.9509 8.62578C17.9455 8.65969 17.9356 8.69271 17.9214 8.72396C17.8922 8.76402 17.8592 8.80126 17.823 8.83517L17.8177 8.84008L17.8132 8.8457L17.7546 8.91896C17.7142 8.9483 17.67 8.97202 17.6231 8.98944L17.606 8.99582L17.5922 9.00786C17.5766 9.02153 17.5586 9.03231 17.5392 9.03968C17.4604 9.06944 17.3767 9.08419 17.2925 9.08317H17.2913H17.1663L13.6328 8.49287L13.6321 8.49276C13.5357 8.47732 13.4432 8.44304 13.36 8.39186C13.2767 8.34069 13.2044 8.27362 13.1471 8.19449C13.0898 8.11537 13.0487 8.02573 13.026 7.9307C13.0034 7.83567 12.9996 7.7371 13.0151 7.64064C13.0305 7.54417 13.0648 7.45169 13.116 7.36847C13.1671 7.28525 13.2342 7.21293 13.3133 7.15563C13.3925 7.09833 13.4821 7.05718 13.5771 7.03452C13.6721 7.01188 13.7706 7.00815 13.867 7.02354C13.867 7.02356 13.8671 7.02357 13.8672 7.02358L15.2418 7.24852L15.4503 7.28264L15.3446 7.09977C14.8086 6.17322 14.0374 5.40472 13.109 4.87207C12.1809 4.33959 11.1286 4.0617 10.0586 4.0665C8.84851 4.04581 7.66042 4.39157 6.65038 5.05838C5.64002 5.72539 4.85509 6.68245 4.3987 7.80381L4.39858 7.80411C4.36235 7.89396 4.30868 7.97574 4.24067 8.04473C4.17266 8.11371 4.09165 8.16854 4.00233 8.20605C3.913 8.24355 3.81714 8.26298 3.72026 8.26322C3.62338 8.26346 3.52742 8.2445 3.43791 8.20744L3.4374 8.20723C3.25774 8.134 3.11441 7.99256 3.03882 7.81388C2.96332 7.63544 2.96152 7.43439 3.03377 7.25464C3.58856 5.94193 4.50203 4.81212 5.66947 3.99473C6.83713 3.17718 8.21158 2.70528 9.63518 2.63315C11.0588 2.56103 12.4739 2.8916 13.7182 3.58695C14.9625 4.2823 15.9857 5.31428 16.6703 6.56453L16.8052 6.81095L16.8563 6.53469L17.1647 4.86803L17.1647 4.86755C17.1998 4.67264 17.3109 4.49965 17.4735 4.38663C17.6362 4.27362 17.837 4.22984 18.0319 4.26492C18.2269 4.30001 18.3998 4.41108 18.5129 4.57371C18.6258 4.73623 18.6696 4.93693 18.6346 5.13172C18.6346 5.13185 18.6346 5.13199 18.6346 5.13212L18.0098 8.46439C18.0098 8.46448 18.0097 8.46458 18.0097 8.46468C18.0011 8.50942 17.9853 8.55246 17.9627 8.59207ZM3.39966 8.29984C3.50137 8.34195 3.61042 8.36349 3.72051 8.36322C3.83059 8.36295 3.93954 8.34087 4.04104 8.29825C4.14254 8.25563 4.2346 8.19333 4.31188 8.11493C4.38917 8.03654 4.45016 7.9436 4.49132 7.8415C4.9401 6.73884 5.71196 5.79773 6.70547 5.14183C7.69898 4.48594 8.86768 4.14593 10.058 4.1665L3.39966 8.29984ZM17.158 9.18317H17.2913H17.158Z" fill="white" stroke="#243C45" stroke-width="0.2"/>
						<path d="M16.5295 11.8176L16.5295 11.8176L16.5308 11.8181C16.7095 11.8886 16.8535 12.0264 16.9317 12.2019C17.0095 12.3769 17.0159 12.5753 16.9495 12.7548C16.3938 14.0665 15.4799 15.1952 14.3124 16.0115C13.1443 16.8283 11.7696 17.2993 10.346 17.3706C8.92247 17.4418 7.50765 17.1105 6.2638 16.4144C5.01995 15.7184 3.99744 14.6859 3.31353 13.4354L3.17861 13.1887L3.12746 13.4652L2.81913 15.1318L2.81909 15.1321C2.78785 15.3029 2.697 15.4571 2.56271 15.5672C2.42842 15.6773 2.2594 15.7362 2.08576 15.7334L2.08576 15.7334H2.08413H1.94307C1.84731 15.7155 1.75603 15.6788 1.67459 15.6252C1.5908 15.5701 1.51921 15.4984 1.46423 15.4146C1.40925 15.3307 1.37204 15.2365 1.35492 15.1377C1.33779 15.0389 1.34111 14.9377 1.36466 14.8402L1.36479 14.8402L1.36575 14.8351L1.99075 11.5018L1.99075 11.5018L1.99084 11.5013C1.99757 11.4643 2.01203 11.4292 2.03326 11.3983L2.04382 11.3829L2.04811 11.3647C2.05828 11.3217 2.07317 11.2799 2.09251 11.2402L2.15846 11.1669L2.15866 11.1671L2.16326 11.1612C2.20051 11.113 2.24363 11.0696 2.29161 11.032C2.36076 10.9887 2.43573 10.9555 2.51423 10.9334H2.56746H2.5766L2.58559 10.9317C2.6645 10.9172 2.74541 10.9172 2.82433 10.9317L2.82432 10.9317L2.82643 10.9321L6.3681 11.5071L6.36805 11.5074L6.37615 11.5081C6.57073 11.5236 6.75115 11.6158 6.87773 11.7644C7.00431 11.913 7.06668 12.1058 7.05111 12.3004C7.03554 12.495 6.94332 12.6754 6.79473 12.802C6.64613 12.9286 6.45334 12.9909 6.25877 12.9754L6.25879 12.975H6.25079H6.12559L4.75861 12.7513L4.55012 12.7172L4.6559 12.9001C5.19182 13.8267 5.96303 14.5952 6.89146 15.1278C7.81961 15.6603 8.87195 15.9382 9.94199 15.9334C11.1425 15.95 12.3205 15.606 13.3234 14.9459C14.3266 14.2857 15.1086 13.3395 15.5682 12.23L15.5682 12.23L15.5689 12.2282C15.6044 12.1377 15.6576 12.0552 15.7253 11.9854C15.793 11.9157 15.8739 11.8601 15.9633 11.8219C16.0527 11.7836 16.1488 11.7636 16.246 11.7628C16.3432 11.7621 16.4396 11.7807 16.5295 11.8176Z" fill="white" stroke="#243C45" stroke-width="0.2"/>
						</svg>
						<?php
							$last_updated = sprintf('Last updated %s', get_tutor_option( 'enable_course_update_date' ) ? get_the_modified_date( get_option( 'date_format' ) ) : get_the_date());
							echo $last_updated;
						?>
						</li>
						<?php
						$course_language = function_exists('get_field') ? get_field('course_language') : false;
						if( $course_language ) {
						?>
						<li><i class="feather-globe"></i><?php echo $course_language; ?></li>
						<?php
						}
						$is_certificed = function_exists('get_field') ? get_field('is_certified') : false;
						if( is_array($is_certificed) && !empty($is_certificed) && $is_certificed[0] == 'yes' ) {
						?>
						<li><i class="feather-award"></i>Accredited Course</li>
						<?php } ?>
					</ul>

				</div>
			</div>
			<div class="col-lg-5">
				<div class="course-thumbnail-video">
					<!-- Start Viedo Wrapper  -->
					<?php
						$placeHolderUrl    	= tutor()->url . 'assets/images/placeholder.svg';
						$thumbnail_url 		= get_the_post_thumbnail_url($course_id);
						$course_video_url   = '';
						$video_info = tutor_utils()->get_video_info();
						if( !empty($video_info->source_youtube) ){
							$course_video_url = esc_html($video_info->source_youtube);
						} elseif( !empty($video_info->source_external_url ) ) {
							$course_video_url = esc_html($video_info->source_external_url);
						} elseif( !empty($video_info->source_vimeo) ) {
							$course_video_url = esc_html($video_info->source_vimeo);
						}
					if( $course_video_url ) {
					?>
						<a class="video-popup-with-text video-popup-wrapper text-center popup-video sidebar-video-hidden" href="<?php echo esc_url($course_video_url); ?>">							
							<div class="video-content">
								<img class="w-100 rbt-radius" src="<?php echo esc_url($thumbnail_url)? esc_url($thumbnail_url) : esc_url($placeHolderUrl); ?>" alt="Video Images">
								<div class="position-to-top">
									<span class="rbt-btn rounded-player-2 with-animation" style="display:flex;justify-content:center;align-items:center;">

									<i style="font-size:24px;" class="fa fa-play"></i>
									</span>									
								</div>
							</div>
						</a>
					<?php } else { ?>
						<div class="video-content">
							<img class="w-100 rbt-radius" src="<?php echo esc_url($thumbnail_url)? esc_url($thumbnail_url) : esc_url($placeHolderUrl); ?>" alt="Video Images">
						</div>
					<?php } ?>
					<!-- End Viedo Wrapper  -->
				</div>
			</div>
		</div>
	</div>
</div>
<!-- End Breadcrumb Area -->
<?php } ?>
<?php do_action( 'tutor_course/single/before/wrap' ); ?>
<div <?php tutor_post_class( 'tutor-full-width-course-top tutor-course-top-info tutor-page-wrap tutor-wrap-parent pb-5' ); ?>>
	<div class="tutor-course-details-page tutor-container">
		
		<div class="tutor-row tutor-gx-xl-5">
			<main class="tutor-col-xl-8">
				
				<?php do_action( 'tutor_course/single/before/inner-wrap' ); ?>
				
				<?php if ( $is_mobile && 'top' === $enrollment_box_position ) : ?>
					<div class="tutor-mt-32">
						<?php tutor_load_template( 'single.course.course-entry-box' ); ?>
					</div>
				<?php endif; ?>

				<div class="tutor-course-details-tab tutor-mt-32">
					<?php ( isset( $is_enrolled ) && $is_enrolled ) ? tutor_course_enrolled_lead_info() : tutor_course_lead_info(); ?>
					<?php if ( is_array( $course_nav_item ) && count( $course_nav_item ) > 1 ) : ?>
						<div class="tutor-is-sticky">
							<?php tutor_load_template( 'single.course.enrolled.nav', array( 'course_nav_item' => $course_nav_item ) ); ?>
						</div>
					<?php endif; ?>
					<div class="tutor-tab tutor-pt-32">
						<?php if(!empty($course_nav_item)) {
							foreach ( $course_nav_item as $key => $subpage ) : ?>
							<div id="tutor-course-details-tab-<?php echo esc_attr( $key ); ?>" class="tutor-tab-item<?php echo 'info' == $key ? ' is-active' : ''; ?>">
								<?php
									do_action( 'tutor_course/single/tab/' . $key . '/before' );

									$method = $subpage['method'];
									
									if ( is_string( $method ) ) {
										$method();
									} else {
										$_object = $method[0];
										$_method = $method[1];
										$_object->$_method( get_the_ID() );
									}

									do_action( 'tutor_course/single/tab/' . $key . '/after' );
								?>
							</div>
						<?php endforeach; }?>
					</div>
				</div>
				<?php do_action( 'tutor_course/single/after/inner-wrap' ); ?>
				<?php
					$course_id = get_the_ID();
					$course_categories = get_the_terms( $course_id, 'course-category' );
					$course_categories_slug = wp_list_pluck( $course_categories, 'slug' );
					$course_categories_id = wp_list_pluck( $course_categories, 'term_id' );
					$related_courses_loop = new WP_Query(
						array(
							'post_type' => 'courses',
							'post_status' => 'publish',
							'posts_per_page' => 5,
							'post__not_in' => array( $course_id ),
							'tax_query' => array(
								array(
									'taxonomy' => 'course-category',
									'field' => 'term_id',
									'terms' => $course_categories_id,
									'operator' => 'IN'
								)
							)
						)
					);
					$author_id = get_post_field( 'post_author', $course_id );
					if( $related_courses_loop->have_posts() ):
				?>
				<div class="rbt-related-course-area bg-color-white pt--60 rbt-section-gapBottom">
					<div class="container">
						<div class="row g-5 align-items-end mb--40">
						     <hr>
							<div class="col-lg-8 col-md-8 col-12">
								<div class="section-title">
									<h4 class="title">
										<?php echo esc_html__('Related courses', 'open-learning'); ?>
									</h4>
									
								</div>
							</div>
							<hr>
						</div>
						
						<div class="row g-5">
							<?php while( $related_courses_loop->have_posts() ): $related_courses_loop->the_post(); ?>
							<!-- Start Single Card  -->
							<div class="col-12" data-sal-delay="150" data-sal="slide-up" data-sal-duration="800">
								<div class="course-card-2 d-flex align-items-center">
									<div class="course-thumbnail">
										<img src="<?php echo get_tutor_course_thumbnail_src(); ?>" alt="<?php the_title(); ?>">
									</div>
									<div class="course-title-holder">
										<div class="course-title-info">
											<h4 class="course-title">
												<a href="<?php echo get_the_permalink(); ?>"><?php the_title(); ?></a>
											</h4>
											<div class="course-info-date">												
											<span class="course-ours">Updated <?php the_date(); ?></span> . <span class="course-date"><?php the_field('study_time'); ?></span> . 
												<?php 
												global $post, $authordata;
												$course_id         = $post->ID;
												$profile_url       = tutor_utils()->profile_url( $authordata->ID, true );
												$course_categories = get_tutor_course_categories( $course_id );
												$course_duration   = get_tutor_course_duration_context( $course_id, true );
												$course_students   = apply_filters( 'tutor_course_students', tutor_utils()->count_enrolled_users_by_course( $course_id ), $course_id );
												$topics_ids = get_posts(array(
													'post_parent'	=> $course_id,
													'post_type'		=> 'topics',
													'fields' 		=> 'ids'
												));

												$lessons_count = 0;
												foreach( $topics_ids as $topic ){
													$lessons_ids = get_posts(array(
														'post_type'		=> 'lesson',
														'post_parent'	=> $topic,
														'fields' 		=> 'ids'
													));

													$lessons_count += count($lessons_ids);
												}
												if ( tutor_utils()->get_option( 'enable_course_total_enrolled' ) || ! empty( $course_duration ) ) : ?>
												
													<span class="course-lesson">
														<?php echo esc_html($lessons_count); ?> Lessons
													</span>
											<?php endif; ?> . 
											
											<span class="course-level"><?php echo get_tutor_course_level($post->ID); ?></span>
											
											</div>
										</div>
										<div class="course-meta-info">
											<span class="course-rating">
											<?php echo tb_get_icon('star'); ?>
												
												<span>
													<?php 
													$this_course_rating   = tutor_utils()->get_course_rating( get_the_ID() );
													echo esc_html($this_course_rating->rating_avg);
													?>
												</span>
											</span>
											<span class="course-price">
												<?php 
												echo tutor_utils()->get_course_price( get_the_ID() ) ?: wc_price( 0 );
												?>
											</span>
											<span class="bookmark tutor-course-wishlist-btn-custom" data-course-id="<?php echo get_the_ID(); ?>">
												<i class="fa fa-heart <?php echo tutor_utils()->is_wishlisted(get_the_ID(), get_current_user_id()) ? 'bold' : 'line'; ?>"></i>
											</span>
										</div>
									</div>
								</div>
							</div>
							<!-- End Single Card  -->
							<?php endwhile; wp_reset_postdata(); ?>
							<div class="col-12">
								<div class="read-more-btn text-center">
									<a class="rbt-btn rbt-btn-7 d-block" href="https://openlearningcollege.ac/course-finder">
										<span data-text="Show More"><?php esc_html_e('Show More', 'open-learning'); ?></span>
									</a>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php endif; ?>
			</main>

			<aside class="tutor-col-xl-4">
				<div class="tutor-single-course-sidebar tutor-mt-40 tutor-mt-xl-0">
					<?php do_action( 'tutor_course/single/before/sidebar' ); ?>
					
					<?php if ( ( $is_mobile && 'bottom' === $enrollment_box_position ) || ! $is_mobile ) : ?>
						<?php tutor_load_template( 'single.course.course-entry-box' ); ?>
					<?php endif ?>
					<div class="course-prospectus-box d-flex">
						<div class="course-prospectus-meta">
							<h4 class="label"><?php esc_html_e('Course Prospectus', 'open-learning'); ?></h4>
							<p><?php esc_html_e('Get all the course information you need by downloading this brochure.', 'open-learning'); ?></p>
							<?php if(!empty(get_field('prospectus_file'))){?>
							<a href="<?php echo get_field('prospectus_file'); ?>" class="download-prospectus" download>
							<?php esc_html_e('Download Prospectus', 'open-learning'); ?>
							<span>
								<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none">
								<path d="M7.08146 9.29052L7.08146 1.26318" stroke="#008080" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
								<path d="M9.02539 7.33887L7.08139 9.29087L5.13739 7.33887" stroke="#008080" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
								<path d="M10.1698 4.41846H10.7918C12.1485 4.41846 13.2478 5.51779 13.2478 6.87512L13.2478 10.1311C13.2478 11.4845 12.1511 12.5811 10.7978 12.5811L3.37114 12.5811C2.01447 12.5811 0.91447 11.4811 0.91447 10.1245L0.91447 6.86779C0.91447 5.51512 2.0118 4.41846 3.36447 4.41846H3.99247" stroke="#008080" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
								</svg>
							</span>
						</a>
						<?php } ?>
						</div>
						<div class="add-thumbnail">
							<img src="https://openlearningcollege.ac/wp-content/uploads/2024/04/Frame-course.svg" alt="image">
						</div>
						
					</div>

					<div class="tutor-single-course-sidebar-more tutor-mt-24">
						<!-- Course Info -->
						<div class="tutor-card-footer <?php echo esc_attr( $tutor_load_sidebar_actions ? '' : 'tutor-no-border' ); ?>">
							<ul class="tutor-ul">
								<?php foreach ( $sidebar_meta as $key => $meta ) : ?>
									<?php
									if( isset($meta['label']) && $meta['label'] == 'Certificate' ) continue;
									if ( ! $meta['value'] ) {
										continue;
									}
									?>
									<li class="tutor-d-flex justify-content-between align-items-center">
										<span class="course-info-label tutor-color-black" aria-labelledby="<?php echo esc_html( $meta['label'] ); ?>"><?php echo esc_html( $meta['label'] ); ?></span>
										<span class="tutor-fs-4 course-info-text">
											<?php echo wp_kses_post( $meta['value'] ).' '.($meta['label'] == 'Study Time:' ? 'Hrs' : ''); ?>
										</span>
									</li>
								<?php endforeach; ?>
							</ul>
						</div>
						<?php tutor_course_target_audience_html(); ?>
						<?php tutor_course_requirements_html(); ?>
					</div>
					<?php echo do_shortcode('[elementor-template id="15775"]'); ?>
					<?php do_action( 'tutor_course/single/after/sidebar' ); ?>
				</div>
			</aside>
		</div>
	</div>
</div>
<div class="rbt-separator-mid">
	<div class="container">
		<hr class="rbt-separator m-0">
	</div>
</div>
<?php do_action( 'tutor_course/single/after/wrap' ); ?>
<?php
tutor_utils()->tutor_custom_footer();

