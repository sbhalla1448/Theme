<?php
/**
 * Course loop title
 *
 * @package Tutor\Templates
 * @subpackage CourseLoopPart
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.4.3
 */
?>

<h4 class="rbt-card-title">
	<?php if(is_search()) { ?>
		<a href="<?php echo esc_url( get_the_permalink() ); ?>">
                        <?php
                        // Get the post title
                        $post_title = get_the_title();
                        // Highlight search text within post title
                        $highlighted_title = preg_replace('/(' . preg_quote(get_search_query(), '/') . ')/i', '<mark>$1</mark>', $post_title);
                        echo $highlighted_title;
                        ?>
        </a>
	<?php } else { ?> 
	<a href="<?php echo esc_url( get_the_permalink() ); ?>"><?php echo esc_html( theme_truncate( get_the_title(), 35 ) );  ?></a>
	<?php } ?>
</h4>
<p class="rbt-card-desc">
	<?php echo esc_html( theme_truncate( get_the_excerpt(), 105 ) );  ?>
</p>
