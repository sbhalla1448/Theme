<?php
/**
 * Template for displaying single course
 *
 * @package Tutor\Templates
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.0.0
 */
global $post, $is_enrolled, $authordata;
$course_id       = get_the_ID();
$course_rating   = tutor_utils()->get_course_rating( $course_id );
$is_enrolled     = tutor_utils()->is_enrolled( $course_id, get_current_user_id() );
$profile_url       = tutor_utils()->profile_url( $authordata->ID, true );
$total_students_in_course = tutor_utils()->count_enrolled_users_by_course($course_id);

// Prepare the nav items.
$course_nav_item = apply_filters( 'tutor_course/single/nav_items', tutor_utils()->course_nav_items(), $course_id );
$is_public       = \TUTOR\Course_List::is_public( $course_id );
$is_mobile       = wp_is_mobile();

$enrollment_box_position = tutor_utils()->get_option( 'enrollment_box_position_in_mobile', 'bottom' );
if ( '-1' === $enrollment_box_position ) {
	$enrollment_box_position = 'bottom';
}
$student_must_login_to_view_course = tutor_utils()->get_option( 'student_must_login_to_view_course' );

tutor_utils()->tutor_custom_header();

if ( ! is_user_logged_in() && ! $is_public && $student_must_login_to_view_course ) {
	tutor_load_template( 'login' );
	tutor_utils()->tutor_custom_footer();
	return;
}
$course_categories 	= get_tutor_course_categories($course_id);
?>
<!-- Start breadcrumb Area -->
<div class="rbt-breadcrumb-default rbt-breadcrumb-style-3">
	<div class="breadcrumb-inner">
		<img src="<?php echo get_template_directory_uri(); ?>/assets/images/bg/bg-image-10.jpg" alt="Education Images">
	</div>
	<div class="container">
		<div class="row">
			<div class="col-lg-8">
				<div class="content text-start">
					<ul class="page-list">
						<li class="rbt-breadcrumb-item"><a href="<?php echo home_url('/'); ?>"><?php echo esc_html__('Home', 'open-learning'); ?></a></li>
						<li>
							<div class="icon-right"><i class="feather-chevron-right"></i></div>
						</li>
						<li class="rbt-breadcrumb-item active"><?php echo !empty($course_categories) ?esc_html($course_categories[0]->name) : ''; ?></li>
					</ul>
					<h2 class="title"><?php the_title(); ?></h2>
					<p class="description"><?php echo wp_trim_words(get_the_excerpt(), 25); ?></p>

					<div class="d-flex align-items-center mb--20 flex-wrap rbt-course-details-feature">
						<div class="feature-sin best-seller-badge">
							<span class="rbt-badge-2">
								<span class="image"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/card-icon-1.png"
										alt="Best Seller Icon"></span> Bestseller
							</span>
						</div>

						<div class="feature-sin rating">
							<a href="#"><?php echo esc_html($course_rating->rating_avg); ?></a>
							<a href="#"><i class="fa fa-star"></i></a>
							<a href="#"><i class="fa fa-star"></i></a>
							<a href="#"><i class="fa fa-star"></i></a>
							<a href="#"><i class="fa fa-star"></i></a>
							<a href="#"><i class="fa fa-star"></i></a>
						</div>

						<div class="feature-sin total-rating">
							<a class="rbt-badge-4" href="#"><?php echo esc_html($course_rating->rating_count); ?> rating</a>
						</div>

						<div class="feature-sin total-student">
							<span><?php echo esc_html($total_students_in_course); ?> students</span>
						</div>

					</div>

					<div class="rbt-author-meta mb--20">
						<div class="rbt-avater">
							<a href="<?php echo esc_url( $profile_url ); ?>">
								<?php echo wp_kses( tutor_utils()->get_tutor_avatar( $post->post_author ), tutor_utils()->allowed_avatar_tags() ); ?>
							</a>
						</div>
						<div class="rbt-author-info">
							By 
							<a href="<?php echo esc_url( $profile_url ); ?>"><?php echo esc_html( ucwords(get_the_author()) ); ?></a> In <a href="#">
							<?php if ( ! empty( $course_categories ) && is_array( $course_categories ) && count( $course_categories ) ) : ?>
								<?php
									$category_links = array();
								foreach ( $course_categories as $course_category ) :
									$category_name    = $course_category->name;
									$category_link    = get_term_link( $course_category->term_id );
									$category_links[] = wp_sprintf( '<a href="%1$s">%2$s</a>', esc_url( $category_link ), esc_html( $category_name ) );
									endforeach;
									echo implode( ', ', $category_links ); //phpcs:ignore --contain safe data
								?>
							<?php endif; ?>
							</a>
						</div>
					</div>

					<ul class="rbt-meta">
						<li><i class="feather-calendar"></i>
						<?php
							$last_updated = sprintf('Last updated %s', get_tutor_option( 'enable_course_update_date' ) ? get_the_modified_date( get_option( 'date_format' ) ) : get_the_date());
							echo $last_updated;
						?>
						</li>
						<li><i class="feather-globe"></i>English</li>
						<li><i class="feather-award"></i>Certified Course</li>
					</ul>

				</div>
			</div>
		</div>
	</div>
</div>
<!-- End Breadcrumb Area -->

<div class="rbt-course-details-area ptb--60">
	<div class="container">
		<div class="row g-5">
			<div class="col-lg-8">
				<div class="course-details-content">
					<div class="rbt-course-feature-box rbt-shadow-box thuumbnail">
						<?php tutor_utils()->has_video_in_single() ? tutor_course_video() : get_tutor_course_thumbnail(); ?>
					</div>
					<?php do_action( 'tutor_course/single/before/inner-wrap' ); ?>
					<?php if ( is_array( $course_nav_item ) && count( $course_nav_item ) > 1 ) : ?>
						<div class="rbt-inner-onepage-navigation sticky-top mt--30">
							<?php tutor_load_template( 'single.course.enrolled.nav', array( 'course_nav_item' => $course_nav_item ) ); ?>
						</div>
					<?php endif; ?>
					<?php foreach ( $course_nav_item as $key => $subpage ) : ?>
						<div id="<?php echo esc_attr( $key ); ?>">
							<?php
								$method = $subpage['method'];
								
								if ( is_string( $method ) ) {
									$method();
								} else {
									$_object = $method[0];
									$_method = $method[1];
									?>
									<div class="rbt-course-feature-box overview-wrapper rbt-shadow-box mt--30">
										<div class="rbt-course-feature-inner has-show-more-inner-content">
											<?php if( isset($_object->page_title) ): ?>
											<div class="section-title">
												<h4 class="rbt-title-style-3"><?php echo esc_html($_object->page_title); ?></h4>
											</div>
											<?php endif; ?>
											<?php
												$_object->$_method( get_the_ID() );
											?>
										</div>
									</div>
									<?php
								}
							?>
						</div>
					<?php endforeach; ?>
					<?php do_action( 'tutor_course/single/after/inner-wrap' ); ?>
				</div>
				<?php
					$author_id = get_post_field( 'post_author', $course_id );
					
					// $instructors = tutor_utils()->get_instructors_by_course($course_id);
					$related_courses_loop = olc_tutor_utils()->get_courses_by_instructor( (int) $author_id, (int) $course_id );
					if( $related_courses_loop->have_posts() ):
				?>
				<div class="related-course mt--60">
					<div class="row g-5 align-items-end mb--40">
						<div class="col-lg-8 col-md-8 col-12">
							<div class="section-title">
								<span class="subtitle bg-pink-opacity"><?php echo esc_html__('Top Course', 'open-learning'); ?></span>
								<h4 class="title"><?php echo esc_html__('More Courses By', 'open-learning'); ?> <strong class="color-primary"><?php echo esc_html(ucwords(get_the_author())); ?></strong></h4>
							</div>
						</div>
						<div class="col-lg-4 col-md-4 col-12">
							<div class="read-more-btn text-start text-md-end">
								<a class="rbt-btn rbt-switch-btn btn-border btn-sm" href="<?php echo esc_url($profile_url); ?>">
									<span data-text="View All Course"><?php esc_html_e('View All Course', 'open-learning'); ?></span>
								</a>
							</div>
						</div>
					</div>
					<div class="row g-5">
						<?php while( $related_courses_loop->have_posts() ): $related_courses_loop->the_post(); ?>
						<!-- Start Single Card  -->
						<div class="col-lg-6 col-md-6 col-sm-6 col-12" data-sal-delay="150" data-sal="slide-up" data-sal-duration="800">
							<?php
								/**
								 * Usage Idea, you may keep a loop within a wrap, such as bootstrap col
								 *
								 * @hook tutor_course/archive/before_loop_course
								 * @type action
								 */
								do_action( 'tutor_course/archive/before_loop_course' );

								tutor_load_template( 'loop.course' );

								/**
								 * Usage Idea, If you start any div before course loop, you can end it here, such as </div>
								 *
								 * @hook tutor_course/archive/after_loop_course
								 * @type action
								 */
								do_action( 'tutor_course/archive/after_loop_course' );
							?>
						</div>
						<!-- End Single Card  -->
						<?php endwhile; wp_reset_postdata(); ?>
					</div>
				</div>
				<?php endif; ?>
			</div>

			<div class="col-lg-4">
				<div class="course-sidebar sticky-top rbt-shadow-box course-sidebar-top rbt-gradient-border">
					<div class="inner">

						<!-- Start Viedo Wrapper  -->
						<?php
							$placeHolderUrl    	= tutor()->url . 'assets/images/placeholder.svg';
							$thumbnail_url 		= get_the_post_thumbnail_url($course_id);
							$course_video_url   = '#';
							$video_info = tutor_utils()->get_video_info();
							if( !empty($video_info->source_youtube) ){
								$course_video_url = esc_html($video_info->source_youtube);
							}
							if( !empty($video_info->source_vimeo) ){
								$course_video_url = esc_html($video_info->source_vimeo);
							}
						?>
						<a class="video-popup-with-text video-popup-wrapper text-center popup-video sidebar-video-hidden mb--15" href="<?php echo esc_url($course_video_url); ?>">
							<div class="video-content">
								<img class="w-100 rbt-radius" src="<?php echo esc_url($thumbnail_url)? esc_url($thumbnail_url) : esc_url($placeHolderUrl); ?>" alt="Video Images">
								<div class="position-to-top">
									<span class="rbt-btn rounded-player-2 with-animation">
										<span class="play-icon"></span>
									</span>
								</div>
								<span class="play-view-text d-block color-white"><i class="feather-eye"></i> <?php echo esc_html__('Preview this course', 'open-learning'); ?></span>
							</div>
						</a>
						<!-- End Viedo Wrapper  -->

						<div class="content-item-content">
							<?php
							$product_id = tutor_utils()->get_course_product_id( $course_id );
							$product    = wc_get_product( $product_id );
							
							$is_logged_in             = is_user_logged_in();
							$enable_guest_course_cart = tutor_utils()->get_option( 'enable_guest_course_cart' );
							$required_loggedin_class  = '';
							if ( ! $is_logged_in && ! $enable_guest_course_cart ) {
								$required_loggedin_class = apply_filters( 'tutor_enroll_required_login_class', 'tutor-open-login-modal' );
							}
							
							?>
							<?php if ( ( $is_mobile && 'bottom' === $enrollment_box_position ) || ! $is_mobile ) : ?>
								<?php tutor_load_template( 'single.course.course-entry-box' ); ?>
							<?php endif ?>
							<?php
								$_meta_youtube_link = function_exists('get_field')? get_field('youtube_link') : '';
								$_meta_tiktok_link = function_exists('get_field')? get_field('tiktok_link') : '';
								$_meta_facebook_link = function_exists('get_field')? get_field('facebook_link') : '';
								$_meta_twitter_link = function_exists('get_field')? get_field('twitter_link') : '';
								$_meta_insta_link = function_exists('get_field')? get_field('insta_link') : '';
								$_meta_linkedin_link = function_exists('get_field')? get_field('linked_in_link') : '';
								$_meta_phone = function_exists('get_field')? get_field('phone') : '';
							?>
							<div class="social-share-wrapper mt--30 text-center">
								<div class="rbt-post-share d-flex align-items-center justify-content-center">
									<ul class="social-icon social-default transparent-with-border justify-content-center">
										<li><a href="<?php echo esc_url($_meta_facebook_link); ?>">
												<i class="feather-facebook"></i>
											</a>
										</li>
										<li><a href="<?php echo esc_url($_meta_twitter_link); ?>">
												<i class="feather-twitter"></i>
											</a>
										</li>
										<li><a href="<?php echo esc_url($_meta_insta_link); ?>">
												<i class="feather-instagram"></i>
											</a>
										</li>
										<li><a href="<?php echo esc_url($_meta_linkedin_link); ?>">
												<i class="feather-linkedin"></i>
											</a>
										</li>
										<li><a href="<?php echo esc_url($_meta_youtube_link); ?>">
												<i class="feather-youtube"></i>
											</a>
										</li>
										<li><a href="<?php echo esc_url($_meta_tiktok_link); ?>">
										<i class="fab fa-tiktok"></i>
											</a>
										</li>
										
									</ul>
								</div>
								<?php if(!empty($_meta_phone)): ?>
								<hr class="mt--20">
								<div class="contact-with-us text-center">
									<p>For details about the course</p>
									<p class="rbt-badge-2 mt--10 justify-content-center w-100"><i class="feather-phone mr--5"></i> <?php _e('Call Us', 'open-learning'); ?>: <a href="tel:<?php echo esc_html($_meta_phone); ?>"><strong><?php echo esc_html($_meta_phone); ?></strong></a></p>
								</div>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php
tutor_utils()->tutor_custom_footer();
