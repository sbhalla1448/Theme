<?php
/**
 * 
 * Custom Inline Style
 */


 function custom_inline_style(){
    wp_enqueue_style('inline-style', get_stylesheet_uri());
    // h9 slider top and bottom shape style
    $top_image = get_theme_file_uri('/assets/img/slider/h9_slider_top_shape.png');
    $bottom_image = get_theme_file_uri('/assets//img/slider/h9_slider_bottom_shape.png');

    $styles = <<<EOD
    .h9-slider-area::after {
        background-image: url({$bottom_image});
    }

    .h9-slider-area::before {
        background-image: url({$top_image});
    }
    EOD;

    wp_add_inline_style( 'inline-style', $styles );
 }
 add_action('wp_enqueue_scripts', 'custom_inline_style');