<?php
/**
 * Custom Functions
 */

if(!function_exists('olc_get_placeholder_img')){
    function olc_get_placeholder_img(){
        return get_template_directory_uri() . '/assets/images/placeholder.svg';
    }
}

add_filter( 'auto_update_plugin', '__return_false' );
add_filter( 'auto_update_core', '__return_false' );

