<?php
 /**
 * 
 * Custom header functions
 * @package OLC
 * @version 1.0.0
 */

require_once( dirname(__DIR__) . '/classes/class-tb-customizer.php' );

$theme_options = new TB_Customizer( 'olc_customizer', array(
	'title'	=> __('OLC Theme Options'),
	'priority'	=> 20
));
 
$theme_options->add_section(array(
	'id'	=> 'olc_header',
	'title'	=> __('Header', 'open-learning'),
	'controls'	=> array(
		array(
			'id'	=> 'main_logo',
			'title'	=> __('Main Logo', 'open-learning'),
			'type'	=> 'image',
		),

		array(
			'id'	=> 'header_campaign',
			'title'	=> __('Header Campaign', 'open-learning'),
			'type'	=> 'checkbox',
			'default'	=> true
		),

		array(
			'id'	=> 'header_campaign_offer_text',
			'title'	=> __('Header Campaign Offer Text', 'open-learning'),
			'type'	=> 'text',
			'default'	=> 'Limited Time Offer',
			'callback'	=> function(){
				if( get_theme_mod('header_campaign') ){
					return true;
				}

				return false;
			}
		),

		array(
			'id'	=> 'header_campaign_text',
			'title'	=> __('Header Campaign Text', 'open-learning'),
			'type'	=> 'textarea',
			'default'	=> 'Intro price. Get Histudy for Big Sale -95% off.',
			'callback'	=> function(){
				if( get_theme_mod('header_campaign') ){
					return true;
				}

				return false;
			}
		),

		array(
			'id'	=> 'header_campaign_button_text',
			'title'	=> __('Header Campaign Button Text', 'open-learning'),
			'type'	=> 'text',
			'default'	=> 'Purchase Now',
			'callback'	=> function(){
				if( get_theme_mod('header_campaign') ){
					return true;
				}

				return false;
			}
		),
		array(
			'id'	=> 'header_campaign_button_link',
			'title'	=> __('Header Campaign Button Link', 'open-learning'),
			'type'	=> 'text',
			'default'	=> '#',
			'callback'	=> function(){
				if( get_theme_mod('header_campaign') ){
					return true;
				}

				return false;
			}
		),

		

		// array(
		// 	'id'	=> 'test_control',
		// 	'title'	=> __('Test Control', 'open-learning'),
		// 	'type'	=> 'text',
		// ),

		

		

		// array(
		// 	'id'	=> 'test_control_6',
		// 	'title'	=> __('Test Control 6', 'open-learning'),
		// 	'type'	=> 'number',
		// ),

		// array(
		// 	'id'	=> 'test_control_7',
		// 	'title'	=> __('Test Control 7', 'open-learning'),
		// 	'type'	=> 'range',
		// ),

		// array(
		// 	'id'	=> 'test_control_8',
		// 	'title'	=> __('Test Control 8', 'open-learning'),
		// 	'type'	=> 'date',
		// ),

		// array(
		// 	'id'	=> 'test_control_9',
		// 	'title'	=> __('Test Control 9', 'open-learning'),
		// 	'type'	=> 'time',
		// 	'attrs'	=> array(
		// 		'class' => 'form-control'
		// 	)
		// ),

		// array(
		// 	'id'	=> 'test_control_11',
		// 	'title'	=> __('Test Control 11', 'open-learning'),
		// 	'type'	=> 'image',
		// ),

		// array(
		// 	'id'	=> 'test_control_12',
		// 	'title'	=> __('Test Control 12', 'open-learning'),
		// 	'type'	=> 'audio',
		// ),

		// array(
		// 	'id'	=> 'test_control_10',
		// 	'title'	=> __('Test Control 10', 'open-learning'),
		// 	'type'	=> 'search',
		// ),

		// array(
		// 	'id'	=> 'test_control_5',
		// 	'title'	=> __('Test Control 5', 'open-learning'),
		// 	'type'	=> 'radio',
		// 	'choices'	=> array(
		// 		'male' => 'Male',
		// 		'female'	=> 'Female'
		// 	)
		// )

	)
));

$theme_options->add_section(array(
	'id'	=> 'olc_footer',
	'title'	=> __('Footer', 'open-learning'),
	'controls'	=> array(
		array(
			'id'	=> 'footer_logo',
			'title'	=> __('Footer Logo', 'open-learning'),
			'type'	=> 'image',
			'default' => esc_url( get_theme_file_uri('/assets/images/logo/logo.png') )
		),

		array(
			'id'	=> 'footer_text',
			'title'	=> __('Footer Text', 'open-learning'),
			'type'	=> 'textarea',
			'default'	=> esc_html__('We’re always in search for talented and motivated people. Don’t be shy introduce yourself!', 'open-learning')
		),

		array(
			'id'	=> 'footer_button_text',
			'title'	=> __('Footer Button Text', 'open-learning'),
			'type'	=> 'text',
			'default'	=> esc_html__('Contact With Us', 'open-learning')
		),

		array(
			'id'	=> 'footer_button_link',
			'title'	=> __('Footer Button Link', 'open-learning'),
			'type'	=> 'text',
			'default'	=> '#'
		),

		array(
			'id'	=> 'footer_copyright',
			'title'	=> __('Footer Copyright', 'open-learning'),
			'type'	=> 'textarea',
			'default'	=> 'Copyright © 2023 <a href="https://themeforest.net/user/rbt-themes">Rainbow-Themes.</a> All Rights Reserved'
		),

		array(
			'id'	=> 'footer_menu',
			'title'	=> __('Footer Menu', 'open-learning'),
			'type'	=> 'select',
			'choices'	=> olc_all_nav_menus(),
			'default'	=> '-1'
		),
	)
));

/**
 * Get all created menus
 */
function olc_all_nav_menus(){
	$menus = get_terms( 'nav_menu' );

	$args = array('-1' => 'Select a menu');
	foreach( $menus as $menu ){
		$args[$menu->term_id] = $menu->name;
	}

	return $args;
}

//  // theme customizer options
//  function theme_customizer($wp_customize){
// 	// theme option panel
// 	$wp_customize->add_panel('theme_options', array(
// 		'title' 		=> esc_html__('OLC Options', 'open-learning'),
// 		'description'	=> esc_html__('Theme modifications like header, footer options and color scheme', 'open-learning'),
// 		'priority'		=> 10
// 	));

// 	// woocommerce section start
// 	$wp_customize->add_section('adara_woocommerce_section', array(
// 		'title' 	=> esc_html__('OLC Woocommerce', 'open-learning'),
// 		'priority' => 40,
// 		'panel' 	=> 'theme_options'
//     ));
	
// 	$wp_customize->add_setting('adara_woocommerce_product_share', array(
// 		'default' 		=> 0,
// 		'sanitize_callback' => 'esc_attr',
// 		'transport' 	=> 'refresh'
// 	));  
   
// 	$wp_customize->add_control('adara_woocommerce_product_share', array(
// 		'label' 	=> esc_html__('Share Option', 'open-learning'),
// 		'section' 	=> 'adara_woocommerce_section',
// 		'type' 		=> 'checkbox',
// 		'active_callback'	=> function (){
// 			if(class_exists('woocommerce')){
// 				return true;
// 			}

// 			return false;
// 		}
// 	));

// 	// woocommerce section end

// 	// header customizer
// 	$wp_customize->add_section('header', array(
// 		 'title' 	=> esc_html__('Header', 'open-learning'),
// 		 'priority' => 20,
// 		 'panel' 	=> 'theme_options'
// 	));

// 	$wp_customize->add_setting('main_logo', array(
// 		'default' 	=> esc_url(get_theme_file_uri( '/assets/img/logo/logo.png' )),
// 		'sanitize_callback' => 'esc_url',
// 		'transport' => 'refresh'
// 	));

// 	$wp_customize->add_control( new WP_Customize_Image_Control($wp_customize, 'main_logo_control', array(
// 		'label' 	=> esc_html__('Main Logo', 'open-learning'),
// 		'section' 	=> 'header',
// 		'settings' 	=> 'main_logo'
// 	)));

// 	$wp_customize->selective_refresh->add_partial('main_logo', array(
// 		'selector'  => '#header-logo',
// 		'settings'	=> 'main_logo',
// 		'render_callback' => function(){
// 			return get_theme_mod( 'main_logo' );
// 		}
// 	));

// 	$wp_customize->add_setting('secondary_logo', array(
// 		'default' 	=> esc_url(get_theme_file_uri( '/assets/img/logo/w_logo.png' )),
// 		'sanitize_callback' => 'esc_url',
// 		'transport' => 'refresh'
// 	));

// 	$wp_customize->add_control( new WP_Customize_Image_Control($wp_customize, 'secondary_logo_control', array(
// 		'label' 	=> esc_html__('Secondary Logo', 'open-learning'),
// 		'section' 	=> 'header',
// 		'settings' 	=> 'secondary_logo'
// 	)));

// 	$wp_customize->add_setting('header_styles', array(
// 		'default' 	=> 'header_1',
// 		'sanitize_callback' => 'esc_attr',
// 		'transport' => 'refresh'
// 	));

// 	$wp_customize->add_control( 'header_styles_control', array(
// 	   'label' 		=> esc_html__('Select Header', 'open-learning'),
// 	   'section' 	=> 'header',
// 	   'settings' 	=> 'header_styles',
// 	   'type' 		=> 'select',
// 	   'choices' 	=> [
// 		   'header_1' => 'Header Style 1',
// 		   'header_2' => 'Header Style 2',
// 		   'header_3' => 'Header Style 3',
// 		   'header_4' => 'Header Style 4',
// 		   'header_5' => 'Header Style 5',
// 		   'header_6' => 'Header Style 6',
// 		   'header_7' => 'Header Style 7'
// 	   ]
// 	));


// 	// if woocommerce plugin active
// 	if( class_exists('woocommerce') ){
// 		$wp_customize->add_setting('wishlist_icon', array(
// 			'default' 		=> 0,
// 			'sanitize_callback' => 'esc_attr',
// 			'transport' 	=> 'refresh'
// 	    ));  
	   
// 	    $wp_customize->add_control('wishlist_icon_control', array(
// 			'label' 	=> esc_html__('Display wishlist icon', 'open-learning'),
// 			'section' 	=> 'header',
// 			'settings' 	=> 'wishlist_icon',
// 			'type' 		=> 'checkbox',
// 			'active_callback' => 'is_yith_wishlist_active'
// 		));

// 	    $wp_customize->add_setting('header_top_offer_text_hideshow', array(
// 			'default' 		=> 0,
// 			'sanitize_callback' => 'esc_html',
// 			'transport' 	=> 'refresh'
// 	    ));  
	   
// 	    $wp_customize->add_control('header_top_offer_text_hideshow_control', array(
// 			'label' 	=> esc_html__('Sale Offer', 'open-learning'),
// 			'section' 	=> 'header',
// 			'settings' 	=> 'header_top_offer_text_hideshow',
// 			'type' 		=> 'checkbox'
// 		));


// 		$wp_customize->add_setting('header_top_offer_text', array(
// 			'default' 		=> 'SUMMER SALE UP TO <span>70% OFF.</span> SHOP NOW',
// 			'sanitize_callback' => function($html){
// 			    return $html;
// 			},
// 			'transport' 	=> 'postMessage'
// 	    ));  

	   
// 	    $wp_customize->add_control('header_top_control', array(
// 			'label' 	=> esc_html__('Offer Text', 'open-learning'),
// 			'section' 	=> 'header',
// 			'settings' 	=> 'header_top_offer_text',
// 			'type' 		=> 'textarea',
// 			'active_callback' => 'hide_sale_offer_if_disable'
// 		));

// 		$wp_customize->selective_refresh->add_partial('header_top_offer_text', array(
// 			'selector'  => '#header_offer_text',
// 			'settings'	=> 'header_top_offer_text',
// 			'render_callback' => function(){
// 				return get_theme_mod( 'header_top_offer_text' );
// 			}
// 		));

// 		$wp_customize->add_setting('header_shipping_offer_text_hideshow', array(
// 			'default' 	=> 0,
// 			'sanitize_callback' => 'esc_html',
// 			'transport' => 'refresh'
// 		));
	
// 		$wp_customize->add_control('header_shipping_offer_text_hideshow_control', array(
// 			'label' 	=> esc_html__('Shipping Offer', 'open-learning'),
// 			'section' 	=> 'header',
// 			'settings' 	=> 'header_shipping_offer_text_hideshow',
// 			'type' 		=> 'checkbox'
// 		));

// 		$wp_customize->add_setting('header_shipping_offer_text', array(
// 			'default' 	=> 'Free Shipping on Orders <span>$39+</span>',
// 			'sanitize_callback' => function($html){
// 			    return $html;
// 			},
// 			'transport' => 'postMessage',
// 		));
	
// 		$wp_customize->add_control('header_shipping_offer_text_control', array(
// 			'label' 	=> esc_html__('Shipping Offer Text', 'open-learning'),
// 			'section' 	=> 'header',
// 			'settings' 	=> 'header_shipping_offer_text',
// 			'type' 		=> 'textarea',
// 			'active_callback' => 'hide_shipping_offer_if_disable'
// 		));

// 		$wp_customize->selective_refresh->add_partial('header_shipping_offer_text', array(
// 			'selector'  => '#header_shipping_offer_text',
// 			'settings'	=> 'header_shipping_offer_text',
// 			'render_callback' => function(){
// 				return get_theme_mod( 'header_shipping_offer_text' );
// 			}
// 		));
// 	}

// 	// offcanvas
// 	$wp_customize->add_setting('header_offcanvas', array(
// 		'default' 	=> 0,
// 		'sanitize_callback' => 'esc_attr',
// 		'transport' => 'refresh'
// 	 ));

// 	$wp_customize->add_control('header_offcanvas_control', array(
// 		'label' 	=> esc_html__('Display Offcanvas', 'open-learning'),
// 		'section' 	=> 'header',
// 		'settings' 	=> 'header_offcanvas',
// 		'type' 		=> 'checkbox'
// 	));

// 	$wp_customize->add_setting('offcanvas_text', array(
// 		'default' 	=> 'WooCommerce and WordPress are both free, open source software reasons many!',
// 		'sanitize_callback' => 'esc_html',
// 		'transport' => 'postMessage'
// 	 ));

// 	$wp_customize->add_control('offcanvas_text_control', array(
// 		'label' 	=> esc_html__('Offcanvas Text', 'open-learning'),
// 		'section' 	=> 'header',
// 		'settings' 	=> 'offcanvas_text',
// 		'type' 		=> 'textarea',
// 		'active_callback'	=> 'display_offcanvas_options_when_active'
// 	));

// 	$wp_customize->selective_refresh->add_partial('offcanvas_text', array(
// 		'selector'  => '#offcanvas_text',
// 		'settings'	=> 'offcanvas_text',
// 		'render_callback' => function(){
// 			return get_theme_mod( 'offcanvas_text' );
// 		}
// 	));

// 	$wp_customize->add_setting('offcanvas_contact_phone', array(
// 		'default' 	=> '+93254440000',
// 		'sanitize_callback' => 'esc_html',
// 		'transport' => 'postMessage'
// 	 ));

// 	$wp_customize->add_control('offcanvas_contact_phone_control', array(
// 		'label' 	=> esc_html__('Phone', 'open-learning'),
// 		'section' 	=> 'header',
// 		'settings' 	=> 'offcanvas_contact_phone',
// 		'type' 		=> 'text',
// 		'active_callback'	=> 'display_offcanvas_options_when_active'
// 	));


// 	$wp_customize->add_setting('offcanvas_contact_email', array(
// 		'default' 	=> 'adara@info.com',
// 		'sanitize_callback' => 'esc_html',
// 		'transport' => 'postMessage'
// 	 ));

// 	$wp_customize->add_control('offcanvas_contact_email_control', array(
// 		'label' 	=> esc_html__('Email', 'open-learning'),
// 		'section' 	=> 'header',
// 		'settings' 	=> 'offcanvas_contact_email',
// 		'type' 		=> 'text',
// 		'active_callback'	=> 'display_offcanvas_options_when_active'
// 	));


// 	$wp_customize->add_setting('offcanvas_contact_address', array(
// 		'default' 	=> '71 Park Lan Street 2355 NY',
// 		'sanitize_callback' => 'esc_html',
// 		'transport' => 'postMessage'
// 	));

// 	$wp_customize->add_control('offcanvas_contact_address_control', array(
// 		'label' 	=> esc_html__('Address', 'open-learning'),
// 		'section' 	=> 'header',
// 		'settings' 	=> 'offcanvas_contact_address',
// 		'type' 		=> 'text',
// 		'active_callback'	=> 'display_offcanvas_options_when_active'
// 	));



// 	// footer customizer
	
// 	$wp_customize->add_section('footer', array(
// 		'title' 	=> esc_html__('Footer', 'open-learning'),
// 		'priority' 	=> 20,
// 		'panel' 	=> 'theme_options'
// 	));

// 	$wp_customize->add_setting('footer_styles', array(
// 		'default' 	=> 'footer_1',
// 		'sanitize_callback' => 'esc_attr',
// 		'transport' => 'refresh'
// 	));

// 	$wp_customize->add_control( 'footer_styles_control', array(
// 	   'label' 		=> esc_html__('Select Footer', 'open-learning'),
// 	   'section' 	=> 'footer',
// 	   'settings' 	=> 'footer_styles',
// 	   'type' 		=> 'select',
// 	   'choices' 	=> [
// 		   'footer_1' => 'Footer Style 1',
// 		   'footer_2' => 'Footer Style 2',
// 		   'footer_3' => 'Footer Style 3',
// 	   ]
// 	));

// 	$wp_customize->add_setting('footer_1_logo', array(
// 		'default' 			=> esc_url(get_theme_file_uri( '/assets/img/logo/w_logo.png' )),
// 		'sanitize_callback' => 'esc_url',
// 		'transport' 		=> 'refresh'
// 	));

// 	$wp_customize->add_control( new WP_Customize_Image_Control($wp_customize, 'footer_logo_1_control', array(
// 		'label' 	=> esc_html__('Footer 1 Logo', 'open-learning'),
// 		'section' 	=> 'footer',
// 		'settings' 	=> 'footer_1_logo',
// 	)));

// 	$wp_customize->add_setting('footer_2_logo', array(
// 		'default' 			=> esc_url(get_theme_file_uri( '/assets/img/logo/logo.png' )),
// 		'sanitize_callback' => 'esc_url',
// 		'transport' 		=> 'refresh'
// 	));

// 	$wp_customize->add_control( new WP_Customize_Image_Control($wp_customize, 'footer_logo_2_control', array(
// 		'label' 	=> esc_html__('Footer 2 Logo', 'open-learning'),
// 		'section' 	=> 'footer',
// 		'settings' 	=> 'footer_2_logo'
// 	)));

// 	$wp_customize->selective_refresh->add_partial('footer_logo', array(
// 		'selector'  => '#footer-logo',
// 		'settings'	=> 'footer_logo',
// 		'render_callback' => function(){
// 			return get_theme_mod( 'footer_logo' );
// 		}
// 	));

// 	$wp_customize->add_setting('footer_socials', array(
// 		'default' 	=> 1,
// 		'sanitize_callback' => 'esc_attr',
// 		'transport' => 'refresh'
// 	));

// 	$wp_customize->add_control('footer_socials_control', array(
// 		'label' 	=> esc_html__('Display Socials', 'open-learning'),
// 		'section' 	=> 'footer',
// 		'settings' 	=> 'footer_socials',
// 		'type' 		=> 'checkbox'
// 	));

// 	$wp_customize->selective_refresh->add_partial('footer_socials_links', array(
// 		'selector'  => '#footer-social-links',
// 		'settings'	=> 'footer_socials',
// 		'render_callback' => function(){
// 			return get_theme_mod( 'footer_socials' );
// 		}
// 	));

// 	$wp_customize->add_setting('facebook_link', array(
// 		'default' 	=> '#',
// 		'sanitize_callback' => 'esc_url',
// 		'transport' => 'refresh'
// 	));
	
// 	$wp_customize->add_control('facebook_link_control', array(
// 		'label' 	=> esc_html__('Facebook', 'open-learning'),
// 		'section' 	=> 'footer',
// 		'settings' 	=> 'facebook_link',
// 		'type' 		=> 'url',
// 		'active_callback' => 'hide_socials_if_disable'
// 	));

// 	$wp_customize->add_setting('twitter_link', array(
// 		'default' 	=> '#',
// 		'sanitize_callback' => 'esc_url',
// 		'transport' => 'refresh'
// 	));
	
// 	$wp_customize->add_control('twitter_link_control', array(
// 		'label' 	=> esc_html__('Twitter', 'open-learning'),
// 		'section' 	=> 'footer',
// 		'settings' 	=> 'twitter_link',
// 		'type' 		=> 'url',
// 		'active_callback' => 'hide_socials_if_disable'
// 	));

// 	$wp_customize->add_setting('youtube_link', array(
// 		'default' 	=> '#',
// 		'sanitize_callback' => 'esc_url',
// 		'transport' => 'refresh'
// 	));
	
// 	$wp_customize->add_control('youtube_link_control', array(
// 		'label' 	=> esc_html__('Youtube', 'open-learning'),
// 		'section' 	=> 'footer',
// 		'settings' 	=> 'youtube_link',
// 		'type' 		=> 'url',
// 		'active_callback' => 'hide_socials_if_disable'
// 	));

// 	$wp_customize->add_setting('instagram_link', array(
// 		'default' 	=> '#',
// 		'sanitize_callback' => 'esc_url',
// 		'transport' => 'refresh'
// 	));
	
// 	$wp_customize->add_control('instagram_link_control', array(
// 		'label' 	=> esc_html__('Instagram', 'open-learning'),
// 		'section' 	=> 'footer',
// 		'settings' 	=> 'instagram_link',
// 		'type' 		=> 'url',
// 		'active_callback' => 'hide_socials_if_disable'
// 	));

// 	$wp_customize->add_setting('linkedin_link', array(
// 		'default' 	=> '#',
// 		'sanitize_callback' => 'esc_url',
// 		'transport' => 'refresh'
// 	));
	
// 	$wp_customize->add_control('linkedin_link_control', array(
// 		'label' 	=> esc_html__('Linked In', 'open-learning'),
// 		'section' 	=> 'footer',
// 		'settings' 	=> 'linkedin_link',
// 		'type' 		=> 'url',
// 		'active_callback' => 'hide_socials_if_disable'
// 	));


//     $footer_copyright = wp_kses_post('&copy; 2022 <a href="'.site_url('/').'">adara</a>. All Rights Reserved | Ph (+09) 456 457869');
// 	$wp_customize->add_setting('footer_copyright_text', array(
// 		'default'	=> $footer_copyright,
// 		'sanitize_callback' => function($html){
// 		    return $html;
// 		},
// 		'transport' => 'refresh' // refresh/postMessage
// 	));

// 	$wp_customize->add_control('footer_copyright_text_control',array(
// 		'label' 	=> esc_html__('Copyright Text', 'open-learning'),
// 		'section' 	=> 'footer',
// 		'settings' 	=> 'footer_copyright_text',
// 		'type' 		=> 'textarea'
// 	));

// 	$wp_customize->selective_refresh->add_partial('footer_copyright_text', array(
// 		'selector'  => '#footer_copyright_text',
// 		'settings'	=> 'footer_copyright_text',
// 		'render_callback' => function(){
// 			return get_theme_mod( 'footer_copyright_text' );
// 		}
// 	));

// 	// if woocommerce plugin active
// 	if( class_exists('woocommerce') ){
// 		$wp_customize->add_setting('payment_methods', array(
// 			'default' 	=> esc_url(get_theme_file_uri( '/assets/img/images/payment_method_img.png' )),
// 			'sanitize_callback' => 'esc_url',
// 			'transport' => 'refresh'
// 		));
	
// 		$wp_customize->add_control( new WP_Customize_Image_Control($wp_customize, 'payment_methods_control', array(
// 			'label' 	=> esc_html__('Payment Methods', 'open-learning'),
// 			'section' 	=> 'footer',
// 			'settings' 	=> 'payment_methods'
// 		)));

// 		$wp_customize->selective_refresh->add_partial('payment_methods', array(
// 			'selector'  => '#payment-img',
// 			'settings'	=> 'payment_methods',
// 			'render_callback' => function(){
// 				return get_theme_mod( 'payment_methods' );
// 			}
// 		));
// 	}

// 	// Breadcrumb customizer
// 	$wp_customize->add_section('breadcrumb', array(
// 		'title' 	=> esc_html__('Breadcrumb', 'open-learning'),
// 		'priority' 	=> 30,
// 		'panel'		=> 'theme_options'
//   	));

// 	$wp_customize->add_setting('breadcrumb_title', array(
// 		'default' 	=> esc_html__( 'Our Blog', 'open-learning' ),
// 		'sanitize_callback' => 'esc_html',
// 		'transport' => 'refresh'
// 	));

// 	$wp_customize->add_control( 'breadcrumb_title_control', array(
// 		'label' 	=> esc_html__('Title', 'open-learning'),
// 		'section' 	=> 'breadcrumb',
// 		'settings' 	=> 'breadcrumb_title'
// 	));

// 	$wp_customize->add_setting('breadcrumb_bg', array(
// 		'default' 	=> '',
// 		'sanitize_callback' => 'esc_url',
// 		'transport' => 'refresh'
// 	));

// 	$wp_customize->add_control( new WP_Customize_Image_Control($wp_customize, 'breadcrumb_bg_control', array(
// 		'label' 	=> esc_html__('Background', 'open-learning'),
// 		'section' 	=> 'breadcrumb',
// 		'settings' 	=> 'breadcrumb_bg'
// 	)));
//  }

//  add_action('customize_register', 'theme_customizer');


//  // check if yith wishlist exist
//  function is_yith_wishlist_active(){
// 	 if( defined('YITH_WCWL') ){
// 		 return true;
// 	 }

// 	 return false;
//  }

//  // hide socials links if disable
//  function hide_socials_if_disable(){
// 	 if( get_theme_mod('footer_socials') == 1 ){
// 		 return true;
// 	 }

// 	 return false;
//  }

//  // hide offcanvas when not use
//  function display_offcanvas_options_when_active(){
// 	if( get_theme_mod('header_offcanvas') == 1 ){
// 		return true;
// 	}

// 	return false;
//  }

//  // hide shipping offer if disable
//  function hide_shipping_offer_if_disable(){
// 	if( get_theme_mod('header_shipping_offer_text_hideshow') == 1 ){
// 		return true;
// 	}

// 	return false;
//  }

//  // hide shipping offer if disable
//  function hide_sale_offer_if_disable(){
// 	if( get_theme_mod('header_top_offer_text_hideshow') == 1 ){
// 		return true;
// 	}

// 	return false;
//  }

//  // customizer live preview with js
//  function customizer_live_preview(){
// 	 wp_enqueue_script( 'adara-customizer-js', get_theme_file_uri( '/assets/js/adara-customizer.js' ), array('jquery', 'customize-preview'), '1.0', true);
//  }

//  add_action( 'customize_preview_init', 'customizer_live_preview' );

/**
* Enqueue script for custom customize control.
*/
function olc_theme_customizer_scripts() {
	wp_enqueue_script( 'cz-javascript', get_template_directory_uri() . '/assets/js/customizer.js', array( 'jquery', 'customize-controls' ), false, true );
}
add_action( 'customize_controls_enqueue_scripts', 'olc_theme_customizer_scripts' );

/**
 * Enqueue the stylesheet.
 */
function olc_theme_customizer_styles() {
	wp_register_style( 'cz-customizer-css', get_template_directory_uri() . '/assets/css/customizer.css', NULL, NULL, 'all' );
	wp_enqueue_style( 'cz-customizer-css' );

}
add_action( 'customize_controls_print_styles', 'olc_theme_customizer_styles' );
