<?php
/**
 * Sidebars For Theme
 * @package OLC
 * @version 1.0.0
 */


function tb_registered_sidebars() {
    register_sidebar(array(
        'id'            => 'blog-sidebar',
        'name'          => esc_html__( 'Blog Sidebar', 'open-learning' ),
        'description'   => esc_html__( 'A blog sidebar for blog widgets','open-learning' ),
        'before_widget' => '<div id="%1$s" class="rbt-single-widget %2$s"><div class="inner">',
        'after_widget'  => '</div></div>',
        'before_title'  => '<h4 class="rbt-widget-title">',
        'after_title'   => '</h4>',
    ));

    register_sidebar(array(
        'id'            => 'footer-1-column-2',
        'name'          => esc_html__( 'Footer 1 Column 2', 'open-learning' ),
        'description'   => esc_html__( 'A footer sidebar for footer widgets','open-learning' ),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h5 class="ft-title">',
        'after_title'   => '</h5>',
    ));

    register_sidebar(array(
        'id'            => 'footer-1-column-3',
        'name'          => esc_html__( 'Footer 1 Column 3', 'open-learning' ),
        'description'   => esc_html__( 'A footer sidebar for footer widgets','open-learning' ),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h5 class="ft-title">',
        'after_title'   => '</h5>',
        'menu_class' => 'ft-link',
    ));

    register_sidebar(array(
        'id'            => 'footer-1-column-4',
        'name'          => esc_html__( 'Footer 1 Column 4', 'open-learning' ),
        'description'   => esc_html__( 'A footer sidebar for footer widgets','open-learning' ),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h5 class="ft-title">',
        'after_title'   => '</h5>',
    ));
    
}
add_action( 'widgets_init', 'tb_registered_sidebars' );