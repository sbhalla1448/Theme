<?php
/**
 * 
 * this file is for loading the statics files css, js and fonts
 */

 require_once( dirname(__DIR__) . '/classes/class-tb-loader.php' );

 /**
  * loading all the css files
  */
 Loader::style('bootstrap', '/assets/css/vendor/bootstrap.min.css');
 Loader::style('slick', '/assets/css/vendor/slick.css');
 Loader::style('slick-theme', '/assets/css/vendor/slick-theme.css');
 Loader::style('sal', '/assets/css/plugins/sal.css');
 Loader::style('feather', '/assets/css/plugins/feather.css');
 Loader::style('fontawesome', '/assets/css/plugins/fontawesome.min.css');
 Loader::style('euclid-circulara', '/assets/css/plugins/euclid-circulara.css');
 Loader::style('swiper', '/assets/css/plugins/swiper.css');
 Loader::style('magnify', '/assets/css/plugins/magnify.css');
 Loader::style('odometer', '/assets/css/plugins/odometer.css');
 Loader::style('animation', '/assets/css/plugins/animation.css');
 Loader::style('bootstrap-select', '/assets/css/plugins/bootstrap-select.min.css');
 Loader::style('jquery-ui', '/assets/css/plugins/jquery-ui.css');
 Loader::style('magnigy-popup', '/assets/css/plugins/magnigy-popup.min.css');
 Loader::style('plyr', '/assets/css/plugins/plyr.css');
 Loader::style('slick-slider', '/assets/css/plugins/slick-slider.css');


 Loader::style('main', 'main');
//  Loader::style('new', '/assets/css/plugins/new.css');



 /**
  * loading all the js files
  */
 Loader::script('modernizr', '/assets/js/vendor/modernizr.min.js');
 Loader::script('bootstrap', '/assets/js/vendor/bootstrap.min.js');
 Loader::script('sal', '/assets/js/vendor/sal.js');
 Loader::script('swiper', '/assets/js/vendor/swiper.js');
 Loader::script('magnify', '/assets/js/vendor/magnify.min.js');
 Loader::script('jquery-appear', '/assets/js/vendor/jquery-appear.js');
 Loader::script('odometer', '/assets/js/vendor/odometer.js');
//  Loader::script('backtotop', '/assets/js/vendor/backtotop.js');
 Loader::script('isotop', '/assets/js/vendor/isotop.js');
 Loader::script('imageloaded', '/assets/js/vendor/imageloaded.js');
 Loader::script('wow', '/assets/js/vendor/wow.js');
//  Loader::script('waypoint', '/assets/js/vendor/waypoint.min.js');
 Loader::script('easypie', '/assets/js/vendor/easypie.js');
 Loader::script('text-type', '/assets/js/vendor/text-type.js');
 Loader::script('jquery-one-page-nav', '/assets/js/vendor/jquery-one-page-nav.js');
 Loader::script('bootstrap-select', '/assets/js/vendor/bootstrap-select.min.js');
 Loader::script('jquery-ui', '/assets/js/vendor/jquery-ui.js');
 Loader::script('magnify-popup', '/assets/js/vendor/magnify-popup.min.js');
//  Loader::script('paralax-scroll', '/assets/js/vendor/paralax-scroll.js');
 Loader::script('paralax', '/assets/js/vendor/paralax.min.js');
 Loader::script('countdown', '/assets/js/vendor/countdown.js');
 Loader::script('plyr', '/assets/js/vendor/plyr.js');
 Loader::script('slick-slider', '/assets/js/slick-slider.js');
 Loader::script('main', '/assets/js/main.js');


 /**
  * Calling the load function
  */
 Loader::load();